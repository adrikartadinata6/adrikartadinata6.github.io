<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>
<tagfile doxygen_version="1.9.8">
  <compound kind="file">
    <name>mexutils.h</name>
    <path>toolbox/</path>
    <filename>mexutils_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="no" import="no" module="no" objc="no">vl/generic.h</includes>
    <includes id="array_8h" name="array.h" local="no" import="no" module="no" objc="no">vl/array.h</includes>
    <includes id="stringop_8h" name="stringop.h" local="no" import="no" module="no" objc="no">vl/stringop.h</includes>
    <class kind="struct">_vlmxOption</class>
    <member kind="define">
      <type>#define</type>
      <name>IN</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a602414ed5181cca60faf1b9fbea4d240</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>OUT</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a14e866e302d035546fbec8dd1ba8c8ca</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_USE_MATLAB_ENV</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a76600f902337bf06037c62b27d76255c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function" static="yes">
      <type>static mxArray *</type>
      <name>vlmxCreatePlainScalar</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>aa64206ada8d179eb1576418ddf937591</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static mxArray *</type>
      <name>vlmxCreateArrayFromVlArray</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a6cd2dc2208edffc0fda3c358b3406b8f</anchor>
      <arglist>(VlArray const *x)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static VlArray *</type>
      <name>vlmxEnvelopeArrayInVlArray</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a80f4863898c7e000a194574f46c06313</anchor>
      <arglist>(VlArray *v, mxArray *x)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxCompareStringsI</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a6a57980687db8396fdd97766fe1bec14</anchor>
      <arglist>(const char *s1, const char *s2)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxCompareToStringI</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>ac17232977bdd780e9387389212c6f318</anchor>
      <arglist>(mxArray const *array, char const *string)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxIsEqualToStringI</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a480999aaa7a6d34243ca858789937ae7</anchor>
      <arglist>(mxArray const *array, char const *string)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxNextOption</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a6b8c52584738d2616f7e0576dc035ea3</anchor>
      <arglist>(mxArray const *args[], int nargs, vlmxOption const *options, int *next, mxArray const **optarg)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static VlEnumerator *</type>
      <name>vlmxDecodeEnumeration</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>afd107856f6583a08e9841172ba91f110</anchor>
      <arglist>(mxArray const *name_array, VlEnumerator const *enumeration, vl_bool caseInsensitive)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsOfClass</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a738f24a24faa9ebfeedb7439ccc4bf44</anchor>
      <arglist>(mxArray const *array, mxClassID classId)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsReal</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a923b6ac320a8aa620a5e8edbe0ee2d2e</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsScalar</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a98ffbf2c20ade9e5094e234e8d58fd8a</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsVector</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a62ed566c271ce76980b587ad2b62b18e</anchor>
      <arglist>(mxArray const *array, vl_index numElements)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsMatrix</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>ab2c48ea72560b1a395a6ce7d6f521ad5</anchor>
      <arglist>(mxArray const *array, vl_index M, vl_index N)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsArray</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>aa9cb2ff7d93e845c8e97260742e355da</anchor>
      <arglist>(mxArray const *array, vl_index numDimensions, vl_index *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlain</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>af28c45fe72ed8814a863f2f00b6909b8</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainScalar</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>ab77fcfb1602e857224014b8ffbad446b</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainVector</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a22eb52c5f6925ea272604bef184c6def</anchor>
      <arglist>(mxArray const *array, vl_index numElements)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainMatrix</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a853a2401a28a2b640f4510772057e75f</anchor>
      <arglist>(mxArray const *array, vl_index M, vl_index N)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxIsString</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a1a0c4101bd3fa1e931867980f3f94240</anchor>
      <arglist>(const mxArray *array, vl_index length)</arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlmxErrorId</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>afe2395ec371beece50f65e7b18edf67a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vlmxError</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a41187a1ec528ba20cb338d321ddbd512</anchor>
      <arglist>(VlmxErrorId errorId, char const *errorMessage,...)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vlmxWarning</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a8a91f9f60803e7a808e71123340bdcb1</anchor>
      <arglist>(VlmxErrorId errorId, char const *errorMessage,...)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsOfClass</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a738f24a24faa9ebfeedb7439ccc4bf44</anchor>
      <arglist>(mxArray const *array, mxClassID classId)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsReal</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a923b6ac320a8aa620a5e8edbe0ee2d2e</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsScalar</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a98ffbf2c20ade9e5094e234e8d58fd8a</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsVector</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a62ed566c271ce76980b587ad2b62b18e</anchor>
      <arglist>(mxArray const *array, vl_index numElements)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsMatrix</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>ab2c48ea72560b1a395a6ce7d6f521ad5</anchor>
      <arglist>(mxArray const *array, vl_index M, vl_index N)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static vl_bool</type>
      <name>vlmxIsArray</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>aa9cb2ff7d93e845c8e97260742e355da</anchor>
      <arglist>(mxArray const *array, vl_index numDimensions, vl_index *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlain</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>af28c45fe72ed8814a863f2f00b6909b8</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainScalar</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>ab77fcfb1602e857224014b8ffbad446b</anchor>
      <arglist>(mxArray const *array)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainVector</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a22eb52c5f6925ea272604bef184c6def</anchor>
      <arglist>(mxArray const *array, vl_index numElements)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vlmxIsPlainMatrix</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a853a2401a28a2b640f4510772057e75f</anchor>
      <arglist>(mxArray const *array, vl_index M, vl_index N)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>vlmxIsString</name>
      <anchorfile>mexutils_8h.html</anchorfile>
      <anchor>a1a0c4101bd3fa1e931867980f3f94240</anchor>
      <arglist>(const mxArray *array, vl_index length)</arglist>
    </member>
    <docanchor file="mexutils_8h.html" title="VLFeat environment">mexutils-env</docanchor>
    <docanchor file="mexutils_8h.html" title="Array tests">mexutils-array-test</docanchor>
    <docanchor file="mexutils_8h.html" title="Parsing options">mexutils-options</docanchor>
  </compound>
  <compound kind="file">
    <name>aib.c</name>
    <path>vl/</path>
    <filename>aib_8c.html</filename>
    <includes id="aib_8h" name="aib.h" local="yes" import="no" module="no" objc="no">aib.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_normalize_P</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a14bc24cb8ad409132d16de6e3f27b002</anchor>
      <arglist>(double *P, vl_uint nelem)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint *</type>
      <name>vl_aib_new_nodelist</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>ae003cbee18d40f48e1e75da92033bc86</anchor>
      <arglist>(vl_uint nentries)</arglist>
    </member>
    <member kind="function">
      <type>double *</type>
      <name>vl_aib_new_Px</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a8983ead522cb83ce5af471645d707d35</anchor>
      <arglist>(double *Pcx, vl_uint nvalues, vl_uint nlabels)</arglist>
    </member>
    <member kind="function">
      <type>double *</type>
      <name>vl_aib_new_Pc</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>abc749f7b5095a5ac34db135de4fda4f6</anchor>
      <arglist>(double *Pcx, vl_uint nvalues, vl_uint nlabels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_min_beta</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>aa567101e4f0835b9a73a9b037afa0953</anchor>
      <arglist>(VlAIB *aib, vl_uint *besti, vl_uint *bestj, double *minbeta)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_merge_nodes</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a4b04bbe5d45b4a9fd84aecb173fbab93</anchor>
      <arglist>(VlAIB *aib, vl_uint i, vl_uint j, vl_uint new)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_update_beta</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a474eae5c9436f86251eea120221e8bd1</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_calculate_information</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a531a6f39064384f6728df5a1641d7f54</anchor>
      <arglist>(VlAIB *aib, double *I, double *H)</arglist>
    </member>
    <member kind="function">
      <type>VlAIB *</type>
      <name>vl_aib_new</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>aaf86aa3d7137937e1e56a52e6d055949</anchor>
      <arglist>(double *Pcx, vl_uint nvalues, vl_uint nlabels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_delete</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a145bb0e2d8f512613e8fd3fb92fe7ace</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_process</name>
      <anchorfile>aib_8c.html</anchorfile>
      <anchor>a2adbc69469a6200896e6582474c398ee</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>aib.h</name>
    <path>vl/</path>
    <filename>aib_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <class kind="struct">VlAIB</class>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_set_verbosity</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a452b9ca04f5c7a46a6b82df3f3ed9bf5</anchor>
      <arglist>(VlAIB *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_aib_get_verbosity</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a7b284789083a9644e96f66da1319ec96</anchor>
      <arglist>(VlAIB const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlAIB *</type>
      <name>vl_aib_new</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>aaf86aa3d7137937e1e56a52e6d055949</anchor>
      <arglist>(double *Pcx, vl_uint nvalues, vl_uint nlabels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_delete</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a145bb0e2d8f512613e8fd3fb92fe7ace</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_process</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a2adbc69469a6200896e6582474c398ee</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint *</type>
      <name>vl_aib_get_parents</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>ab5f34e685e826902284748f40328f27e</anchor>
      <arglist>(VlAIB const *aib)</arglist>
    </member>
    <member kind="function">
      <type>double *</type>
      <name>vl_aib_get_costs</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a9fca2d098bd88a72132c5eca55db4f7b</anchor>
      <arglist>(VlAIB const *aib)</arglist>
    </member>
    <member kind="function">
      <type>VlAIB *</type>
      <name>vl_aib_new</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>aaf86aa3d7137937e1e56a52e6d055949</anchor>
      <arglist>(double *Pcx, vl_uint nvalues, vl_uint nlabels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_delete</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a145bb0e2d8f512613e8fd3fb92fe7ace</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_aib_process</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a2adbc69469a6200896e6582474c398ee</anchor>
      <arglist>(VlAIB *aib)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint *</type>
      <name>vl_aib_get_parents</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>ab5f34e685e826902284748f40328f27e</anchor>
      <arglist>(VlAIB const *aib)</arglist>
    </member>
    <member kind="function">
      <type>double *</type>
      <name>vl_aib_get_costs</name>
      <anchorfile>aib_8h.html</anchorfile>
      <anchor>a9fca2d098bd88a72132c5eca55db4f7b</anchor>
      <arglist>(VlAIB const *aib)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>array.h</name>
    <path>vl/</path>
    <filename>array_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlArray</class>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARRAY_MAX_NUM_DIMENSIONS</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a80a9a517ee30d7400df369f6a126efd1</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_array_get_num_dimensions</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a5c38f7c444dbab895b31fc4fdb88422d</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size const *</type>
      <name>vl_array_get_dimensions</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>ae0f0e45c20b3b93845430676768928b9</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_array_get_data</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>aa93c4334e0ea760def9fb1755da0a6d4</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_array_get_data_type</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a8a855ba511380e99590905879e578ed2</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_array_get_num_elements</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a96d147d44ba7cbe905565181fa8b970f</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a13e937fbbbbb7507dfafa0cc7e558b11</anchor>
      <arglist>(VlArray *self, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>acb0dd35407984736a820c754a30d11fd</anchor>
      <arglist>(VlArray *self, void *data, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_matrix</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a711b0dba1e11f616f26f58bf5bb0af84</anchor>
      <arglist>(VlArray *self, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_matrix_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>aaace92daf56a02734d0ef6079ee71f50</anchor>
      <arglist>(VlArray *self, void *data, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a78e0f4b38bafedfe0ef31f5ad1d18dad</anchor>
      <arglist>(vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a67b31b72d500e04d66894be78d3f08cb</anchor>
      <arglist>(void *data, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_matrix</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>ab0bb77833389b149bd15e4fc91f6f63e</anchor>
      <arglist>(vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_matrix_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a1a3af13a5d54bdbb2d436ed878a67d90</anchor>
      <arglist>(void *data, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_array_dealloc</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a22469f7d3a16d6bd56025330c87c351e</anchor>
      <arglist>(VlArray *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_array_delete</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a32a8f1faf1c01c33c762b5a607a53582</anchor>
      <arglist>(VlArray *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_array_get_num_dimensions</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a5c38f7c444dbab895b31fc4fdb88422d</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size const *</type>
      <name>vl_array_get_dimensions</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>ae0f0e45c20b3b93845430676768928b9</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_array_get_data</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>aa93c4334e0ea760def9fb1755da0a6d4</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_array_get_data_type</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a8a855ba511380e99590905879e578ed2</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_array_get_num_elements</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a96d147d44ba7cbe905565181fa8b970f</anchor>
      <arglist>(VlArray const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a13e937fbbbbb7507dfafa0cc7e558b11</anchor>
      <arglist>(VlArray *self, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>acb0dd35407984736a820c754a30d11fd</anchor>
      <arglist>(VlArray *self, void *data, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_matrix</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a711b0dba1e11f616f26f58bf5bb0af84</anchor>
      <arglist>(VlArray *self, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_init_matrix_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>aaace92daf56a02734d0ef6079ee71f50</anchor>
      <arglist>(VlArray *self, void *data, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a78e0f4b38bafedfe0ef31f5ad1d18dad</anchor>
      <arglist>(vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a67b31b72d500e04d66894be78d3f08cb</anchor>
      <arglist>(void *data, vl_type type, vl_size numDimension, vl_size const *dimensions)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_matrix</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>ab0bb77833389b149bd15e4fc91f6f63e</anchor>
      <arglist>(vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>VlArray *</type>
      <name>vl_array_new_matrix_envelope</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a1a3af13a5d54bdbb2d436ed878a67d90</anchor>
      <arglist>(void *data, vl_type type, vl_size numRows, vl_size numColumns)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_array_dealloc</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a22469f7d3a16d6bd56025330c87c351e</anchor>
      <arglist>(VlArray *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_array_delete</name>
      <anchorfile>array_8h.html</anchorfile>
      <anchor>a32a8f1faf1c01c33c762b5a607a53582</anchor>
      <arglist>(VlArray *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>covdet.c</name>
    <path>vl/</path>
    <filename>covdet_8c.html</filename>
    <includes id="covdet_8h" name="covdet.h" local="yes" import="no" module="no" objc="no">covdet.h</includes>
    <class kind="struct">_VlCovDet</class>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>_vl_resize_buffer</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a9115190fadfffd887d24132ea02954f7</anchor>
      <arglist>(void **buffer, vl_size *bufferSize, vl_size targetSize)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>_vl_enlarge_buffer</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>afb3bdb49a23d115dafa953f2be5f87c0</anchor>
      <arglist>(void **buffer, vl_size *bufferSize, vl_size targetSize)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_find_local_extrema_3</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>af951de09ebfe2adfb18887be739ed73e</anchor>
      <arglist>(vl_index **extrema, vl_size *bufferSize, float const *map, vl_size width, vl_size height, vl_size depth, double threshold)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_find_local_extrema_2</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a9a6be0521775a458c2d7f7566488cb5c</anchor>
      <arglist>(vl_index **extrema, vl_size *bufferSize, float const  *map, vl_size width, vl_size height, double threshold)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_refine_local_extreum_3</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a6eb190e7eb77268734e56bb9a8773f30</anchor>
      <arglist>(VlCovDetExtremum3 *refined, float const *map, vl_size width, vl_size height, vl_size depth, vl_index x, vl_index y, vl_index z)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_refine_local_extreum_2</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a98a72bd26a4cb59bb9899e9cffc32bd3</anchor>
      <arglist>(VlCovDetExtremum2 *refined, float const *map, vl_size width, vl_size height, vl_index x, vl_index y)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDet *</type>
      <name>vl_covdet_new</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ab9a4060af83564ca36cc55ce8cbfa790</anchor>
      <arglist>(VlCovDetMethod method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_reset</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a7cfe6bd396893127c69f02f189e7f359</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_delete</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a7abfa72a8bb2a05c12376052c29ea17f</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_append_feature</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>af266ce65ae19bff2c5d9ef1ad499b5fd</anchor>
      <arglist>(VlCovDet *self, VlCovDetFeature const *feature)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_put_image</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>affcedda1fdc7ed72d223e0aab003024e</anchor>
      <arglist>(VlCovDet *self, float const *image, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_det_hessian_response</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ad9b4be768992adb630dbaa53698f4b71</anchor>
      <arglist>(float *hessian, float const *image, vl_size width, vl_size height, double step, double sigma)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_harris_response</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ad32aecc30ae52c6d666935b655ea0881</anchor>
      <arglist>(float *harris, float const *image, vl_size width, vl_size height, double step, double sigma, double sigmaI, double alpha)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_dog_response</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a953455b468b827819e8586e5f1a859b2</anchor>
      <arglist>(float *dog, float const *level1, float const *level2, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_detect</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>abfe553fdb25132cbcf9cbb08839b7f98</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_extract_patch_helper</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a8cc86041f081986e633e621272ee9218</anchor>
      <arglist>(VlCovDet *self, double *sigma1, double *sigma2, float *patch, vl_size resolution, double extent, double sigma, double A_[4], double T_[2], double d1, double d2)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_extract_patch_for_frame</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a5332ef1f0e09654f5787c19e156404a9</anchor>
      <arglist>(VlCovDet *self, float *patch, vl_size resolution, double extent, double sigma, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_extract_affine_shape_for_frame</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ad3c1402a759e6056b6bd58a27ba4799c</anchor>
      <arglist>(VlCovDet *self, VlFrameOrientedEllipse *adapted, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_affine_shape</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>aee6fc0f35fb23b32e558e8d0131abb96</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureOrientation *</type>
      <name>vl_covdet_extract_orientations_for_frame</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a6c8b0db407312ad21c9dd9b29cf40d69</anchor>
      <arglist>(VlCovDet *self, vl_size *numOrientations, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_orientations</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a0f9823a4cffd55760cf6c16352381f1a</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureLaplacianScale *</type>
      <name>vl_covdet_extract_laplacian_scales_for_frame</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>af65611417c4e7e843d76811837e78a99</anchor>
      <arglist>(VlCovDet *self, vl_size *numScales, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_laplacian_scales</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a1858e75418d7c6364a66bbbd8899fdd6</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_drop_features_outside</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a614fd4d42d8d2c938c945c76a544680f</anchor>
      <arglist>(VlCovDet *self, double margin)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_transposed</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a55d10412a55bc52e6468f347daa84c2d</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_transposed</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>aca7fefc61bf17249380bef9410e0b2b2</anchor>
      <arglist>(VlCovDet *self, vl_bool t)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_edge_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>acd380e24e7525b6c5bc2dfa656d7a9b2</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_edge_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a16e0f9b96b16727a1bcec2df7bff0017</anchor>
      <arglist>(VlCovDet *self, double edgeThreshold)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_peak_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a4fd154b4600ca2bf32b87adf77f62825</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_peak_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>afcbfb9f6cade3f20bf429cd520b9cee8</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_laplacian_peak_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a997689d5bf1078028223ebad6f1f0626</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_laplacian_peak_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a214c8968e436f281f70532fa85b54043</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>vl_index</type>
      <name>vl_covdet_get_first_octave</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ab06c5d750facf9105d6e3036c1ba40bb</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_first_octave</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>af51d1a729e1611201ae7208a1144b8d8</anchor>
      <arglist>(VlCovDet *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_octaves</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ad3247e72c38a9c713aecc0752468f954</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_base_scale</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>af57b014275578f5d4513a65b0523ac11</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_num_octaves</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a234342d7c689f6d16e30e5b8433f3170</anchor>
      <arglist>(VlCovDet *self, vl_size o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_base_scale</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a83fcd4f56f9ced56232b58d13f869c02</anchor>
      <arglist>(VlCovDet *self, double s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_max_num_orientations</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a1064241f872090d4ba32c8a7de9dc89b</anchor>
      <arglist>(VlCovDet *self, vl_size m)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_octave_resolution</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a9ccdfbf6b9fbfa01429ed2713c555846</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_octave_resolution</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a3ab247f8ce822636bb32ccd48c753a1d</anchor>
      <arglist>(VlCovDet *self, vl_size r)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_aa_accurate_smoothing</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ad91ad31d5ca752e14c351e9cffbde68c</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_aa_accurate_smoothing</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a8573f2724701397d5684e0dfbc987423</anchor>
      <arglist>(VlCovDet *self, vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_max_num_orientations</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ab921cc0292adf7c88b17ec7426d2bdd8</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a68dbea737c1c5ced8590b0b6ae66a3ad</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a50bd5cc5eb6584f585d0bf7af8feff2f</anchor>
      <arglist>(VlCovDet *self, double x)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_non_extrema_suppressed</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a6e2c647eb87bea3d0935734acd2ba8f5</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_features</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a463ed222516fe046e8b170e3d3c06585</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_covdet_get_features</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a44e0bd8bf35247972dd663d79d991555</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_gss</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a05ef092a1eb34af3bd46e13344be1f40</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_css</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>ab0801070e67a2f32a8edb4dd32c96605</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size const *</type>
      <name>vl_covdet_get_laplacian_scales_statistics</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>adbacfe11137ac9a842ee0409a32d74a3</anchor>
      <arglist>(VlCovDet const *self, vl_size *numScales)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_allow_padded_warping</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a1dff0f21a42e510718b35c5020204ca0</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_allow_padded_warping</name>
      <anchorfile>covdet_8c.html</anchorfile>
      <anchor>a1d121b6a8ab2f8a6bda93336731b3b7d</anchor>
      <arglist>(VlCovDet *self, vl_bool t)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>covdet.h</name>
    <path>vl/</path>
    <filename>covdet_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="stringop_8h" name="stringop.h" local="yes" import="no" module="no" objc="no">stringop.h</includes>
    <includes id="scalespace_8h" name="scalespace.h" local="yes" import="no" module="no" objc="no">scalespace.h</includes>
    <class kind="struct">VlFrameDisc</class>
    <class kind="struct">VlFrameOrientedDisc</class>
    <class kind="struct">VlFrameEllipse</class>
    <class kind="struct">VlFrameOrientedEllipse</class>
    <class kind="struct">VlCovDetFeature</class>
    <class kind="struct">VlCovDetFeatureOrientation</class>
    <class kind="struct">VlCovDetFeatureLaplacianScale</class>
    <class kind="struct">_VlCovDet</class>
    <member kind="function">
      <type>VlCovDet *</type>
      <name>vl_covdet_new</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab9a4060af83564ca36cc55ce8cbfa790</anchor>
      <arglist>(VlCovDetMethod method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_delete</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a7abfa72a8bb2a05c12376052c29ea17f</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_reset</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a7cfe6bd396893127c69f02f189e7f359</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_put_image</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>affcedda1fdc7ed72d223e0aab003024e</anchor>
      <arglist>(VlCovDet *self, float const *image, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_detect</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>abfe553fdb25132cbcf9cbb08839b7f98</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_append_feature</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af266ce65ae19bff2c5d9ef1ad499b5fd</anchor>
      <arglist>(VlCovDet *self, VlCovDetFeature const *feature)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a0f9823a4cffd55760cf6c16352381f1a</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_laplacian_scales</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1858e75418d7c6364a66bbbd8899fdd6</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_affine_shape</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>aee6fc0f35fb23b32e558e8d0131abb96</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureOrientation *</type>
      <name>vl_covdet_extract_orientations_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a6c8b0db407312ad21c9dd9b29cf40d69</anchor>
      <arglist>(VlCovDet *self, vl_size *numOrientations, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureLaplacianScale *</type>
      <name>vl_covdet_extract_laplacian_scales_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af65611417c4e7e843d76811837e78a99</anchor>
      <arglist>(VlCovDet *self, vl_size *numScales, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_extract_affine_shape_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad3c1402a759e6056b6bd58a27ba4799c</anchor>
      <arglist>(VlCovDet *self, VlFrameOrientedEllipse *adapted, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_extract_patch_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a5332ef1f0e09654f5787c19e156404a9</anchor>
      <arglist>(VlCovDet *self, float *patch, vl_size resolution, double extent, double sigma, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_drop_features_outside</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a614fd4d42d8d2c938c945c76a544680f</anchor>
      <arglist>(VlCovDet *self, double margin)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_features</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a463ed222516fe046e8b170e3d3c06585</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_covdet_get_features</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a44e0bd8bf35247972dd663d79d991555</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_index</type>
      <name>vl_covdet_get_first_octave</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab06c5d750facf9105d6e3036c1ba40bb</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_octaves</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad3247e72c38a9c713aecc0752468f954</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_base_scale</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af57b014275578f5d4513a65b0523ac11</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_octave_resolution</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a9ccdfbf6b9fbfa01429ed2713c555846</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a4fd154b4600ca2bf32b87adf77f62825</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_edge_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>acd380e24e7525b6c5bc2dfa656d7a9b2</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_max_num_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab921cc0292adf7c88b17ec7426d2bdd8</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_transposed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a55d10412a55bc52e6468f347daa84c2d</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_gss</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a05ef092a1eb34af3bd46e13344be1f40</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_css</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab0801070e67a2f32a8edb4dd32c96605</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_aa_accurate_smoothing</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad91ad31d5ca752e14c351e9cffbde68c</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size const *</type>
      <name>vl_covdet_get_laplacian_scales_statistics</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>adbacfe11137ac9a842ee0409a32d74a3</anchor>
      <arglist>(VlCovDet const *self, vl_size *numScales)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a68dbea737c1c5ced8590b0b6ae66a3ad</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_non_extrema_suppressed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a6e2c647eb87bea3d0935734acd2ba8f5</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_allow_padded_warping</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1dff0f21a42e510718b35c5020204ca0</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_first_octave</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af51d1a729e1611201ae7208a1144b8d8</anchor>
      <arglist>(VlCovDet *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_num_octaves</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a234342d7c689f6d16e30e5b8433f3170</anchor>
      <arglist>(VlCovDet *self, vl_size o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_base_scale</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a83fcd4f56f9ced56232b58d13f869c02</anchor>
      <arglist>(VlCovDet *self, double s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_octave_resolution</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a3ab247f8ce822636bb32ccd48c753a1d</anchor>
      <arglist>(VlCovDet *self, vl_size r)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afcbfb9f6cade3f20bf429cd520b9cee8</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_edge_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a16e0f9b96b16727a1bcec2df7bff0017</anchor>
      <arglist>(VlCovDet *self, double edgeThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_laplacian_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a214c8968e436f281f70532fa85b54043</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_max_num_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1064241f872090d4ba32c8a7de9dc89b</anchor>
      <arglist>(VlCovDet *self, vl_size m)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_transposed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>aca7fefc61bf17249380bef9410e0b2b2</anchor>
      <arglist>(VlCovDet *self, vl_bool t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_aa_accurate_smoothing</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a8573f2724701397d5684e0dfbc987423</anchor>
      <arglist>(VlCovDet *self, vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a50bd5cc5eb6584f585d0bf7af8feff2f</anchor>
      <arglist>(VlCovDet *self, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_allow_padded_warping</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a89e1127e52b07376f29804b0f59f7f3c</anchor>
      <arglist>(VlCovDet *self, vl_bool x)</arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlFrameType</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afbadee402b023a061620226e2f4bb45e</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_FRAMETYPE_DISC</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afbadee402b023a061620226e2f4bb45ea7dc9a8930f7f37eedc693977464b3fd4</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_FRAMETYPE_ORIENTED_DISC</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afbadee402b023a061620226e2f4bb45ea18b389125522f1c5944e5d1d07edb218</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_FRAMETYPE_ELLIPSE</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afbadee402b023a061620226e2f4bb45ea6145863075f58a45373a3f72a7f411a9</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_FRAMETYPE_ORIENTED_ELLIPSE</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afbadee402b023a061620226e2f4bb45ea5d51e0a1b4f08d13e50e689b990a7a87</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlCovDetMethod</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a29fcb6ced2bee0db21c3c3f81a54477e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>const char *</type>
      <name>vlFrameNames</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ac0451e3eeb39245382946810e492424f</anchor>
      <arglist>[VL_FRAMETYPE_NUM]</arglist>
    </member>
    <member kind="variable">
      <type>VlEnumerator</type>
      <name>vlFrameTypes</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad61cfa115e5bbc18bcf10ac1ae1c18a2</anchor>
      <arglist>[VL_FRAMETYPE_NUM]</arglist>
    </member>
    <member kind="variable">
      <type>VlEnumerator</type>
      <name>vlCovdetMethods</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a5498a8ca2643970858426c50a847f363</anchor>
      <arglist>[VL_COVDET_METHOD_NUM]</arglist>
    </member>
    <member kind="variable">
      <type>struct _VlCovDet</type>
      <name>VlCovDet</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ac9ee6b09d1b6ace81783ecbb4de7303c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_frame_size</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad245e479a99d398bfed34aa892530a23</anchor>
      <arglist>(VlFrameType frameType)</arglist>
    </member>
    <member kind="function">
      <type>VlFrameType</type>
      <name>vl_get_frame_type</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a3dfa5e94c79c5dd14013eb075db487bf</anchor>
      <arglist>(vl_bool affineAdaptation, vl_bool orientation)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDet *</type>
      <name>vl_covdet_new</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab9a4060af83564ca36cc55ce8cbfa790</anchor>
      <arglist>(VlCovDetMethod method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_delete</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a7abfa72a8bb2a05c12376052c29ea17f</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_reset</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a7cfe6bd396893127c69f02f189e7f359</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_put_image</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>affcedda1fdc7ed72d223e0aab003024e</anchor>
      <arglist>(VlCovDet *self, float const *image, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_detect</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>abfe553fdb25132cbcf9cbb08839b7f98</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_append_feature</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af266ce65ae19bff2c5d9ef1ad499b5fd</anchor>
      <arglist>(VlCovDet *self, VlCovDetFeature const *feature)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a0f9823a4cffd55760cf6c16352381f1a</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_laplacian_scales</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1858e75418d7c6364a66bbbd8899fdd6</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_extract_affine_shape</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>aee6fc0f35fb23b32e558e8d0131abb96</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureOrientation *</type>
      <name>vl_covdet_extract_orientations_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a6c8b0db407312ad21c9dd9b29cf40d69</anchor>
      <arglist>(VlCovDet *self, vl_size *numOrientations, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>VlCovDetFeatureLaplacianScale *</type>
      <name>vl_covdet_extract_laplacian_scales_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af65611417c4e7e843d76811837e78a99</anchor>
      <arglist>(VlCovDet *self, vl_size *numScales, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_covdet_extract_affine_shape_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad3c1402a759e6056b6bd58a27ba4799c</anchor>
      <arglist>(VlCovDet *self, VlFrameOrientedEllipse *adapted, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_extract_patch_for_frame</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a5332ef1f0e09654f5787c19e156404a9</anchor>
      <arglist>(VlCovDet *self, float *patch, vl_size resolution, double extent, double sigma, VlFrameOrientedEllipse frame)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_drop_features_outside</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a614fd4d42d8d2c938c945c76a544680f</anchor>
      <arglist>(VlCovDet *self, double margin)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_features</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a463ed222516fe046e8b170e3d3c06585</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_covdet_get_features</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a44e0bd8bf35247972dd663d79d991555</anchor>
      <arglist>(VlCovDet *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_index</type>
      <name>vl_covdet_get_first_octave</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab06c5d750facf9105d6e3036c1ba40bb</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_octaves</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad3247e72c38a9c713aecc0752468f954</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_base_scale</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af57b014275578f5d4513a65b0523ac11</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_octave_resolution</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a9ccdfbf6b9fbfa01429ed2713c555846</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a4fd154b4600ca2bf32b87adf77f62825</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_edge_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>acd380e24e7525b6c5bc2dfa656d7a9b2</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_max_num_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab921cc0292adf7c88b17ec7426d2bdd8</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_transposed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a55d10412a55bc52e6468f347daa84c2d</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_gss</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a05ef092a1eb34af3bd46e13344be1f40</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_covdet_get_css</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ab0801070e67a2f32a8edb4dd32c96605</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_aa_accurate_smoothing</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>ad91ad31d5ca752e14c351e9cffbde68c</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size const *</type>
      <name>vl_covdet_get_laplacian_scales_statistics</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>adbacfe11137ac9a842ee0409a32d74a3</anchor>
      <arglist>(VlCovDet const *self, vl_size *numScales)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_covdet_get_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a68dbea737c1c5ced8590b0b6ae66a3ad</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_covdet_get_num_non_extrema_suppressed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a6e2c647eb87bea3d0935734acd2ba8f5</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_covdet_get_allow_padded_warping</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1dff0f21a42e510718b35c5020204ca0</anchor>
      <arglist>(VlCovDet const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_first_octave</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>af51d1a729e1611201ae7208a1144b8d8</anchor>
      <arglist>(VlCovDet *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_num_octaves</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a234342d7c689f6d16e30e5b8433f3170</anchor>
      <arglist>(VlCovDet *self, vl_size o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_base_scale</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a83fcd4f56f9ced56232b58d13f869c02</anchor>
      <arglist>(VlCovDet *self, double s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_octave_resolution</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a3ab247f8ce822636bb32ccd48c753a1d</anchor>
      <arglist>(VlCovDet *self, vl_size r)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>afcbfb9f6cade3f20bf429cd520b9cee8</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_edge_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a16e0f9b96b16727a1bcec2df7bff0017</anchor>
      <arglist>(VlCovDet *self, double edgeThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_laplacian_peak_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a214c8968e436f281f70532fa85b54043</anchor>
      <arglist>(VlCovDet *self, double peakThreshold)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_max_num_orientations</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a1064241f872090d4ba32c8a7de9dc89b</anchor>
      <arglist>(VlCovDet *self, vl_size m)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_transposed</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>aca7fefc61bf17249380bef9410e0b2b2</anchor>
      <arglist>(VlCovDet *self, vl_bool t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_aa_accurate_smoothing</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a8573f2724701397d5684e0dfbc987423</anchor>
      <arglist>(VlCovDet *self, vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_non_extrema_suppression_threshold</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a50bd5cc5eb6584f585d0bf7af8feff2f</anchor>
      <arglist>(VlCovDet *self, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_covdet_set_allow_padded_warping</name>
      <anchorfile>covdet_8h.html</anchorfile>
      <anchor>a89e1127e52b07376f29804b0f59f7f3c</anchor>
      <arglist>(VlCovDet *self, vl_bool x)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>dsift.c</name>
    <path>vl/</path>
    <filename>dsift_8c.html</filename>
    <includes id="dsift_8h" name="dsift.h" local="yes" import="no" module="no" objc="no">dsift.h</includes>
    <includes id="pgm_8h" name="pgm.h" local="yes" import="no" module="no" objc="no">pgm.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <member kind="function">
      <type>float *</type>
      <name>_vl_dsift_new_kernel</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a1bccbdabd349ba105eedb978fac29719</anchor>
      <arglist>(int binSize, int numBins, int binIndex, double windowSize)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>_vl_dsift_normalize_histogram</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a79f9ffc851983f7e26f09b9ed1c43813</anchor>
      <arglist>(float *begin, float *end)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_dsift_free_buffers</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a85a2ddc18108b83931d3cb7c66e7b382</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_dsift_update_buffers</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>af83ee4f65210d5f4476a39167802ec97</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_dsift_alloc_buffers</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a8b3119bdf4dd078826d1fa70231184fe</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftFilter *</type>
      <name>vl_dsift_new</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>af64de03d751b58997592217b40d8e7a7</anchor>
      <arglist>(int imWidth, int imHeight)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftFilter *</type>
      <name>vl_dsift_new_basic</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a482bbcc4eba519011f8f784c7cea82f3</anchor>
      <arglist>(int imWidth, int imHeight, int step, int binSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_delete</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>aa123f1d9e79ab01882646f713dfb4f0c</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_dsift_with_gaussian_window</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>ac4c6be3c85911ea7493faa841349aff7</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_dsift_with_flat_window</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a52dc36ae1f1a09fd8fa3978f973e763d</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_process</name>
      <anchorfile>dsift_8c.html</anchorfile>
      <anchor>a09d5525ad7e16e2b9f3f1b9d273c85f6</anchor>
      <arglist>(VlDsiftFilter *self, float const *im)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>dsift.h</name>
    <path>vl/</path>
    <filename>dsift_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlDsiftKeypoint</class>
    <class kind="struct">VlDsiftDescriptorGeometry</class>
    <class kind="struct">VlDsiftFilter</class>
    <member kind="function">
      <type>VlDsiftFilter *</type>
      <name>vl_dsift_new</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>accf2dec4b3dfc2bda842a826a7e09381</anchor>
      <arglist>(int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftFilter *</type>
      <name>vl_dsift_new_basic</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a9f5d83ab20ca277423e3f0d25f750194</anchor>
      <arglist>(int width, int height, int step, int binSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_delete</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>aa123f1d9e79ab01882646f713dfb4f0c</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_process</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a09d5525ad7e16e2b9f3f1b9d273c85f6</anchor>
      <arglist>(VlDsiftFilter *self, float const *im)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_transpose_descriptor</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>abf6a55498f4385dcb9ead862a8477e6b</anchor>
      <arglist>(float *dst, float const  *src, int numBinT, int numBinX, int numBinY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_dsift_update_buffers</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>af83ee4f65210d5f4476a39167802ec97</anchor>
      <arglist>(VlDsiftFilter *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_steps</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a42ae6bf77a9b737fd1e45ad5c43263dd</anchor>
      <arglist>(VlDsiftFilter *self, int stepX, int stepY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_bounds</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a7d34c8e257c873f2ed580b046296d1ac</anchor>
      <arglist>(VlDsiftFilter *self, int minX, int minY, int maxX, int maxY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_geometry</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a930f20c25eab08d9490830b0a358ff2b</anchor>
      <arglist>(VlDsiftFilter *self, VlDsiftDescriptorGeometry const *geom)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_flat_window</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a8dfe2d20dbe9885d0c139c5b81b5f4b0</anchor>
      <arglist>(VlDsiftFilter *self, vl_bool useFlatWindow)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_window_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>ae60fa31ff4df09e8025525714dac9563</anchor>
      <arglist>(VlDsiftFilter *self, double windowSize)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_dsift_get_descriptors</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a06f036e38fb68d2237dd60efb6f21236</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_dsift_get_descriptor_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>aeade8b18c21954f00d76f5dcb12b9bfe</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_dsift_get_keypoint_num</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a3b5fabb1496fc91a70669d4201f47a5b</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftKeypoint const *</type>
      <name>vl_dsift_get_keypoints</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a5b586c60d079a65ded73c4fd2387d6bf</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_get_bounds</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a92580ab01e5fb7967b1fa69abde717d0</anchor>
      <arglist>(VlDsiftFilter const  *self, int *minX, int *minY, int *maxX, int *maxY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_get_steps</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>ac2ba5f78ac2675e547a4ef36c1bf4654</anchor>
      <arglist>(VlDsiftFilter const  *self, int *stepX, int *stepY)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftDescriptorGeometry const *</type>
      <name>vl_dsift_get_geometry</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a05dc468116dc64d75b45853ead4c5031</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_dsift_get_flat_window</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a36450893fad7e5d9bb4ea003b05ea6d2</anchor>
      <arglist>(VlDsiftFilter const  *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_dsift_get_window_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>afa8d4a02e6f7a0d8b89b585c689e164e</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_steps</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a42ae6bf77a9b737fd1e45ad5c43263dd</anchor>
      <arglist>(VlDsiftFilter *self, int stepX, int stepY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_bounds</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a7d34c8e257c873f2ed580b046296d1ac</anchor>
      <arglist>(VlDsiftFilter *self, int minX, int minY, int maxX, int maxY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_geometry</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a930f20c25eab08d9490830b0a358ff2b</anchor>
      <arglist>(VlDsiftFilter *self, VlDsiftDescriptorGeometry const *geom)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_flat_window</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a8dfe2d20dbe9885d0c139c5b81b5f4b0</anchor>
      <arglist>(VlDsiftFilter *self, vl_bool useFlatWindow)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_set_window_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>ae60fa31ff4df09e8025525714dac9563</anchor>
      <arglist>(VlDsiftFilter *self, double windowSize)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_dsift_get_descriptors</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a06f036e38fb68d2237dd60efb6f21236</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_dsift_get_descriptor_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>aeade8b18c21954f00d76f5dcb12b9bfe</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_dsift_get_keypoint_num</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a3b5fabb1496fc91a70669d4201f47a5b</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftKeypoint const *</type>
      <name>vl_dsift_get_keypoints</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a5b586c60d079a65ded73c4fd2387d6bf</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_get_bounds</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a92580ab01e5fb7967b1fa69abde717d0</anchor>
      <arglist>(VlDsiftFilter const  *self, int *minX, int *minY, int *maxX, int *maxY)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_dsift_get_steps</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>ac2ba5f78ac2675e547a4ef36c1bf4654</anchor>
      <arglist>(VlDsiftFilter const  *self, int *stepX, int *stepY)</arglist>
    </member>
    <member kind="function">
      <type>VlDsiftDescriptorGeometry const *</type>
      <name>vl_dsift_get_geometry</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a05dc468116dc64d75b45853ead4c5031</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_dsift_get_flat_window</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>a36450893fad7e5d9bb4ea003b05ea6d2</anchor>
      <arglist>(VlDsiftFilter const  *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_dsift_get_window_size</name>
      <anchorfile>dsift_8h.html</anchorfile>
      <anchor>afa8d4a02e6f7a0d8b89b585c689e164e</anchor>
      <arglist>(VlDsiftFilter const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>fisher.c</name>
    <path>vl/</path>
    <filename>fisher_8c.html</filename>
    <includes id="fisher_8h" name="fisher.h" local="yes" import="no" module="no" objc="no">fisher.h</includes>
    <includes id="gmm_8h" name="gmm.h" local="yes" import="no" module="no" objc="no">gmm.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_fisher_encode</name>
      <anchorfile>fisher_8c.html</anchorfile>
      <anchor>a4c13fe11e9847f9046c2636a6e77c1bd</anchor>
      <arglist>(void *enc, vl_type dataType, void const *means, vl_size dimension, vl_size numClusters, void const *covariances, void const *priors, void const *data, vl_size numData, int flags)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>fisher.h</name>
    <path>vl/</path>
    <filename>fisher_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_SQUARE_ROOT</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>ac25863013987b97998d64b9f0695c223</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_NORMALIZED</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>aca9b5a03e0c6ff578cee1268f725afa5</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_IMPROVED</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>a73052d0cb0678620a8d52f97eada233c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_FAST</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>aaa8a24c2d002294897dcd82f1d9456b5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_fisher_encode</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>a4c13fe11e9847f9046c2636a6e77c1bd</anchor>
      <arglist>(void *enc, vl_type dataType, void const *means, vl_size dimension, vl_size numClusters, void const *covariances, void const *priors, void const *data, vl_size numData, int flags)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_SQUARE_ROOT</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>ac25863013987b97998d64b9f0695c223</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_NORMALIZED</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>aca9b5a03e0c6ff578cee1268f725afa5</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_IMPROVED</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>a73052d0cb0678620a8d52f97eada233c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FISHER_FLAG_FAST</name>
      <anchorfile>fisher_8h.html</anchorfile>
      <anchor>aaa8a24c2d002294897dcd82f1d9456b5</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>generic.c</name>
    <path>vl/</path>
    <filename>generic_8c.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="function">
      <type>VlState *</type>
      <name>vl_get_state</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>abccc32c43986a62ed389572157c768cc</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>VlThreadState *</type>
      <name>vl_get_thread_specific_state</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a6c4407682ab9d2e18d83bf7b45ec2f2e</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_lock_state</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aa4922f5efbe6b13c2527b1fcc6fc833a</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_unlock_state</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aa5589c034e06c5965ad91cdf2467dffd</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static VlThreadState *</type>
      <name>vl_thread_specific_state_new</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a6f7d17a2292676f8d6c88718578087e9</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_thread_specific_state_delete</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aecf02e838af9ff971eca81a427c64165</anchor>
      <arglist>(VlThreadState *self)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_version_string</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ac484fa1024773f68845e249c9939f424</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_configuration_to_string_copy</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a87117aad7c7163dc135f543304c0beeb</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>do_nothing_printf</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ad4772f51849960d0d88e434a157fbceb</anchor>
      <arglist>(char const *format,...)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_num_cpus</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a49f59f6c5355c146c8fae8959b7da782</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_simd_enabled</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a57a5db4e3647ce66b3c22741928a291a</anchor>
      <arglist>(vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_get_simd_enabled</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ac4090b5a1fac0a0bc6e42cc1a7d77047</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_avx</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>accbf3c00c4b86e465acb28d746a92f58</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_sse3</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a84aadf91644a01036d3718fe595f5a26</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_sse2</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ad2cf9346f3895f26bb7f05b5917614c9</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_thread_limit</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a426a9313eef611543f45fd3faaa9b343</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_max_threads</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a2d38f8e7475ddb8f1e106e2b7495d28f</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_num_threads</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a3e410efeeb102664d7b98417c8b5806c</anchor>
      <arglist>(vl_size numThreads)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_set_last_error</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a7a3ebca801573280aafbea04578ef124</anchor>
      <arglist>(int error, char const *errorMessage,...)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_get_last_error</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aa5d08848df8c025fadd5430c8a6cb0e2</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_last_error_message</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a6678ce547dc4da09bf5d63555fa9c0ea</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_alloc_func</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ac04fe278ac908fa6ed02bda099588cf0</anchor>
      <arglist>(void *(*malloc_func)(size_t), void *(*realloc_func)(void *, size_t), void *(*calloc_func)(size_t, size_t), void(*free_func)(void *))</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_malloc</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a136474bd173eb04e98989c7a521d4ada</anchor>
      <arglist>(size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_realloc</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a6213d08692fb90f0a0eaa423644f25c2</anchor>
      <arglist>(void *ptr, size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_calloc</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a175a5268fe40a4e3c68e6fab63ed064b</anchor>
      <arglist>(size_t n, size_t size)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_free</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>ae070a0a4d3d367a1ba8308644c88ada3</anchor>
      <arglist>(void *ptr)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_printf_func</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a17ef7f5dfc74e0ff032f46617a5bc1c5</anchor>
      <arglist>(printf_func_t printf_func)</arglist>
    </member>
    <member kind="function">
      <type>printf_func_t</type>
      <name>vl_get_printf_func</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>afeb1328b069d33541dc21ea859b02d0a</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_get_cpu_time</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a4a2af50f50dfc91505947ced9656f5e7</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_tic</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>acc7e28d60e21ecef6e3f5d83b850b34b</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_toc</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a429bff43a8deafa7c2ce016932738cd6</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>VlRand *</type>
      <name>vl_get_rand</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aa4712bf966aec4c90e97e0897fc2241a</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_constructor</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>a1af550f58b02cee55be9c0b8a3bddee2</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_destructor</name>
      <anchorfile>generic_8c.html</anchorfile>
      <anchor>aa3d76b59c0a5e7c45f80e172ec042c93</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>generic.h</name>
    <path>vl/</path>
    <filename>generic_8h.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_VERSION_STRING</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aa53b45e68c7ce79c6fc539e64ba027a6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_MSG_LEN</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>af35e10968d642caab4fbffe6f4b0789c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_MIN</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a36f2f85796040ca2f71bb34a9f55969f</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_MAX</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac8a3f4020a3e381daadd4214668dc63c</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHIFT_LEFT</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aee17b425e4672e582e26cf9e103fc0fb</anchor>
      <arglist>(x, n)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_version_string</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a21873db436e8ad3710486c1bb5d2b183</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_configuration_to_string_copy</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aff40f4feb7c9c61dcaf1173a26d58e67</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_simd_enabled</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a3fb6cee731450d886e49da54e29788e8</anchor>
      <arglist>(vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_get_simd_enabled</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac4090b5a1fac0a0bc6e42cc1a7d77047</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_avx</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>accbf3c00c4b86e465acb28d746a92f58</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_sse3</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a84aadf91644a01036d3718fe595f5a26</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_cpu_has_sse2</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ad2cf9346f3895f26bb7f05b5917614c9</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_num_cpus</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a49f59f6c5355c146c8fae8959b7da782</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>VlRand *</type>
      <name>vl_get_rand</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aa4712bf966aec4c90e97e0897fc2241a</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_max_threads</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a2d38f8e7475ddb8f1e106e2b7495d28f</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_num_threads</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>adbbde4d47763c8e581640b23db5b6a1a</anchor>
      <arglist>(vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_thread_limit</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a426a9313eef611543f45fd3faaa9b343</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_alloc_func</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac04fe278ac908fa6ed02bda099588cf0</anchor>
      <arglist>(void *(*malloc_func)(size_t), void *(*realloc_func)(void *, size_t), void *(*calloc_func)(size_t, size_t), void(*free_func)(void *))</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_malloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a136474bd173eb04e98989c7a521d4ada</anchor>
      <arglist>(size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_realloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a6213d08692fb90f0a0eaa423644f25c2</anchor>
      <arglist>(void *ptr, size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_calloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a175a5268fe40a4e3c68e6fab63ed064b</anchor>
      <arglist>(size_t n, size_t size)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_free</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ae070a0a4d3d367a1ba8308644c88ada3</anchor>
      <arglist>(void *ptr)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_tic</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>acc7e28d60e21ecef6e3f5d83b850b34b</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_toc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a429bff43a8deafa7c2ce016932738cd6</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_get_cpu_time</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a49738f9f66a6a6d8a70dbe712ab1f697</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_FLOAT</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aa034d0b942f9800b2a02aeb30ff10fa2</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_DOUBLE</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a41d6691dac0cc3648ca9701d27e5d2b0</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_INT8</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a90ea396337523c32c3022f358196ccc9</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_UINT8</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a4db234bb60c94d6f562f8e9ce3b1795e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_INT16</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a4eb25b91045f880c1d10e609174d3f5c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_UINT16</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a2e47aef4fdd2aa9f388fd2adfc36f4b1</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_INT32</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a4ca0c2adc987dcb7f57a7de7893f5b7c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_UINT32</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac1ca77a71afce483185fbd23f4df9ec7</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_INT64</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a873cea95408414b33bc0d0af250caf5e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TYPE_UINT64</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ace055d33cb1d7f213bfc0b3a55b86fa2</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_type_name</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac61da98ae51637b9dc8b829b96eca96a</anchor>
      <arglist>(vl_type type)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_type_size</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a477016b861e56130cfb95fe7085138d9</anchor>
      <arglist>(vl_type type)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_OK</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a26519a3dd2966d2d46538eb46921abba</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_OVERFLOW</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aad375cc4dcec5d098a94d072b6c5b3d4</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_ALLOC</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a0a05979eb0e5e1bb8edd1d6992d73f5f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_BAD_ARG</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aa4c6982fd95a25fca8ec202632581345</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_IO</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aba78f9bc7029f3e8f69e502ef10a1ea2</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_EOF</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a67cc69e40d7af2aec137b36e53422982</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_NO_MORE</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a28c5e84bca772be393e834dfff61b22d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_get_last_error</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aa5d08848df8c025fadd5430c8a6cb0e2</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_last_error_message</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a6678ce547dc4da09bf5d63555fa9c0ea</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_set_last_error</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a7a3ebca801573280aafbea04578ef124</anchor>
      <arglist>(int error, char const *errorMessage,...)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PRINTF</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>af68d1c6327bf2226b15c84007eab3d94</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PRINT</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a1d4b7e68329e078b0d9064b7f408c96b</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>int(*</type>
      <name>printf_func_t</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a2ec0ef25b7502f3d671796dfbe19acda</anchor>
      <arglist>)(char const *format,...)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_printf_func</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a17ef7f5dfc74e0ff032f46617a5bc1c5</anchor>
      <arglist>(printf_func_t printf_func)</arglist>
    </member>
    <member kind="function">
      <type>printf_func_t</type>
      <name>vl_get_printf_func</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>afeb1328b069d33541dc21ea859b02d0a</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_MIN</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a36f2f85796040ca2f71bb34a9f55969f</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_MAX</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac8a3f4020a3e381daadd4214668dc63c</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHIFT_LEFT</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>aee17b425e4672e582e26cf9e103fc0fb</anchor>
      <arglist>(x, n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_max_threads</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a2d38f8e7475ddb8f1e106e2b7495d28f</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_num_threads</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>adbbde4d47763c8e581640b23db5b6a1a</anchor>
      <arglist>(vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_get_thread_limit</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a426a9313eef611543f45fd3faaa9b343</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_set_alloc_func</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ac04fe278ac908fa6ed02bda099588cf0</anchor>
      <arglist>(void *(*malloc_func)(size_t), void *(*realloc_func)(void *, size_t), void *(*calloc_func)(size_t, size_t), void(*free_func)(void *))</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_malloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a136474bd173eb04e98989c7a521d4ada</anchor>
      <arglist>(size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_realloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a6213d08692fb90f0a0eaa423644f25c2</anchor>
      <arglist>(void *ptr, size_t n)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_calloc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a175a5268fe40a4e3c68e6fab63ed064b</anchor>
      <arglist>(size_t n, size_t size)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_free</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>ae070a0a4d3d367a1ba8308644c88ada3</anchor>
      <arglist>(void *ptr)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_tic</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>acc7e28d60e21ecef6e3f5d83b850b34b</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_toc</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a429bff43a8deafa7c2ce016932738cd6</anchor>
      <arglist>(void)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_get_cpu_time</name>
      <anchorfile>generic_8h.html</anchorfile>
      <anchor>a49738f9f66a6a6d8a70dbe712ab1f697</anchor>
      <arglist>(void)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>gmm.c</name>
    <path>vl/</path>
    <filename>gmm_8c.html</filename>
    <includes id="gmm_8h" name="gmm.h" local="yes" import="no" module="no" objc="no">gmm.h</includes>
    <includes id="mathop__avx_8h" name="mathop_avx.h" local="yes" import="no" module="no" objc="no">mathop_avx.h</includes>
    <includes id="shuffle-def_8h" name="shuffle-def.h" local="yes" import="no" module="no" objc="no">shuffle-def.h</includes>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a049a00cb049f663905a07eefacf5b957</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numComponents)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_reset</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a1baeb175e0cdb68c548addc837d7baae</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_delete</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>adbde533172047f780e2713d18387a9d0</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_gmm_get_data_type</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>ac8980d73a2bac3f4aba64108ea9b7986</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_clusters</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a6d4f30630fd47af3dec762a58df7b653</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_data</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a83a3fb14322069092b4618bcabaf5fda</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_get_loglikelihood</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a618c40e1338f2433505f83d0745fce7f</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_gmm_get_verbosity</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a167e3a1208bc756e1681dfc44dab5928</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_verbosity</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a96708e3c10107c49f136a0fe1082684a</anchor>
      <arglist>(VlGMM *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_means</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a28238c4c58f9ce0cf628983ee3250692</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_covariances</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a4396bdbacc52f021ae411a86b8b790d0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_priors</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a5c3d0051905738dcc3a530999c040e4d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_posteriors</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a7c7edd9be337cd70996a7dbea16a1cba</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_max_num_iterations</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>aaa311e17e0190fa3a247349d4e127e3d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_max_num_iterations</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a606ce33d200101fa6a60e10a3e89cec1</anchor>
      <arglist>(VlGMM *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_num_repetitions</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a9801c187ad6f0561275a715d3e589a59</anchor>
      <arglist>(VlGMM *self, vl_size numRepetitions)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_dimension</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a5dd301238834c161a8ca142f32b2a83c</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlGMMInitialization</type>
      <name>vl_gmm_get_initialization</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a51e3a8e372e5d019c215d126823986b0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_initialization</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a3f34a10ef70b880a81eabce9fc29cc2e</anchor>
      <arglist>(VlGMM *self, VlGMMInitialization init)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_gmm_get_kmeans_init_object</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>aabae027322a65ed27f9cc4245aaf69af</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_kmeans_init_object</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>ae740ca4d9c354ac9d83c89127bce744c</anchor>
      <arglist>(VlGMM *self, VlKMeans *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_gmm_get_covariance_lower_bounds</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a0c419f2bdd757a072413f2f9aae7eac9</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bounds</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>ac5b9aa600e348e99907cdb9f160c8d1d</anchor>
      <arglist>(VlGMM *self, double const *bounds)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bound</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a607ba2f82f3bfe5949f71acca0d332c8</anchor>
      <arglist>(VlGMM *self, double bound)</arglist>
    </member>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new_copy</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>abe04baf8b2d7ad3892ed5d4cb7ddf7d9</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_rand_data</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>aab9d461e2fca63960f2751ae86946804</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_kmeans</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a21934aa27cd02d67734d311c4207829e</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData, VlKMeans *kmeansInit)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_cluster</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a856cdfe758b7c48c3309859853f38e36</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_em</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a4f8f3fc91d284a2866fc5fd5d5b48dfd</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_means</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a001f4a994fbb997e7b7b38d56e69e495</anchor>
      <arglist>(VlGMM *self, void const *means)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariances</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a9467941c38e0eb70f1e7de2cf8242716</anchor>
      <arglist>(VlGMM *self, void const *covariances)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_priors</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>a4c0e4759f7b082400cfe4da0991139c8</anchor>
      <arglist>(VlGMM *self, void const *priors)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_repetitions</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>aba79f6a785a9c33b84f5dc38c9b670aa</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_repetitions</name>
      <anchorfile>gmm_8c.html</anchorfile>
      <anchor>aba79f6a785a9c33b84f5dc38c9b670aa</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>gmm.h</name>
    <path>vl/</path>
    <filename>gmm_8h.html</filename>
    <includes id="kmeans_8h" name="kmeans.h" local="yes" import="no" module="no" objc="no">kmeans.h</includes>
    <member kind="typedef">
      <type>OPAQUE</type>
      <name>VlGMM</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a01f10e60632745b4c4aa7cf8b796647f</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlGMMInitialization</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a89681cfc201e4ddfff3084c2898d1974</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlGMMKMeans</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a89681cfc201e4ddfff3084c2898d1974a5a63bb7b0105d969855a9097d13ffd34</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlGMMRand</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a89681cfc201e4ddfff3084c2898d1974affba7144b2bd2505b6b0ccaa89bd4f51</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlGMMCustom</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a89681cfc201e4ddfff3084c2898d1974adaee798f6850c527ecf774cedfc44cb7</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_means</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a001f4a994fbb997e7b7b38d56e69e495</anchor>
      <arglist>(VlGMM *self, void const *means)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariances</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a9467941c38e0eb70f1e7de2cf8242716</anchor>
      <arglist>(VlGMM *self, void const *covariances)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_priors</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a4c0e4759f7b082400cfe4da0991139c8</anchor>
      <arglist>(VlGMM *self, void const *priors)</arglist>
    </member>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a049a00cb049f663905a07eefacf5b957</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numComponents)</arglist>
    </member>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new_copy</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a453251a43be156a42080f24085c4c943</anchor>
      <arglist>(VlGMM const *gmm)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_delete</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>adbde533172047f780e2713d18387a9d0</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_reset</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a1baeb175e0cdb68c548addc837d7baae</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_cluster</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a856cdfe758b7c48c3309859853f38e36</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_rand_data</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aab9d461e2fca63960f2751ae86946804</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_kmeans</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a21934aa27cd02d67734d311c4207829e</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData, VlKMeans *kmeansInit)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_em</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a4f8f3fc91d284a2866fc5fd5d5b48dfd</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_num_repetitions</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a9801c187ad6f0561275a715d3e589a59</anchor>
      <arglist>(VlGMM *self, vl_size numRepetitions)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_max_num_iterations</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a606ce33d200101fa6a60e10a3e89cec1</anchor>
      <arglist>(VlGMM *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_verbosity</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a96708e3c10107c49f136a0fe1082684a</anchor>
      <arglist>(VlGMM *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_initialization</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a3f34a10ef70b880a81eabce9fc29cc2e</anchor>
      <arglist>(VlGMM *self, VlGMMInitialization init)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_kmeans_init_object</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ae740ca4d9c354ac9d83c89127bce744c</anchor>
      <arglist>(VlGMM *self, VlKMeans *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bounds</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ac5b9aa600e348e99907cdb9f160c8d1d</anchor>
      <arglist>(VlGMM *self, double const *bounds)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bound</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a607ba2f82f3bfe5949f71acca0d332c8</anchor>
      <arglist>(VlGMM *self, double bound)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_means</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a28238c4c58f9ce0cf628983ee3250692</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_covariances</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a4396bdbacc52f021ae411a86b8b790d0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_priors</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a5c3d0051905738dcc3a530999c040e4d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_posteriors</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a7c7edd9be337cd70996a7dbea16a1cba</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_gmm_get_data_type</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ac8980d73a2bac3f4aba64108ea9b7986</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_dimension</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a5dd301238834c161a8ca142f32b2a83c</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_repetitions</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aba79f6a785a9c33b84f5dc38c9b670aa</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_data</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a83a3fb14322069092b4618bcabaf5fda</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_clusters</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a6d4f30630fd47af3dec762a58df7b653</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_get_loglikelihood</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a618c40e1338f2433505f83d0745fce7f</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_gmm_get_verbosity</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a167e3a1208bc756e1681dfc44dab5928</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_max_num_iterations</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aaa311e17e0190fa3a247349d4e127e3d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlGMMInitialization</type>
      <name>vl_gmm_get_initialization</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a51e3a8e372e5d019c215d126823986b0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_gmm_get_kmeans_init_object</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aabae027322a65ed27f9cc4245aaf69af</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_gmm_get_covariance_lower_bounds</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a0c419f2bdd757a072413f2f9aae7eac9</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a049a00cb049f663905a07eefacf5b957</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numComponents)</arglist>
    </member>
    <member kind="function">
      <type>VlGMM *</type>
      <name>vl_gmm_new_copy</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a453251a43be156a42080f24085c4c943</anchor>
      <arglist>(VlGMM const *gmm)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_delete</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>adbde533172047f780e2713d18387a9d0</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_reset</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a1baeb175e0cdb68c548addc837d7baae</anchor>
      <arglist>(VlGMM *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_cluster</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a856cdfe758b7c48c3309859853f38e36</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_rand_data</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aab9d461e2fca63960f2751ae86946804</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_init_with_kmeans</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a21934aa27cd02d67734d311c4207829e</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData, VlKMeans *kmeansInit)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_em</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a4f8f3fc91d284a2866fc5fd5d5b48dfd</anchor>
      <arglist>(VlGMM *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_num_repetitions</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a9801c187ad6f0561275a715d3e589a59</anchor>
      <arglist>(VlGMM *self, vl_size numRepetitions)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_max_num_iterations</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a606ce33d200101fa6a60e10a3e89cec1</anchor>
      <arglist>(VlGMM *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_verbosity</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a96708e3c10107c49f136a0fe1082684a</anchor>
      <arglist>(VlGMM *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_initialization</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a3f34a10ef70b880a81eabce9fc29cc2e</anchor>
      <arglist>(VlGMM *self, VlGMMInitialization init)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_kmeans_init_object</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ae740ca4d9c354ac9d83c89127bce744c</anchor>
      <arglist>(VlGMM *self, VlKMeans *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bounds</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ac5b9aa600e348e99907cdb9f160c8d1d</anchor>
      <arglist>(VlGMM *self, double const *bounds)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_gmm_set_covariance_lower_bound</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a607ba2f82f3bfe5949f71acca0d332c8</anchor>
      <arglist>(VlGMM *self, double bound)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_means</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a28238c4c58f9ce0cf628983ee3250692</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_covariances</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a4396bdbacc52f021ae411a86b8b790d0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_priors</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a5c3d0051905738dcc3a530999c040e4d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_gmm_get_posteriors</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a7c7edd9be337cd70996a7dbea16a1cba</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_gmm_get_data_type</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>ac8980d73a2bac3f4aba64108ea9b7986</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_dimension</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a5dd301238834c161a8ca142f32b2a83c</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_repetitions</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aba79f6a785a9c33b84f5dc38c9b670aa</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_data</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a83a3fb14322069092b4618bcabaf5fda</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_num_clusters</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a6d4f30630fd47af3dec762a58df7b653</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_gmm_get_loglikelihood</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a618c40e1338f2433505f83d0745fce7f</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_gmm_get_verbosity</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a167e3a1208bc756e1681dfc44dab5928</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_gmm_get_max_num_iterations</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aaa311e17e0190fa3a247349d4e127e3d</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlGMMInitialization</type>
      <name>vl_gmm_get_initialization</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a51e3a8e372e5d019c215d126823986b0</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_gmm_get_kmeans_init_object</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>aabae027322a65ed27f9cc4245aaf69af</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_gmm_get_covariance_lower_bounds</name>
      <anchorfile>gmm_8h.html</anchorfile>
      <anchor>a0c419f2bdd757a072413f2f9aae7eac9</anchor>
      <arglist>(VlGMM const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>heap-def.h</name>
    <path>vl/</path>
    <filename>heap-def_8h.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_HEAP_array</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ac2b59b9373be3df851dac7c594924a92</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_HEAP_prefix</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ae0d8f7e617493c4a73696983e1c360b6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_HEAP_type</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a809b241c547ba76275bd10575086c3b2</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_HEAP_array</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ac2b59b9373be3df851dac7c594924a92</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_HEAP_array</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ac2b59b9373be3df851dac7c594924a92</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_heap_parent</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a7256f361601ba43113c862d9477f1d4b</anchor>
      <arglist>(vl_uindex index)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_heap_left_child</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a95b7f92afacd889da252d5a77fde5d05</anchor>
      <arglist>(vl_uindex index)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_heap_right_child</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>aacfa305e511251faa8cfb8b7114a31f7</anchor>
      <arglist>(vl_uindex index)</arglist>
    </member>
    <member kind="function">
      <type>VL_HEAP_type</type>
      <name>VL_HEAP_cmp</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>af926f2b2ea17e5adcf6ab144d87f96e2</anchor>
      <arglist>(VL_HEAP_array_const array, vl_uindex indexA, vl_uindex indexB)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_HEAP_swap</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a23f32c850484c8824785a17e9d93272b</anchor>
      <arglist>(VL_HEAP_array array, vl_uindex indexA, vl_uindex indexB)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_HEAP_up</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a8c4d40e0b2309f0d897a8b1e9a55d726</anchor>
      <arglist>(VL_HEAP_array array, vl_size heapSize, vl_uindex index)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_HEAP_down</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>affd0336086a1762e0ac2cace28c9656a</anchor>
      <arglist>(VL_HEAP_array array, vl_uindex index)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_HEAP_push</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ab8d30a74d7d51d3ed4c9f3e35ef6c638</anchor>
      <arglist>(VL_HEAP_array array, vl_size *heapSize)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>VL_HEAP_pop</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>ac9e07a24d045fbc08853213bc84be5ea</anchor>
      <arglist>(VL_HEAP_array array, vl_size *heapSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_HEAP_update</name>
      <anchorfile>heap-def_8h.html</anchorfile>
      <anchor>a6718e132e6bfabc177ca2f5115dd6452</anchor>
      <arglist>(VL_HEAP_array array, vl_size heapSize, vl_uindex index)</arglist>
    </member>
    <docanchor file="heap-def_8h.html" title="Overview">heap-def-overview</docanchor>
    <docanchor file="heap-def_8h.html" title="General usage">heap-def-overview-general</docanchor>
    <docanchor file="heap-def_8h.html" title="Technical details">heap-def-tech</docanchor>
  </compound>
  <compound kind="file">
    <name>hikmeans.c</name>
    <path>vl/</path>
    <filename>hikmeans_8c.html</filename>
    <includes id="hikmeans_8h" name="hikmeans.h" local="yes" import="no" module="no" objc="no">hikmeans.h</includes>
    <member kind="function">
      <type>vl_uint8 *</type>
      <name>vl_hikm_copy_subset</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a037cb5c4ef769d5aa7ae313f431a2ec2</anchor>
      <arglist>(vl_uint8 const *data, vl_uint32 *ids, vl_size N, vl_size M, vl_uint32 id, vl_size *N2)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static VlHIKMNode *</type>
      <name>xmeans</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>ad4f7ed123a365903ad915c6335c670a6</anchor>
      <arglist>(VlHIKMTree *tree, vl_uint8 const *data, vl_size N, vl_size K, vl_size height)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>xdelete</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>aadddad0081d1f54bbb0a198ed4f16916</anchor>
      <arglist>(VlHIKMNode *node)</arglist>
    </member>
    <member kind="function">
      <type>VlHIKMTree *</type>
      <name>vl_hikm_new</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>af553e56789fbc7e177e9202d47af973e</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_delete</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a7830ea7acf7332e0eda8369b58853808</anchor>
      <arglist>(VlHIKMTree *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_init</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a80b86a77cf5994e4c6675a7632e01e01</anchor>
      <arglist>(VlHIKMTree *f, vl_size M, vl_size K, vl_size depth)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_train</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>ace8de873d52287e32918999864b93fbd</anchor>
      <arglist>(VlHIKMTree *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_push</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>aacb98ccf6f8e9cc45dcfda9ca4f648c9</anchor>
      <arglist>(VlHIKMTree *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_ndims</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a8bbbad989ed222178d7d80a7ef8a6a8c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_K</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>ad01623c87b275ba47ab9dcf6679d3bae</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_depth</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a51b8a3da781958f50d4ef41dcbda2d32</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_hikm_get_verbosity</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a41f0093905ef603a8b93e921522638e4</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_max_niters</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>af305ded1d09a18af4ea3d9562a2bdb1c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>VlHIKMNode const *</type>
      <name>vl_hikm_get_root</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a3ac5fe2898bb059de5ec3c9a4fcdb03a</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_verbosity</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a23789e4faee416be030f2a519de096e3</anchor>
      <arglist>(VlHIKMTree *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_max_niters</name>
      <anchorfile>hikmeans_8c.html</anchorfile>
      <anchor>a431d5ac9cb5d5ae058dcc9785ad08fe5</anchor>
      <arglist>(VlHIKMTree *f, int max_niters)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>hikmeans.h</name>
    <path>vl/</path>
    <filename>hikmeans_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="ikmeans_8h" name="ikmeans.h" local="yes" import="no" module="no" objc="no">ikmeans.h</includes>
    <class kind="struct">VlHIKMNode</class>
    <class kind="struct">VlHIKMTree</class>
    <member kind="function">
      <type>VlHIKMTree *</type>
      <name>vl_hikm_new</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>af553e56789fbc7e177e9202d47af973e</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_delete</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a7830ea7acf7332e0eda8369b58853808</anchor>
      <arglist>(VlHIKMTree *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_ndims</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a8bbbad989ed222178d7d80a7ef8a6a8c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_K</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>ad01623c87b275ba47ab9dcf6679d3bae</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_depth</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a51b8a3da781958f50d4ef41dcbda2d32</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_hikm_get_verbosity</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a41f0093905ef603a8b93e921522638e4</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_max_niters</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>af305ded1d09a18af4ea3d9562a2bdb1c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>VlHIKMNode const *</type>
      <name>vl_hikm_get_root</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a3ac5fe2898bb059de5ec3c9a4fcdb03a</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_verbosity</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a23789e4faee416be030f2a519de096e3</anchor>
      <arglist>(VlHIKMTree *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_max_niters</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a431d5ac9cb5d5ae058dcc9785ad08fe5</anchor>
      <arglist>(VlHIKMTree *f, int max_niters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_init</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a80b86a77cf5994e4c6675a7632e01e01</anchor>
      <arglist>(VlHIKMTree *f, vl_size M, vl_size K, vl_size depth)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_train</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>ace8de873d52287e32918999864b93fbd</anchor>
      <arglist>(VlHIKMTree *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_push</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>aacb98ccf6f8e9cc45dcfda9ca4f648c9</anchor>
      <arglist>(VlHIKMTree *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>VlHIKMTree *</type>
      <name>vl_hikm_new</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>af553e56789fbc7e177e9202d47af973e</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_delete</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a7830ea7acf7332e0eda8369b58853808</anchor>
      <arglist>(VlHIKMTree *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_ndims</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a8bbbad989ed222178d7d80a7ef8a6a8c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_K</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>ad01623c87b275ba47ab9dcf6679d3bae</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_depth</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a51b8a3da781958f50d4ef41dcbda2d32</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_hikm_get_verbosity</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a41f0093905ef603a8b93e921522638e4</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hikm_get_max_niters</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>af305ded1d09a18af4ea3d9562a2bdb1c</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>VlHIKMNode const *</type>
      <name>vl_hikm_get_root</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a3ac5fe2898bb059de5ec3c9a4fcdb03a</anchor>
      <arglist>(VlHIKMTree const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_verbosity</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a23789e4faee416be030f2a519de096e3</anchor>
      <arglist>(VlHIKMTree *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_set_max_niters</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a431d5ac9cb5d5ae058dcc9785ad08fe5</anchor>
      <arglist>(VlHIKMTree *f, int max_niters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_init</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>a80b86a77cf5994e4c6675a7632e01e01</anchor>
      <arglist>(VlHIKMTree *f, vl_size M, vl_size K, vl_size depth)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_train</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>ace8de873d52287e32918999864b93fbd</anchor>
      <arglist>(VlHIKMTree *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hikm_push</name>
      <anchorfile>hikmeans_8h.html</anchorfile>
      <anchor>aacb98ccf6f8e9cc45dcfda9ca4f648c9</anchor>
      <arglist>(VlHIKMTree *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <docanchor file="hikmeans_8h.html" title="HIKM tree">hikm-tree</docanchor>
  </compound>
  <compound kind="file">
    <name>hog.c</name>
    <path>vl/</path>
    <filename>hog_8c.html</filename>
    <includes id="hog_8h" name="hog.h" local="yes" import="no" module="no" objc="no">hog.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>VlHog *</type>
      <name>vl_hog_new</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a6a2398bb1353ca5f85202a445f2928cd</anchor>
      <arglist>(VlHogVariant variant, vl_size numOrientations, vl_bool transposed)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_delete</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a31692138ce8b6c925bf9cf4761f9dd71</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_glyph_size</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a61ae53dfac6a9ed20a8865e531c23d5a</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_index const *</type>
      <name>vl_hog_get_permutation</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a41de7d4ca02d59c2a62ccc27bc74072d</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_set_use_bilinear_orientation_assignments</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a1d3c6e1ebef79141b2ddbf8208f3e25e</anchor>
      <arglist>(VlHog *self, vl_bool x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_hog_get_use_bilinear_orientation_assignments</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a901062389718b5584a194d15bbdaaad2</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_render</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>aafce8a9f029f232887bda4e64c585aa3</anchor>
      <arglist>(VlHog const *self, float *image, float const *descriptor, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_dimension</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>acce19086c37f34edc0078933f224ebcc</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_width</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a8e899624c92435e77f3a1916b7ce5ed4</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_height</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>ad7037e000f578c2abeeb4e8a3d6bbaf6</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_hog_prepare_buffers</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a5dbfa64119c885357735d6f7f2bd26b5</anchor>
      <arglist>(VlHog *self, vl_size width, vl_size height, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_put_image</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a86e1faec74ae8163db8dd1e0d292c305</anchor>
      <arglist>(VlHog *self, float const *image, vl_size width, vl_size height, vl_size numChannels, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_put_polar_field</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>a2da0444b21261c3db0309ca25ad5895b</anchor>
      <arglist>(VlHog *self, float const *modulus, float const *angle, vl_bool directed, vl_size width, vl_size height, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_extract</name>
      <anchorfile>hog_8c.html</anchorfile>
      <anchor>ab66448d416e661344327f969aebb9a42</anchor>
      <arglist>(VlHog *self, float *features)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>hog.h</name>
    <path>vl/</path>
    <filename>hog_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="function">
      <type>VlHog *</type>
      <name>vl_hog_new</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a6a2398bb1353ca5f85202a445f2928cd</anchor>
      <arglist>(VlHogVariant variant, vl_size numOrientations, vl_bool transposed)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_delete</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a31692138ce8b6c925bf9cf4761f9dd71</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_put_image</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a86e1faec74ae8163db8dd1e0d292c305</anchor>
      <arglist>(VlHog *self, float const *image, vl_size width, vl_size height, vl_size numChannels, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_put_polar_field</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a2da0444b21261c3db0309ca25ad5895b</anchor>
      <arglist>(VlHog *self, float const *modulus, float const *angle, vl_bool directed, vl_size width, vl_size height, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_extract</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>ab66448d416e661344327f969aebb9a42</anchor>
      <arglist>(VlHog *self, float *features)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_height</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>ad7037e000f578c2abeeb4e8a3d6bbaf6</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_width</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a8e899624c92435e77f3a1916b7ce5ed4</anchor>
      <arglist>(VlHog *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_render</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a807b3e1a41f403eab4b2c22aba5cbbc2</anchor>
      <arglist>(VlHog const *self, float *image, float const *features, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_dimension</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>acce19086c37f34edc0078933f224ebcc</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_index const *</type>
      <name>vl_hog_get_permutation</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a41de7d4ca02d59c2a62ccc27bc74072d</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_hog_get_glyph_size</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a61ae53dfac6a9ed20a8865e531c23d5a</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_hog_get_use_bilinear_orientation_assignments</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a901062389718b5584a194d15bbdaaad2</anchor>
      <arglist>(VlHog const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_hog_set_use_bilinear_orientation_assignments</name>
      <anchorfile>hog_8h.html</anchorfile>
      <anchor>a1d3c6e1ebef79141b2ddbf8208f3e25e</anchor>
      <arglist>(VlHog *self, vl_bool x)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>homkermap.c</name>
    <path>vl/</path>
    <filename>homkermap_8c.html</filename>
    <includes id="homkermap_8h" name="homkermap.h" local="yes" import="no" module="no" objc="no">homkermap.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="homkermap_8c" name="homkermap.c" local="yes" import="no" module="no" objc="no">homkermap.c</includes>
    <member kind="function">
      <type>double</type>
      <name>vl_homogeneouskernelmap_get_spectrum</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a86c2873e6353bcfcbaa4abd4314af9d8</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, double omega)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_homogeneouskernelmap_get_smooth_spectrum</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>ac2d0164090862bfa17f25364447676e7</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, double omega)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_homogeneouskernelmap_new</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a744ee7b0d81f677a0f5e2cce65971ad1</anchor>
      <arglist>(VlHomogeneousKernelType kernelType, double gamma, vl_size order, double period, VlHomogeneousKernelMapWindowType windowType)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_delete</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a9a059f792833cb10e62f5f476f99f0da</anchor>
      <arglist>(VlHomogeneousKernelMap *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_order</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a5313ff7a41b555600e5d2379613e486f</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_dimension</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a9b0ff9e29e918d0591590a8857ca6ae1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelType</type>
      <name>vl_homogeneouskernelmap_get_kernel_type</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>a61d8c4d7f2226bbdff7a67779c156bbb</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMapWindowType</type>
      <name>vl_homogeneouskernelmap_get_window_type</name>
      <anchorfile>homkermap_8c.html</anchorfile>
      <anchor>ae3ed4aa68a26e81a8456743c7edda1c1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>homkermap.h</name>
    <path>vl/</path>
    <filename>homkermap_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="typedef">
      <type>OPAQUE</type>
      <name>VlHomogeneousKernelMap</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a5606496b3524c531aef85d63e1f7d0d9</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlHomogeneousKernelType</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a13074dd7edec5d8c86dde5da80e8d8d8</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlHomogeneousKernelIntersection</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a13074dd7edec5d8c86dde5da80e8d8d8af793e7c7238192b64f007e7a5bc9b3b2</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlHomogeneousKernelChi2</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a13074dd7edec5d8c86dde5da80e8d8d8a0ddb0dafd4c63088336d983b944ac5df</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlHomogeneousKernelJS</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a13074dd7edec5d8c86dde5da80e8d8d8a685a81b7c2636dffa06eb5b59e836df5</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlHomogeneousKernelMapWindowType</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a35a05da3e1eb781a6fa997ec9be69a62</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlHomogeneousKernelMapWindowUniform</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a35a05da3e1eb781a6fa997ec9be69a62ab9d8903c4fc8d17dadf194dac6682238</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlHomogeneousKernelMapWindowRectangular</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a35a05da3e1eb781a6fa997ec9be69a62a83070b8b6be773c61bc3f19fc4583053</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_homogeneouskernelmap_new</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a744ee7b0d81f677a0f5e2cce65971ad1</anchor>
      <arglist>(VlHomogeneousKernelType kernelType, double gamma, vl_size order, double period, VlHomogeneousKernelMapWindowType windowType)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_delete</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a9a059f792833cb10e62f5f476f99f0da</anchor>
      <arglist>(VlHomogeneousKernelMap *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_evaluate_d</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>aa46c3f8cfdf0f1334727c27c13e77608</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, double *destination, vl_size stride, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_evaluate_f</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a2ea4628d7a00b9543112fc4dd2d8f380</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, float *destination, vl_size stride, double x)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_order</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a5313ff7a41b555600e5d2379613e486f</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_dimension</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a9b0ff9e29e918d0591590a8857ca6ae1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelType</type>
      <name>vl_homogeneouskernelmap_get_kernel_type</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a61d8c4d7f2226bbdff7a67779c156bbb</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMapWindowType</type>
      <name>vl_homogeneouskernelmap_get_window_type</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>ae3ed4aa68a26e81a8456743c7edda1c1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_homogeneouskernelmap_new</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a744ee7b0d81f677a0f5e2cce65971ad1</anchor>
      <arglist>(VlHomogeneousKernelType kernelType, double gamma, vl_size order, double period, VlHomogeneousKernelMapWindowType windowType)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_delete</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a9a059f792833cb10e62f5f476f99f0da</anchor>
      <arglist>(VlHomogeneousKernelMap *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_evaluate_d</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>aa46c3f8cfdf0f1334727c27c13e77608</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, double *destination, vl_size stride, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_homogeneouskernelmap_evaluate_f</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a2ea4628d7a00b9543112fc4dd2d8f380</anchor>
      <arglist>(VlHomogeneousKernelMap const *self, float *destination, vl_size stride, double x)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_order</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a5313ff7a41b555600e5d2379613e486f</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_homogeneouskernelmap_get_dimension</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a9b0ff9e29e918d0591590a8857ca6ae1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelType</type>
      <name>vl_homogeneouskernelmap_get_kernel_type</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>a61d8c4d7f2226bbdff7a67779c156bbb</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMapWindowType</type>
      <name>vl_homogeneouskernelmap_get_window_type</name>
      <anchorfile>homkermap_8h.html</anchorfile>
      <anchor>ae3ed4aa68a26e81a8456743c7edda1c1</anchor>
      <arglist>(VlHomogeneousKernelMap const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>host.c</name>
    <path>vl/</path>
    <filename>host_8c.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>HAS_CPUID</name>
      <anchorfile>host_8c.html</anchorfile>
      <anchor>a64a428a197a6f71e42806354612841ef</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_static_configuration_to_string_copy</name>
      <anchorfile>host_8c.html</anchorfile>
      <anchor>af15406f9e55646ad43421b29a7fa12d3</anchor>
      <arglist>()</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>host.h</name>
    <path>vl/</path>
    <filename>host_8h.html</filename>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_THREADS</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a6aa5ee10e7a31696751b3e5f6d18c829</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_SSE2</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a7395dc017ee0e86717a1b5f8c38fcb44</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_OPENMP</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa685e90981c2eb133a361080cdf7b82f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_EXPORT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a489d7622ef2e3937985fcb9f89a5cbe5</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INLINE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a41b94143626a52276b1a0ffd1e29e496</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_STRINGIFY</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a61a48096b951544d0554b8a06aa59306</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XSTRINGIFY</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2a5d283f40e6bf0fc1ca74644084a423</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_CAT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aeba7ee97f4e6474a78c242ca9c49798c</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a755f8d9673970b82ad9375e32d2693ef</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT3</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ae5a425c5832ec8b91c3acd70cc30ad8d</anchor>
      <arglist>(x, y, z)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT4</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0b450714848c2941f3e00e7a9d2338f4</anchor>
      <arglist>(x, y, z, u)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT5</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a551d8bfc670074c55bf8a0a7405f5e28</anchor>
      <arglist>(x, y, z, u, v)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_YESNO</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>addfdc610a7c5d53f5167f7a02b5baf4f</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_LINUX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ace5a6e77fa663303cfd489f3eaaf1cd9</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_MACOSX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a6368203ab40afc45aa5d2faaf794038e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_WIN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9e8b6b892c4c517efb458a908f8d8f89</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_WIN64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a5a08df472ecc78e67b920ca29217fabf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_THREADS_POSIX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa463843e959e6add43b050e78892e75a</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_THREADS_WIN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a4b8e0e703e4bbdff30e1c3a00225e74f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_GNUC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a1d501d055fcbcd42c1369c64f4bc8e8d</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_MSC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a27371f6fc56a871d3d2a2dea1b191cbf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LCC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a8c241c8e1d46fc25653460876004fbee</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_IX86</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aad2a5cd35841264fc165f9b92fad3feb</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_IA64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a55960eea1c39d0ed79519e4fbdb782bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LLP64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a01af69f0de0af937ca06729348d3b1a6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LP64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a06056894ccd483c6171eec205fb253a6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_ILP32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a426f6e574a76d69692eace4d858b9adf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_LITTLE_ENDIAN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2f05e20e356b146f3d111f403657ca17</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_BIG_ENDIAN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a040b85d2764e6270f5d14515c8ab02aa</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT8_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a39c44d2083958e498425a8abb29b407d</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT16_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ad08cf90e9ab75508ff1a5a8c5a33f1fd</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT32_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a39f97aecddfe2a7abf90a358690410a1</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT64_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2d1d0a4a0f2f80fd47ee405e4c92bba3</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT8_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ae3cffa06d00149d83a3d2332f60b9134</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT16_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>abd41ad6b0fecc0c06e89f556d30f5a05</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT32_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9fedb480a5681cef16985d34ec52f6fe</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT64_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a555c4468bb49c4c17513ef5bcf470f62</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9e0dd28d4000da64e451fbce6939cb6f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ac08de2d648945a77801c9884a0ff752d</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT16</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a065ee814c68df328e58181c387f8ccf6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a782a8eb010de36cbc9c4517f73c23d29</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a15a80f72eaf892a9f0d69167df1a071b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a15a80f72eaf892a9f0d69167df1a071b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a79c56fd25ae0746b063266ec7fae930b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_INTPTR</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>afade1e41badafa9c5280aaef35f87403</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_UINDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>addb8218f8f733565479705ff5f6c0e52</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_SIZE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a32387e8bdd1b0d03af42522deb12f127</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_UINTPTR</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>afbbbf7b8cd264a829a6aecbe26bffba8</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_BIG_INT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2a2754158f58ad8118579b45f66426f3</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SMALL_INT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab11084ae11b83378e74bf4b1e545f134</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_BIG_UINT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a985a5b1b02b23f20c72ba5d5b9abab2d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_static_configuration_to_string_copy</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>af15406f9e55646ad43421b29a7fa12d3</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0eb83ae66c944bcd8517b577b557f872</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_4</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa1a8104ab44b97df0b09d1afdd4754fc</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_2</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab2280db7d7cc2f6ce56100ab5ff6c81a</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_THREADS</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a6aa5ee10e7a31696751b3e5f6d18c829</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_SSE2</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a7395dc017ee0e86717a1b5f8c38fcb44</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_DISABLE_OPENMP</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa685e90981c2eb133a361080cdf7b82f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_EXPORT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a489d7622ef2e3937985fcb9f89a5cbe5</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INLINE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a41b94143626a52276b1a0ffd1e29e496</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_STRINGIFY</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a61a48096b951544d0554b8a06aa59306</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XSTRINGIFY</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2a5d283f40e6bf0fc1ca74644084a423</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_CAT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aeba7ee97f4e6474a78c242ca9c49798c</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a755f8d9673970b82ad9375e32d2693ef</anchor>
      <arglist>(x, y)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT3</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ae5a425c5832ec8b91c3acd70cc30ad8d</anchor>
      <arglist>(x, y, z)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT4</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0b450714848c2941f3e00e7a9d2338f4</anchor>
      <arglist>(x, y, z, u)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_XCAT5</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a551d8bfc670074c55bf8a0a7405f5e28</anchor>
      <arglist>(x, y, z, u, v)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_YESNO</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>addfdc610a7c5d53f5167f7a02b5baf4f</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_LINUX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ace5a6e77fa663303cfd489f3eaaf1cd9</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_MACOSX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a6368203ab40afc45aa5d2faaf794038e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_WIN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9e8b6b892c4c517efb458a908f8d8f89</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_OS_WIN64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a5a08df472ecc78e67b920ca29217fabf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_THREADS_POSIX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa463843e959e6add43b050e78892e75a</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_THREADS_WIN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a4b8e0e703e4bbdff30e1c3a00225e74f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_GNUC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a1d501d055fcbcd42c1369c64f4bc8e8d</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_MSC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a27371f6fc56a871d3d2a2dea1b191cbf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LCC</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a8c241c8e1d46fc25653460876004fbee</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_IX86</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aad2a5cd35841264fc165f9b92fad3feb</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_IA64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a55960eea1c39d0ed79519e4fbdb782bf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LLP64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a01af69f0de0af937ca06729348d3b1a6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_LP64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a06056894ccd483c6171eec205fb253a6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_COMPILER_ILP32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a426f6e574a76d69692eace4d858b9adf</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_LITTLE_ENDIAN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2f05e20e356b146f3d111f403657ca17</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ARCH_BIG_ENDIAN</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a040b85d2764e6270f5d14515c8ab02aa</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TRUE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0c72a8c7d2abcd2871b3348138c5f1f4</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FALSE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>abce143a5a9b51d987a74f2ad30046520</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>long long</type>
      <name>vl_int64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab9925d4a6df873da6df7a59d2a97d81c</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>int</type>
      <name>vl_int32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a03fa435c713d3141c4a700f79f5b2600</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>short</type>
      <name>vl_int16</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a47e046602e64d54280961328bf950ca1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>char</type>
      <name>vl_int8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aee4cc9690b799a33dfc9614636ac34a1</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>long long unsigned</type>
      <name>vl_uint64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>af37832522d1f5c028ac15d0ccda7ff48</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>int unsigned</type>
      <name>vl_uint32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aeb7c862765448a70017105efa4d25e7a</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>short unsigned</type>
      <name>vl_uint16</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab2275d6c7bf6fc027151d11072b45f03</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>char unsigned</type>
      <name>vl_uint8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a38fbd9a3cf53dfc9a5650c38497b7d35</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>int</type>
      <name>vl_int</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a8127af01f6220099c1dd4ec579f5ae09</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>unsigned int</type>
      <name>vl_uint</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a5bd6e91d6bfd0be04101fdca94069c92</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>int</type>
      <name>vl_bool</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ad32e7f8ec7333ff33998cf671a3b1412</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_int64</type>
      <name>vl_intptr</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>afa16bd9b637357fb5590b7154987239b</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_uint64</type>
      <name>vl_uintptr</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a20819052598008f96d3bd302a35c9d59</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_uint64</type>
      <name>vl_size</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0ee26101458c663510d620e3ee7e2555</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_int64</type>
      <name>vl_index</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a66417c5847876295ea87b38140073879</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_uint64</type>
      <name>vl_uindex</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ac13bd3cc913e1da576e189a3ec8d66fc</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT8_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a39c44d2083958e498425a8abb29b407d</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT16_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ad08cf90e9ab75508ff1a5a8c5a33f1fd</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT32_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a39f97aecddfe2a7abf90a358690410a1</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INT64_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2d1d0a4a0f2f80fd47ee405e4c92bba3</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT8_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ae3cffa06d00149d83a3d2332f60b9134</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT16_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>abd41ad6b0fecc0c06e89f556d30f5a05</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT32_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9fedb480a5681cef16985d34ec52f6fe</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_UINT64_C</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a555c4468bb49c4c17513ef5bcf470f62</anchor>
      <arglist>(x)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT64</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a9e0dd28d4000da64e451fbce6939cb6f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT32</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ac08de2d648945a77801c9884a0ff752d</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT16</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a065ee814c68df328e58181c387f8ccf6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INT8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a782a8eb010de36cbc9c4517f73c23d29</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a15a80f72eaf892a9f0d69167df1a071b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FL_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a15a80f72eaf892a9f0d69167df1a071b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_INDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a79c56fd25ae0746b063266ec7fae930b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_INTPTR</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>afade1e41badafa9c5280aaef35f87403</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_UINDEX</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>addb8218f8f733565479705ff5f6c0e52</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_SIZE</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a32387e8bdd1b0d03af42522deb12f127</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_FMT_UINTPTR</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>afbbbf7b8cd264a829a6aecbe26bffba8</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_BIG_INT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a2a2754158f58ad8118579b45f66426f3</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SMALL_INT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab11084ae11b83378e74bf4b1e545f134</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_BIG_UINT</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a985a5b1b02b23f20c72ba5d5b9abab2d</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_8</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>a0eb83ae66c944bcd8517b577b557f872</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_4</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>aa1a8104ab44b97df0b09d1afdd4754fc</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_swap_host_big_endianness_2</name>
      <anchorfile>host_8h.html</anchorfile>
      <anchor>ab2280db7d7cc2f6ce56100ab5ff6c81a</anchor>
      <arglist>(void *dst, void *src)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>ikmeans.c</name>
    <path>vl/</path>
    <filename>ikmeans_8c.html</filename>
    <includes id="ikmeans_8h" name="ikmeans.h" local="yes" import="no" module="no" objc="no">ikmeans.h</includes>
    <member kind="function">
      <type>VlIKMFilt *</type>
      <name>vl_ikm_new</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>a7b454f1d095bed9c8dfb0d86907f45ab</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_delete</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>a33a659152e03286d390aa17b1a212a7b</anchor>
      <arglist>(VlIKMFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_train</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>a58ccd60ab79dbfe8b9823a1caede7879</anchor>
      <arglist>(VlIKMFilt *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_push</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>ac7e2bc8d34d514a4fe43b57d12dc244a</anchor>
      <arglist>(VlIKMFilt *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint32</type>
      <name>vl_ikm_push_one</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>af2fef6df8fbeb3bfe780a031b6d36861</anchor>
      <arglist>(vl_ikmacc_t const *centers, vl_uint8 const *data, vl_size M, vl_size K)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_ndims</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>a10787adeb3ac4c3d6cce7a2e3598525f</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_K</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>aba2ce262018aae7049c53a33af0db8e1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_get_verbosity</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>afe77d60b7c64f773b9e5edbcebca6e21</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_max_niters</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>ad1dcf031fd04bdbaf9d389dcd960c953</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_ikmacc_t const *</type>
      <name>vl_ikm_get_centers</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>ab6fe81f5f1ec1555603efbea1653c9c1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_verbosity</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>adbf9d13d091a5bec378023de11bfa690</anchor>
      <arglist>(VlIKMFilt *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_max_niters</name>
      <anchorfile>ikmeans_8c.html</anchorfile>
      <anchor>a25053477cd794f1a0fc3095a08640c62</anchor>
      <arglist>(VlIKMFilt *f, vl_size max_niters)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>ikmeans.h</name>
    <path>vl/</path>
    <filename>ikmeans_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <class kind="struct">VlIKMFilt</class>
    <member kind="typedef">
      <type>vl_int32</type>
      <name>vl_ikmacc_t</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a6a9ff8a15b1f0d96c187e96705d350e2</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlIKMAlgorithms</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a4aa95067e495fa8309ab028307a3418d</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_IKM_LLOYD</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a4aa95067e495fa8309ab028307a3418da03abd693c3d932bb543401274eb868c4</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_IKM_ELKAN</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a4aa95067e495fa8309ab028307a3418da46d6e04c3599a881c16722b6969c5a21</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlIKMFilt *</type>
      <name>vl_ikm_new</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a7b454f1d095bed9c8dfb0d86907f45ab</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_delete</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a33a659152e03286d390aa17b1a212a7b</anchor>
      <arglist>(VlIKMFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_train</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a58ccd60ab79dbfe8b9823a1caede7879</anchor>
      <arglist>(VlIKMFilt *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_push</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ac7e2bc8d34d514a4fe43b57d12dc244a</anchor>
      <arglist>(VlIKMFilt *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_ikm_push_one</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a03f0ed5b6f3680b1f872c01e47b36cb8</anchor>
      <arglist>(vl_ikmacc_t const *centers, vl_uint8 const *data, vl_size M, vl_size K)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_ndims</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a10787adeb3ac4c3d6cce7a2e3598525f</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_K</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>aba2ce262018aae7049c53a33af0db8e1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_get_verbosity</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>afe77d60b7c64f773b9e5edbcebca6e21</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_max_niters</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ad1dcf031fd04bdbaf9d389dcd960c953</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_ikmacc_t const *</type>
      <name>vl_ikm_get_centers</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ab6fe81f5f1ec1555603efbea1653c9c1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_verbosity</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>adbf9d13d091a5bec378023de11bfa690</anchor>
      <arglist>(VlIKMFilt *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_max_niters</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a25053477cd794f1a0fc3095a08640c62</anchor>
      <arglist>(VlIKMFilt *f, vl_size max_niters)</arglist>
    </member>
    <member kind="function">
      <type>VlIKMFilt *</type>
      <name>vl_ikm_new</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a7b454f1d095bed9c8dfb0d86907f45ab</anchor>
      <arglist>(int method)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_delete</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a33a659152e03286d390aa17b1a212a7b</anchor>
      <arglist>(VlIKMFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_train</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a58ccd60ab79dbfe8b9823a1caede7879</anchor>
      <arglist>(VlIKMFilt *f, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_push</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ac7e2bc8d34d514a4fe43b57d12dc244a</anchor>
      <arglist>(VlIKMFilt *f, vl_uint32 *asgn, vl_uint8 const *data, vl_size N)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_ikm_push_one</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a03f0ed5b6f3680b1f872c01e47b36cb8</anchor>
      <arglist>(vl_ikmacc_t const *centers, vl_uint8 const *data, vl_size M, vl_size K)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_ndims</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a10787adeb3ac4c3d6cce7a2e3598525f</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_K</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>aba2ce262018aae7049c53a33af0db8e1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_ikm_get_verbosity</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>afe77d60b7c64f773b9e5edbcebca6e21</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_ikm_get_max_niters</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ad1dcf031fd04bdbaf9d389dcd960c953</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_ikmacc_t const *</type>
      <name>vl_ikm_get_centers</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>ab6fe81f5f1ec1555603efbea1653c9c1</anchor>
      <arglist>(VlIKMFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_verbosity</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>adbf9d13d091a5bec378023de11bfa690</anchor>
      <arglist>(VlIKMFilt *f, int verb)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_ikm_set_max_niters</name>
      <anchorfile>ikmeans_8h.html</anchorfile>
      <anchor>a25053477cd794f1a0fc3095a08640c62</anchor>
      <arglist>(VlIKMFilt *f, vl_size max_niters)</arglist>
    </member>
    <docanchor file="ikmeans_8h.html" title="Algorithms">ikmeans-algo</docanchor>
    <docanchor file="ikmeans_8h.html" title="Initialization">ikmeans-alg-init</docanchor>
    <docanchor file="ikmeans_8h.html" title="Lloyd">ikmeans-alg-lloyd</docanchor>
    <docanchor file="ikmeans_8h.html" title="Elkan">ikmeans-alg-elkan</docanchor>
  </compound>
  <compound kind="file">
    <name>imopv.c</name>
    <path>vl/</path>
    <filename>imopv_8c.html</filename>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <includes id="imopv__sse2_8h" name="imopv_sse2.h" local="yes" import="no" module="no" objc="no">imopv_sse2.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="imopv_8c" name="imopv.c" local="yes" import="no" module="no" objc="no">imopv.c</includes>
  </compound>
  <compound kind="file">
    <name>imopv.h</name>
    <path>vl/</path>
    <filename>imopv_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_BY_ZERO</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>af6e169f2ed366d16f9149a99d5574071</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_BY_CONTINUITY</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>aabcdd51c289c0d8db11dda9e26349a52</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_MASK</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a2a4f0c469409eea71985bac3f10d08fb</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TRANSPOSE</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a2489ff30a8c5d4048038a90b640a038a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcol_vf</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a4d2fa6d46faace80e4d28f771cc1d2c1</anchor>
      <arglist>(float *dst, vl_size dst_stride, float const *src, vl_size src_width, vl_size src_height, vl_size src_stride, float const *filt, vl_index filt_begin, vl_index filt_end, int step, unsigned int flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcol_vd</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>aca77f25ca260644bfcba2b36efb0cb19</anchor>
      <arglist>(double *dst, vl_size dst_stride, double const *src, vl_size src_width, vl_size src_height, vl_size src_stride, double const *filt, vl_index filt_begin, vl_index filt_end, int step, unsigned int flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcoltri_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ab5561b2ed447b0099e7bf8dc79915382</anchor>
      <arglist>(float *dest, vl_size destStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride, vl_size filterSize, vl_size step, int unsigned flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcoltri_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ad624650d3ab3d609f68634f83623677c</anchor>
      <arglist>(double *dest, vl_size destStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride, vl_size filterSize, vl_size step, int unsigned flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a783087728b77a88fb701426acf587956</anchor>
      <arglist>(float *integral, vl_size integralStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a63f63ca0445077d4baf05db04a1921e5</anchor>
      <arglist>(double *integral, vl_size integralStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_i32</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a33c2c2a2dc57e86aa03f0f5288001c46</anchor>
      <arglist>(vl_int32 *integral, vl_size integralStride, vl_int32 const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_ui32</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ab02ddbe089220e3c33c548d2b45887a1</anchor>
      <arglist>(vl_uint32 *integral, vl_size integralStride, vl_uint32 const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_image_distance_transform_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ad13a54f025599cbde1e2f073733872b2</anchor>
      <arglist>(double const *image, vl_size numColumns, vl_size numRows, vl_size columnStride, vl_size rowStride, double *distanceTransform, vl_uindex *indexes, double coeff, double offset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_image_distance_transform_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ac20d3690d57a30ddb2937d051abaf192</anchor>
      <arglist>(float const *image, vl_size numColumns, vl_size numRows, vl_size columnStride, vl_size rowStride, float *distanceTransform, vl_uindex *indexes, float coeff, float offset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imsmooth_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ae57b15ab6308fb8a20f358267645657d</anchor>
      <arglist>(float *smoothed, vl_size smoothedStride, float const *image, vl_size width, vl_size height, vl_size stride, double sigmax, double sigmay)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imsmooth_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>af6c768d466c0c767bbad085166618daa</anchor>
      <arglist>(double *smoothed, vl_size smoothedStride, double const *image, vl_size width, vl_size height, vl_size stride, double sigmax, double sigmay)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imgradient_polar_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a0733fd424fee11f8f4028eb83af90c16</anchor>
      <arglist>(float *amplitudeGradient, float *angleGradient, vl_size gradWidthStride, vl_size gradHeightStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imgradient_polar_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a52fe17840f8ca2c5ef8f25a3f92cf30f</anchor>
      <arglist>(double *amplitudeGradient, double *angleGradient, vl_size gradWidthStride, vl_size gradHeightStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_BY_ZERO</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>af6e169f2ed366d16f9149a99d5574071</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_BY_CONTINUITY</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>aabcdd51c289c0d8db11dda9e26349a52</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PAD_MASK</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a2a4f0c469409eea71985bac3f10d08fb</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_TRANSPOSE</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a2489ff30a8c5d4048038a90b640a038a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcol_vf</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a4d2fa6d46faace80e4d28f771cc1d2c1</anchor>
      <arglist>(float *dst, vl_size dst_stride, float const *src, vl_size src_width, vl_size src_height, vl_size src_stride, float const *filt, vl_index filt_begin, vl_index filt_end, int step, unsigned int flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcol_vd</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>aca77f25ca260644bfcba2b36efb0cb19</anchor>
      <arglist>(double *dst, vl_size dst_stride, double const *src, vl_size src_width, vl_size src_height, vl_size src_stride, double const *filt, vl_index filt_begin, vl_index filt_end, int step, unsigned int flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcoltri_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ab5561b2ed447b0099e7bf8dc79915382</anchor>
      <arglist>(float *dest, vl_size destStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride, vl_size filterSize, vl_size step, int unsigned flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imconvcoltri_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ad624650d3ab3d609f68634f83623677c</anchor>
      <arglist>(double *dest, vl_size destStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride, vl_size filterSize, vl_size step, int unsigned flags)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a783087728b77a88fb701426acf587956</anchor>
      <arglist>(float *integral, vl_size integralStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a63f63ca0445077d4baf05db04a1921e5</anchor>
      <arglist>(double *integral, vl_size integralStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_i32</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a33c2c2a2dc57e86aa03f0f5288001c46</anchor>
      <arglist>(vl_int32 *integral, vl_size integralStride, vl_int32 const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imintegral_ui32</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ab02ddbe089220e3c33c548d2b45887a1</anchor>
      <arglist>(vl_uint32 *integral, vl_size integralStride, vl_uint32 const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_image_distance_transform_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ad13a54f025599cbde1e2f073733872b2</anchor>
      <arglist>(double const *image, vl_size numColumns, vl_size numRows, vl_size columnStride, vl_size rowStride, double *distanceTransform, vl_uindex *indexes, double coeff, double offset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_image_distance_transform_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ac20d3690d57a30ddb2937d051abaf192</anchor>
      <arglist>(float const *image, vl_size numColumns, vl_size numRows, vl_size columnStride, vl_size rowStride, float *distanceTransform, vl_uindex *indexes, float coeff, float offset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imsmooth_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>ae57b15ab6308fb8a20f358267645657d</anchor>
      <arglist>(float *smoothed, vl_size smoothedStride, float const *image, vl_size width, vl_size height, vl_size stride, double sigmax, double sigmay)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imsmooth_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>af6c768d466c0c767bbad085166618daa</anchor>
      <arglist>(double *smoothed, vl_size smoothedStride, double const *image, vl_size width, vl_size height, vl_size stride, double sigmax, double sigmay)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imgradient_polar_f</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a0733fd424fee11f8f4028eb83af90c16</anchor>
      <arglist>(float *amplitudeGradient, float *angleGradient, vl_size gradWidthStride, vl_size gradHeightStride, float const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_imgradient_polar_d</name>
      <anchorfile>imopv_8h.html</anchorfile>
      <anchor>a52fe17840f8ca2c5ef8f25a3f92cf30f</anchor>
      <arglist>(double *amplitudeGradient, double *angleGradient, vl_size gradWidthStride, vl_size gradHeightStride, double const *image, vl_size imageWidth, vl_size imageHeight, vl_size imageStride)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>imopv_sse2.c</name>
    <path>vl/</path>
    <filename>imopv__sse2_8c.html</filename>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <includes id="imopv__sse2_8h" name="imopv_sse2.h" local="yes" import="no" module="no" objc="no">imopv_sse2.h</includes>
    <includes id="imopv__sse2_8c" name="imopv_sse2.c" local="yes" import="no" module="no" objc="no">imopv_sse2.c</includes>
  </compound>
  <compound kind="file">
    <name>imopv_sse2.h</name>
    <path>vl/</path>
    <filename>imopv__sse2_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
  </compound>
  <compound kind="file">
    <name>kdtree.c</name>
    <path>vl/</path>
    <filename>kdtree_8c.html</filename>
    <includes id="kdtree_8h" name="kdtree.h" local="yes" import="no" module="no" objc="no">kdtree.h</includes>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="heap-def_8h" name="heap-def.h" local="yes" import="no" module="no" objc="no">heap-def.h</includes>
    <member kind="function" static="yes">
      <type>static vl_uindex</type>
      <name>vl_kdtree_node_new</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a94cd8f55cedbb5512a83c234103921e7</anchor>
      <arglist>(VlKDTree *tree, vl_uindex parentIndex)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_kdtree_compare_index_entries</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>af080598a5f9fe657bd3d3bdffe5c3a3d</anchor>
      <arglist>(void const *a, void const *b)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_kdtree_build_recursively</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>ac1b2bb2aa04dc77c102048d7f112fd5e</anchor>
      <arglist>(VlKDForest *forest, VlKDTree *tree, vl_uindex nodeIndex, vl_uindex dataBegin, vl_uindex dataEnd, unsigned int depth)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForest *</type>
      <name>vl_kdforest_new</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a055323ce27fa1f58d309e8fbceb95826</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numTrees, VlVectorComparisonType distance)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForestSearcher *</type>
      <name>vl_kdforest_new_searcher</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>af7d7d5546e9167678a4d73015fca4256</anchor>
      <arglist>(VlKDForest *kdforest)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforestsearcher_delete</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>aaf7bb0d93fffba8cc0b1967b6a94293a</anchor>
      <arglist>(VlKDForestSearcher *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_delete</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a68bcecfea6e63a41aafbd5ea9ca1a418</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>vl_kdtree_calc_bounds_recursively</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a435c39094d6a630a7393e76fc8506630</anchor>
      <arglist>(VlKDTree *tree, vl_uindex nodeIndex, double *searchBounds)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_build</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>ac886f1fd6024a74e9e4a5d7566b2125f</anchor>
      <arglist>(VlKDForest *self, vl_size numData, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_kdforest_query_recursively</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>ab0f262a9cbe09b77e5a6eddd2c6c81db</anchor>
      <arglist>(VlKDForestSearcher *searcher, VlKDTree *tree, vl_uindex nodeIndex, VlKDForestNeighbor *neighbors, vl_size numNeighbors, vl_size *numAddedNeighbors, double dist, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a2af87b58193ea0314fa971f8678e4e8c</anchor>
      <arglist>(VlKDForest *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforestsearcher_query</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a2a6c7a53e155d26b62409157d8be7fef</anchor>
      <arglist>(VlKDForestSearcher *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query_with_array</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a2b44b23d4ea1b3296a76c6a020831ac6</anchor>
      <arglist>(VlKDForest *self, vl_uint32 *indexes, vl_size numNeighbors, vl_size numQueries, void *distances, void const *queries)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_nodes_of_tree</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a766017f8aefa345762c3503f6a2b0b75</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_depth_of_tree</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a55728e3e3e7a3619ed24e8b016dbf2a4</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_trees</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a054701571177903a5369bb73da3139ef</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_max_num_comparisons</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a4bf926f9406cec740d564b703236c68d</anchor>
      <arglist>(VlKDForest *self, vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_max_num_comparisons</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>af0d6436d4b42826cf4aaf50b2ec59b53</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_thresholding_method</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>adf66cf1b6be55d82a2ad4d568271f157</anchor>
      <arglist>(VlKDForest *self, VlKDTreeThresholdingMethod method)</arglist>
    </member>
    <member kind="function">
      <type>VlKDTreeThresholdingMethod</type>
      <name>vl_kdforest_get_thresholding_method</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>ac153ede5b0d8716f2ae7887ef7060884</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_data_dimension</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a548f72a02684f50ed2fc5d54e256b752</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_kdforest_get_data_type</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>abba39fcd9a3693e9c8851b0b008c2db0</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForest *</type>
      <name>vl_kdforestsearcher_get_forest</name>
      <anchorfile>kdtree_8c.html</anchorfile>
      <anchor>a2fa383b0380658e86c3c8f5b2ab220c3</anchor>
      <arglist>(VlKDForestSearcher const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>kdtree.h</name>
    <path>vl/</path>
    <filename>kdtree_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <class kind="struct">VlKDForestNeighbor</class>
    <class kind="struct">VlKDForest</class>
    <class kind="struct">VlKDForestSearcher</class>
    <member kind="enumeration">
      <type></type>
      <name>VlKDTreeThresholdingMethod</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a7132289873fbe45803ce724beaa74364</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlKDForest *</type>
      <name>vl_kdforest_new</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>aac24c990e0e3e95a4fadafd968330665</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numTrees, VlVectorComparisonType normType)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForestSearcher *</type>
      <name>vl_kdforest_new_searcher</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>af7d7d5546e9167678a4d73015fca4256</anchor>
      <arglist>(VlKDForest *kdforest)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_delete</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a68bcecfea6e63a41aafbd5ea9ca1a418</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforestsearcher_delete</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a621a1c0691c271f8e24f27dbe32cf039</anchor>
      <arglist>(VlKDForestSearcher *searcher)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_build</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>ac886f1fd6024a74e9e4a5d7566b2125f</anchor>
      <arglist>(VlKDForest *self, vl_size numData, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a2af87b58193ea0314fa971f8678e4e8c</anchor>
      <arglist>(VlKDForest *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query_with_array</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a01338d575e98246f59dfa80c22e833d1</anchor>
      <arglist>(VlKDForest *self, vl_uint32 *index, vl_size numNeighbors, vl_size numQueries, void *distance, void const *queries)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforestsearcher_query</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a2a6c7a53e155d26b62409157d8be7fef</anchor>
      <arglist>(VlKDForestSearcher *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_depth_of_tree</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a55728e3e3e7a3619ed24e8b016dbf2a4</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_nodes_of_tree</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a766017f8aefa345762c3503f6a2b0b75</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_trees</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a054701571177903a5369bb73da3139ef</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_data_dimension</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a548f72a02684f50ed2fc5d54e256b752</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_kdforest_get_data_type</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>abba39fcd9a3693e9c8851b0b008c2db0</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_max_num_comparisons</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a4bf926f9406cec740d564b703236c68d</anchor>
      <arglist>(VlKDForest *self, vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_max_num_comparisons</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>af0d6436d4b42826cf4aaf50b2ec59b53</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_thresholding_method</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>adf66cf1b6be55d82a2ad4d568271f157</anchor>
      <arglist>(VlKDForest *self, VlKDTreeThresholdingMethod method)</arglist>
    </member>
    <member kind="function">
      <type>VlKDTreeThresholdingMethod</type>
      <name>vl_kdforest_get_thresholding_method</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>ac153ede5b0d8716f2ae7887ef7060884</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForest *</type>
      <name>vl_kdforest_new</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>aac24c990e0e3e95a4fadafd968330665</anchor>
      <arglist>(vl_type dataType, vl_size dimension, vl_size numTrees, VlVectorComparisonType normType)</arglist>
    </member>
    <member kind="function">
      <type>VlKDForestSearcher *</type>
      <name>vl_kdforest_new_searcher</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>af7d7d5546e9167678a4d73015fca4256</anchor>
      <arglist>(VlKDForest *kdforest)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_delete</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a68bcecfea6e63a41aafbd5ea9ca1a418</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforestsearcher_delete</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a621a1c0691c271f8e24f27dbe32cf039</anchor>
      <arglist>(VlKDForestSearcher *searcher)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_build</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>ac886f1fd6024a74e9e4a5d7566b2125f</anchor>
      <arglist>(VlKDForest *self, vl_size numData, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a2af87b58193ea0314fa971f8678e4e8c</anchor>
      <arglist>(VlKDForest *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_query_with_array</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a01338d575e98246f59dfa80c22e833d1</anchor>
      <arglist>(VlKDForest *self, vl_uint32 *index, vl_size numNeighbors, vl_size numQueries, void *distance, void const *queries)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforestsearcher_query</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a2a6c7a53e155d26b62409157d8be7fef</anchor>
      <arglist>(VlKDForestSearcher *self, VlKDForestNeighbor *neighbors, vl_size numNeighbors, void const *query)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_depth_of_tree</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a55728e3e3e7a3619ed24e8b016dbf2a4</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_nodes_of_tree</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a766017f8aefa345762c3503f6a2b0b75</anchor>
      <arglist>(VlKDForest const *self, vl_uindex treeIndex)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_num_trees</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a054701571177903a5369bb73da3139ef</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_data_dimension</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a548f72a02684f50ed2fc5d54e256b752</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_kdforest_get_data_type</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>abba39fcd9a3693e9c8851b0b008c2db0</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_max_num_comparisons</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>a4bf926f9406cec740d564b703236c68d</anchor>
      <arglist>(VlKDForest *self, vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kdforest_get_max_num_comparisons</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>af0d6436d4b42826cf4aaf50b2ec59b53</anchor>
      <arglist>(VlKDForest *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kdforest_set_thresholding_method</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>adf66cf1b6be55d82a2ad4d568271f157</anchor>
      <arglist>(VlKDForest *self, VlKDTreeThresholdingMethod method)</arglist>
    </member>
    <member kind="function">
      <type>VlKDTreeThresholdingMethod</type>
      <name>vl_kdforest_get_thresholding_method</name>
      <anchorfile>kdtree_8h.html</anchorfile>
      <anchor>ac153ede5b0d8716f2ae7887ef7060884</anchor>
      <arglist>(VlKDForest const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>kmeans.c</name>
    <path>vl/</path>
    <filename>kmeans_8c.html</filename>
    <includes id="kmeans_8h" name="kmeans.h" local="yes" import="no" module="no" objc="no">kmeans.h</includes>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="shuffle-def_8h" name="shuffle-def.h" local="yes" import="no" module="no" objc="no">shuffle-def.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_reset</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a77b5f58050110584e188534ad15c1dd0</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a3a087a1b2dea9ab110db5193d632c616</anchor>
      <arglist>(vl_type dataType, VlVectorComparisonType distance)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new_copy</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>aa98d53b8982193f1d1d18597d64023c4</anchor>
      <arglist>(VlKMeans const *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_delete</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a55a50b06dfd493861651200c61458609</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_centers</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>ac86bd2fa181f6e23e22a6ad92f25288c</anchor>
      <arglist>(VlKMeans *self, void const *centers, vl_size dimension, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_with_rand_data</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>ae32387a856746fe4c39ae10fd533c8d3</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimension, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_plus_plus</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a5867c89e2916d933ecbc383c4da348c9</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimension, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_quantize</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a3649fe42a94e9b4945511b5665f82355</anchor>
      <arglist>(VlKMeans *self, vl_uint32 *assignments, void *distances, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_quantize_ann</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>aa1b270ad6b6e303994629b74b4862f8e</anchor>
      <arglist>(VlKMeans *self, vl_uint32 *assignments, void *distances, void const *data, vl_size numData, vl_bool update)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_refine_centers</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a9fd1885e6b4742a93b4672f56eb9f2ce</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_cluster</name>
      <anchorfile>kmeans_8c.html</anchorfile>
      <anchor>a3f35fc9b75799b10a6e32ec81a9cd54d</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimension, vl_size numData, vl_size numCenters)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>kmeans.h</name>
    <path>vl/</path>
    <filename>kmeans_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="kdtree_8h" name="kdtree.h" local="yes" import="no" module="no" objc="no">kdtree.h</includes>
    <class kind="struct">VlKMeans</class>
    <member kind="enumeration">
      <type></type>
      <name>VlKMeansAlgorithm</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4c431fed2c5377435e08cbad0040c9f3</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKMeansLloyd</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4c431fed2c5377435e08cbad0040c9f3a19e04f61cc224d6f970a6cba351d6692</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKMeansElkan</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4c431fed2c5377435e08cbad0040c9f3a5f262d513ca0a82ddb577bbe31aa164c</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKMeansANN</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4c431fed2c5377435e08cbad0040c9f3adc59056a09e72cdca518cfd6860d0ce4</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlKMeansInitialization</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ab5a665f209dfbe8e9d53af18fdf489d5</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKMeansRandomSelection</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ab5a665f209dfbe8e9d53af18fdf489d5a60e94b6baf611109b87ca291ff86943b</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKMeansPlusPlus</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ab5a665f209dfbe8e9d53af18fdf489d5a314ecb9e2d2f166ce7199e1a6cb0594a</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3a087a1b2dea9ab110db5193d632c616</anchor>
      <arglist>(vl_type dataType, VlVectorComparisonType distance)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new_copy</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aa98d53b8982193f1d1d18597d64023c4</anchor>
      <arglist>(VlKMeans const *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_delete</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a55a50b06dfd493861651200c61458609</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_reset</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a77b5f58050110584e188534ad15c1dd0</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_cluster</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3f35fc9b75799b10a6e32ec81a9cd54d</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimension, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_quantize</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3649fe42a94e9b4945511b5665f82355</anchor>
      <arglist>(VlKMeans *self, vl_uint32 *assignments, void *distances, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ac86bd2fa181f6e23e22a6ad92f25288c</anchor>
      <arglist>(VlKMeans *self, void const *centers, vl_size dimension, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_with_rand_data</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4fca3ae363d35813cde918fddc41a456</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimensions, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_plus_plus</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a08f5ecf2c5b1a75f7dacd6f29b922020</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimensions, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_refine_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a9fd1885e6b4742a93b4672f56eb9f2ce</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_kmeans_get_data_type</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>abc797cd0e7228d096313fd97b412a21c</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlVectorComparisonType</type>
      <name>vl_kmeans_get_distance</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a61bd032e28960a20cf86e8c77577b67e</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeansAlgorithm</type>
      <name>vl_kmeans_get_algorithm</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae6d9f44be8b5d6fc71f11554de742a63</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeansInitialization</type>
      <name>vl_kmeans_get_initialization</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>af920d0fc7e802901fd071eec3def47d2</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_num_repetitions</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae84b1f054eacec5dd7cf2d54668ba181</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_dimension</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a16d8a8bb5d3d7484c4645561dc42ee53</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_num_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>acba49a529f1393cd04c02a6ef8e2cacd</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_kmeans_get_verbosity</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7747422051ced08941d2306951445d79</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_max_num_iterations</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a6312397c35e56ccd50ac1fa8dbc6bcc2</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_get_min_energy_variation</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a49bb2db622503ca24038be22e76aae24</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_max_num_comparisons</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aec83e043931adc13fe73f3e0a0586600</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_get_energy</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a02365a4146fabad03f76bb4cdad7cb77</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_kmeans_get_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a05bd0ac3529beeb460c3dcef4f1a594f</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_algorithm</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae2ab27c25bb4730d854219af20f37804</anchor>
      <arglist>(VlKMeans *self, VlKMeansAlgorithm algorithm)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_initialization</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7c61513feb74bb5393326ed3cced2650</anchor>
      <arglist>(VlKMeans *self, VlKMeansInitialization initialization)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_num_repetitions</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7a1095cdba2192ee48e15d19144315fb</anchor>
      <arglist>(VlKMeans *self, vl_size numRepetitions)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_max_num_iterations</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a34f80e7e3f4c7213366b88169cc2f70f</anchor>
      <arglist>(VlKMeans *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_min_energy_variation</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aa807a9a807f80ad1dc5359a81e06566b</anchor>
      <arglist>(VlKMeans *self, double minEnergyVariation)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_verbosity</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>af2411b97e440ef5419657c41273d38cb</anchor>
      <arglist>(VlKMeans *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_max_num_comparisons</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ac19079ea46c3b5d719dc66f81b38bb5a</anchor>
      <arglist>(VlKMeans *self, vl_size maxNumComparisons)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_num_trees</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a1a607e91823a83cbcb9c5eaecab99843</anchor>
      <arglist>(VlKMeans *self, vl_size numTrees)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3a087a1b2dea9ab110db5193d632c616</anchor>
      <arglist>(vl_type dataType, VlVectorComparisonType distance)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeans *</type>
      <name>vl_kmeans_new_copy</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aa98d53b8982193f1d1d18597d64023c4</anchor>
      <arglist>(VlKMeans const *kmeans)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_delete</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a55a50b06dfd493861651200c61458609</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_reset</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a77b5f58050110584e188534ad15c1dd0</anchor>
      <arglist>(VlKMeans *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_cluster</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3f35fc9b75799b10a6e32ec81a9cd54d</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimension, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_quantize</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a3649fe42a94e9b4945511b5665f82355</anchor>
      <arglist>(VlKMeans *self, vl_uint32 *assignments, void *distances, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ac86bd2fa181f6e23e22a6ad92f25288c</anchor>
      <arglist>(VlKMeans *self, void const *centers, vl_size dimension, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_with_rand_data</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a4fca3ae363d35813cde918fddc41a456</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimensions, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_init_centers_plus_plus</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a08f5ecf2c5b1a75f7dacd6f29b922020</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size dimensions, vl_size numData, vl_size numCenters)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_refine_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a9fd1885e6b4742a93b4672f56eb9f2ce</anchor>
      <arglist>(VlKMeans *self, void const *data, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>vl_type</type>
      <name>vl_kmeans_get_data_type</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>abc797cd0e7228d096313fd97b412a21c</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlVectorComparisonType</type>
      <name>vl_kmeans_get_distance</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a61bd032e28960a20cf86e8c77577b67e</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeansAlgorithm</type>
      <name>vl_kmeans_get_algorithm</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae6d9f44be8b5d6fc71f11554de742a63</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlKMeansInitialization</type>
      <name>vl_kmeans_get_initialization</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>af920d0fc7e802901fd071eec3def47d2</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_num_repetitions</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae84b1f054eacec5dd7cf2d54668ba181</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_dimension</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a16d8a8bb5d3d7484c4645561dc42ee53</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_num_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>acba49a529f1393cd04c02a6ef8e2cacd</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_kmeans_get_verbosity</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7747422051ced08941d2306951445d79</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_max_num_iterations</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a6312397c35e56ccd50ac1fa8dbc6bcc2</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_get_min_energy_variation</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a49bb2db622503ca24038be22e76aae24</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_kmeans_get_max_num_comparisons</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aec83e043931adc13fe73f3e0a0586600</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_kmeans_get_energy</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a02365a4146fabad03f76bb4cdad7cb77</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>void const *</type>
      <name>vl_kmeans_get_centers</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a05bd0ac3529beeb460c3dcef4f1a594f</anchor>
      <arglist>(VlKMeans const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_algorithm</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ae2ab27c25bb4730d854219af20f37804</anchor>
      <arglist>(VlKMeans *self, VlKMeansAlgorithm algorithm)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_initialization</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7c61513feb74bb5393326ed3cced2650</anchor>
      <arglist>(VlKMeans *self, VlKMeansInitialization initialization)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_num_repetitions</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a7a1095cdba2192ee48e15d19144315fb</anchor>
      <arglist>(VlKMeans *self, vl_size numRepetitions)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_max_num_iterations</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a34f80e7e3f4c7213366b88169cc2f70f</anchor>
      <arglist>(VlKMeans *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_min_energy_variation</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>aa807a9a807f80ad1dc5359a81e06566b</anchor>
      <arglist>(VlKMeans *self, double minEnergyVariation)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_verbosity</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>af2411b97e440ef5419657c41273d38cb</anchor>
      <arglist>(VlKMeans *self, int verbosity)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_max_num_comparisons</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>ac19079ea46c3b5d719dc66f81b38bb5a</anchor>
      <arglist>(VlKMeans *self, vl_size maxNumComparisons)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_kmeans_set_num_trees</name>
      <anchorfile>kmeans_8h.html</anchorfile>
      <anchor>a1a607e91823a83cbcb9c5eaecab99843</anchor>
      <arglist>(VlKMeans *self, vl_size numTrees)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>lbp.c</name>
    <path>vl/</path>
    <filename>lbp_8c.html</filename>
    <includes id="lbp_8h" name="lbp.h" local="yes" import="no" module="no" objc="no">lbp.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>VlLbp *</type>
      <name>vl_lbp_new</name>
      <anchorfile>lbp_8c.html</anchorfile>
      <anchor>ae0e80366f8ecf4570bbcae0b53b08cc5</anchor>
      <arglist>(VlLbpMappingType type, vl_bool transposed)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_lbp_delete</name>
      <anchorfile>lbp_8c.html</anchorfile>
      <anchor>af4061c7ff063118d14893cafe5b55ed8</anchor>
      <arglist>(VlLbp *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_lbp_get_dimension</name>
      <anchorfile>lbp_8c.html</anchorfile>
      <anchor>a9fdc1d38de7ce1494cdd911bfd8957a7</anchor>
      <arglist>(VlLbp *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_lbp_process</name>
      <anchorfile>lbp_8c.html</anchorfile>
      <anchor>a605c416d7ab3906609cbb62404a20253</anchor>
      <arglist>(VlLbp *self, float *features, float *image, vl_size width, vl_size height, vl_size cellSize)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>lbp.h</name>
    <path>vl/</path>
    <filename>lbp_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlLbp</class>
    <member kind="enumeration">
      <type></type>
      <name>VlLbpMappingType</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>add3c75c3439f492a9c4b445d80af3d48</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlLbpUniform</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>add3c75c3439f492a9c4b445d80af3d48a56d4fb4c61f28ddf9fb2569935a5a9a4</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlLbp *</type>
      <name>vl_lbp_new</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>ae0e80366f8ecf4570bbcae0b53b08cc5</anchor>
      <arglist>(VlLbpMappingType type, vl_bool transposed)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_lbp_delete</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>af4061c7ff063118d14893cafe5b55ed8</anchor>
      <arglist>(VlLbp *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_lbp_process</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>a605c416d7ab3906609cbb62404a20253</anchor>
      <arglist>(VlLbp *self, float *features, float *image, vl_size width, vl_size height, vl_size cellSize)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_lbp_get_dimension</name>
      <anchorfile>lbp_8h.html</anchorfile>
      <anchor>a9fdc1d38de7ce1494cdd911bfd8957a7</anchor>
      <arglist>(VlLbp *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>liop.c</name>
    <path>vl/</path>
    <filename>liop_8c.html</filename>
    <includes id="liop_8h" name="liop.h" local="yes" import="no" module="no" objc="no">liop.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <includes id="qsort-def_8h" name="qsort-def.h" local="yes" import="no" module="no" objc="no">qsort-def.h</includes>
    <member kind="function">
      <type>vl_index</type>
      <name>get_permutation_index</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>a4ea5d8f10dc339704875072b27e71737</anchor>
      <arglist>(vl_uindex *permutation, vl_size size)</arglist>
    </member>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>ae8ffbcd23d7236033b0cb6133a6b28fb</anchor>
      <arglist>(vl_int numNeighbours, vl_int numSpatialBins, float radius, vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new_basic</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>ab85b723fb632fe45253cd184866e545a</anchor>
      <arglist>(vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_delete</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>a2e765f1f59a64454f05999de06e48d28</anchor>
      <arglist>(VlLiopDesc *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_process</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>a33e638228068ce2674b23eee7af5ce43</anchor>
      <arglist>(VlLiopDesc *self, float *desc, float const *patch)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_dimension</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>aea42b7981535254d18c8d55a4c32f606</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_neighbours</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>ac90f67676f91f17d9f3b51df4dab4730</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_liopdesc_get_intensity_threshold</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>ad861a14df3f0236ca908726c9fbe269a</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_set_intensity_threshold</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>a1d385f07442b954b658ae419abdd31eb</anchor>
      <arglist>(VlLiopDesc *self, float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_liopdesc_get_neighbourhood_radius</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>a409893390d672968c871861a37c3dc0c</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_spatial_bins</name>
      <anchorfile>liop_8c.html</anchorfile>
      <anchor>afbb31827623d0b7f7957ba76e6a705cb</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>liop.h</name>
    <path>vl/</path>
    <filename>liop_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlLiopDesc</class>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ae8ffbcd23d7236033b0cb6133a6b28fb</anchor>
      <arglist>(vl_int numNeighbours, vl_int numSpatialBins, float radius, vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new_basic</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ab85b723fb632fe45253cd184866e545a</anchor>
      <arglist>(vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_delete</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a2e765f1f59a64454f05999de06e48d28</anchor>
      <arglist>(VlLiopDesc *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_dimension</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>aea42b7981535254d18c8d55a4c32f606</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_neighbours</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ac90f67676f91f17d9f3b51df4dab4730</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_liopdesc_get_intensity_threshold</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ad861a14df3f0236ca908726c9fbe269a</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_spatial_bins</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>afbb31827623d0b7f7957ba76e6a705cb</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_liopdesc_get_neighbourhood_radius</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a409893390d672968c871861a37c3dc0c</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_set_intensity_threshold</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a1d385f07442b954b658ae419abdd31eb</anchor>
      <arglist>(VlLiopDesc *self, float x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_process</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a027e15a74b23d371e90a5511d25c5f24</anchor>
      <arglist>(VlLiopDesc *liop, float *desc, float const *patch)</arglist>
    </member>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ae8ffbcd23d7236033b0cb6133a6b28fb</anchor>
      <arglist>(vl_int numNeighbours, vl_int numSpatialBins, float radius, vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>VlLiopDesc *</type>
      <name>vl_liopdesc_new_basic</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ab85b723fb632fe45253cd184866e545a</anchor>
      <arglist>(vl_size sideLength)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_delete</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a2e765f1f59a64454f05999de06e48d28</anchor>
      <arglist>(VlLiopDesc *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_dimension</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>aea42b7981535254d18c8d55a4c32f606</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_neighbours</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ac90f67676f91f17d9f3b51df4dab4730</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_liopdesc_get_intensity_threshold</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>ad861a14df3f0236ca908726c9fbe269a</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_liopdesc_get_num_spatial_bins</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>afbb31827623d0b7f7957ba76e6a705cb</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_liopdesc_get_neighbourhood_radius</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a409893390d672968c871861a37c3dc0c</anchor>
      <arglist>(VlLiopDesc const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_set_intensity_threshold</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a1d385f07442b954b658ae419abdd31eb</anchor>
      <arglist>(VlLiopDesc *self, float x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_liopdesc_process</name>
      <anchorfile>liop_8h.html</anchorfile>
      <anchor>a027e15a74b23d371e90a5511d25c5f24</anchor>
      <arglist>(VlLiopDesc *liop, float *desc, float const *patch)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>mathop.c</name>
    <path>vl/</path>
    <filename>mathop_8c.html</filename>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="mathop__sse2_8h" name="mathop_sse2.h" local="yes" import="no" module="no" objc="no">mathop_sse2.h</includes>
    <includes id="mathop__avx_8h" name="mathop_avx.h" local="yes" import="no" module="no" objc="no">mathop_avx.h</includes>
    <includes id="mathop_8c" name="mathop.c" local="yes" import="no" module="no" objc="no">mathop.c</includes>
  </compound>
  <compound kind="file">
    <name>mathop.h</name>
    <path>vl/</path>
    <filename>mathop_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_E</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a72021996fb98d3130ead10a4989f4ca5</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_LOG_OF_2</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a5103e2bf416806fb511feaa8ee96328f</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_PI</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a19d43a5e0c355df553ebe825208a4cc1</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_EPSILON_F</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a8088f3da04d6bce27544adaa6da948ca</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_EPSILON_D</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>aa2d957b08ce16011fc3827c270cd2664</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_NAN_F</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>afcbfd66dfa72bf495e08e1d622d6da0e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INFINITY_F</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a7c8e51b4132fa5072a31ec38770e22c6</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_NAN_D</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a3f9df65fc71880e96e21e93e3abfd99c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_INFINITY_D</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a9eb876cf62894be62a2467db9db0bb03</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>float(*</type>
      <name>VlFloatVectorComparisonFunction</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ab3bfc8e36e1d3a558ad4d1ba7d028bc1</anchor>
      <arglist>)(vl_size dimension, float const *X, float const *Y)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlDoubleVectorComparisonFunction</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a9f01157d716a8023720436416e5b7ebd</anchor>
      <arglist>)(vl_size dimension, double const *X, double const *Y)</arglist>
    </member>
    <member kind="typedef">
      <type>float(*</type>
      <name>VlFloatVector3ComparisonFunction</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a55ba767ecd79b6edebd798141f8f7a92</anchor>
      <arglist>)(vl_size dimension, float const *X, float const *Y, float const *Z)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlDoubleVector3ComparisonFunction</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a7673a4c14ad203748a8e94467ac990c4</anchor>
      <arglist>)(vl_size dimension, double const *X, double const *Y, double const *Z)</arglist>
    </member>
    <member kind="typedef">
      <type>enum _VlVectorComparisonType</type>
      <name>VlVectorComparisonType</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>aa4cc7d511f708d61bc8fe15c65ad6d74</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>_VlVectorComparisonType</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09ac</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceL1</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acaff42f6aa9da4f0d11415de32089a1348</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceL2</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acab44b9322465d703274acfa21690de9fd</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceChi2</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09aca8bd37a4dd18960b8faf2c52093227857</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceHellinger</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acaa2290709524875cbabbce86ba2d28635</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceJS</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acaed22a8624bfdae0b2ca92a43750bf68a</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlDistanceMahalanobis</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09aca0793259deafb1d691a1a6daed52b245b</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKernelL1</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09aca5e26182d2d853d6e16238535fd8f7f98</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKernelL2</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acaad5fb6e24379dd36f94bdfb10068ec6c</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKernelChi2</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acad945961afcae876365e585655b3dbdde</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKernelHellinger</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09acae6735870a9191f6f9c44492bd2fdeae8</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlKernelJS</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af7397bb42d71000754eafba9458b09aca2b327ebbf8e9ad7e76df758a9062145f</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_mod_2pi_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a99beafd23bc68c4bf8fb525e4efb2749</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mod_2pi_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a6ee66acb41ce542899a6e99e4fe5b6f3</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_floor_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a7651faad897e764d74159d4661777115</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_floor_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a4573abdff2b32ef131f090a7cd8afeee</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_ceil_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a2e33bdf5324485def067bbbe66a54f91</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_ceil_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a6a0c3cd1c2c65220bcdc472a5a9391d6</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_round_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a97fb4b325bc0dc8bb8618e132fab736c</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>long int</type>
      <name>vl_round_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>af3adf65b9d416b2438ccfe78748ed60f</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_abs_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a772d390dd8d1fb4adc4eda6e0d8f4c0b</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_abs_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a87c54a1c66beffacfba7bf7bac52fb09</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_log2_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a2b8296f9c8f1266500860fcb08bf29b5</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_log2_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a9d76b809ad52b5a4080cb94fdeac425e</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sqrt_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>aff464f96f4eb9651aef329228c68dcf9</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_sqrt_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a0b02ca15f62d4ec9056bf7f55324e0bc</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_is_nan_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a3752bdd4daa1e678178543f51ad18d72</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_is_nan_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a20334a5a243c1e6cee531e3f457b5a68</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_is_inf_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ab51e6a4e74b39c8b8226c682e317323b</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_is_inf_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a89b3b96cfa1fa17814e209721368f0f1</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_fast_atan2_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a302745de850d5b18b49359a830b74f6d</anchor>
      <arglist>(float y, float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_fast_atan2_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ae76d962e552bdddb02a687dd3dc38330</anchor>
      <arglist>(double y, double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_fast_resqrt_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a1a7ffdd0b23196a330e36d6e9aa8c6ff</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_fast_resqrt_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a8aab2f55af664aaef0d51b84fb09ebc7</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>float</type>
      <name>vl_fast_sqrt_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a69441a371eeaa0c183214d8f19204d46</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_fast_sqrt_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a8a7ca9f7a6df25bd6869f648f1e643d9</anchor>
      <arglist>(float x)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint64</type>
      <name>vl_fast_sqrt_ui64</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a15c07a9b9ec933f685115779c8913f5c</anchor>
      <arglist>(vl_uint64 x)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint32</type>
      <name>vl_fast_sqrt_ui32</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a07ed33a01737b8aa5716e46d1afdf0b8</anchor>
      <arglist>(vl_uint32 x)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint16</type>
      <name>vl_fast_sqrt_ui16</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a7475cc5573d9ff6147ebc9e97097740b</anchor>
      <arglist>(vl_uint16 x)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint8</type>
      <name>vl_fast_sqrt_ui8</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ad3ba8bee4d358e752175582321e96e10</anchor>
      <arglist>(vl_uint8 x)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_get_vector_comparison_type_name</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a84945e54da7315e1479f7153a1f75768</anchor>
      <arglist>(int type)</arglist>
    </member>
    <member kind="function">
      <type>VlFloatVectorComparisonFunction</type>
      <name>vl_get_vector_comparison_function_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ad5143f7d144cba8a1d302dacee14d23e</anchor>
      <arglist>(VlVectorComparisonType type)</arglist>
    </member>
    <member kind="function">
      <type>VlDoubleVectorComparisonFunction</type>
      <name>vl_get_vector_comparison_function_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a34ec850e1d4b291c4e7a4235206c23bd</anchor>
      <arglist>(VlVectorComparisonType type)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_eval_vector_comparison_on_all_pairs_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ae38ee42a415c7958c38c02ea57cf9b4e</anchor>
      <arglist>(float *result, vl_size dimension, float const *X, vl_size numDataX, float const *Y, vl_size numDataY, VlFloatVectorComparisonFunction function)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_eval_vector_comparison_on_all_pairs_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a2fa33c2469aa77aea316927d13e8e644</anchor>
      <arglist>(double *result, vl_size dimension, double const *X, vl_size numDataX, double const *Y, vl_size numDataY, VlDoubleVectorComparisonFunction function)</arglist>
    </member>
    <member kind="variable" static="yes">
      <type>static union @1</type>
      <name>vl_nan_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>a2930ae1c9c5c58257ef2ca4f7946ebc4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" static="yes">
      <type>static union @2</type>
      <name>vl_infinity_f</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>aa229f0ad87d42202ad17cdc019428455</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" static="yes">
      <type>static union @3</type>
      <name>vl_nan_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>ad5d519fcbb9f3c90414e6987df2e4cb5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable" static="yes">
      <type>static union @4</type>
      <name>vl_infinity_d</name>
      <anchorfile>mathop_8h.html</anchorfile>
      <anchor>afab36bf94fa017fd8c9023ab1c8caed1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>mathop_avx.c</name>
    <path>vl/</path>
    <filename>mathop__avx_8c.html</filename>
    <includes id="mathop__avx_8h" name="mathop_avx.h" local="yes" import="no" module="no" objc="no">mathop_avx.h</includes>
    <includes id="mathop__avx_8c" name="mathop_avx.c" local="yes" import="no" module="no" objc="no">mathop_avx.c</includes>
  </compound>
  <compound kind="file">
    <name>mathop_avx.h</name>
    <path>vl/</path>
    <filename>mathop__avx_8h.html</filename>
    <includes id="mathop__avx_8h" name="mathop_avx.h" local="yes" import="no" module="no" objc="no">mathop_avx.h</includes>
  </compound>
  <compound kind="file">
    <name>mathop_sse2.c</name>
    <path>vl/</path>
    <filename>mathop__sse2_8c.html</filename>
    <includes id="mathop__sse2_8h" name="mathop_sse2.h" local="yes" import="no" module="no" objc="no">mathop_sse2.h</includes>
    <includes id="mathop__sse2_8c" name="mathop_sse2.c" local="yes" import="no" module="no" objc="no">mathop_sse2.c</includes>
  </compound>
  <compound kind="file">
    <name>mathop_sse2.h</name>
    <path>vl/</path>
    <filename>mathop__sse2_8h.html</filename>
    <includes id="mathop__sse2_8h" name="mathop_sse2.h" local="yes" import="no" module="no" objc="no">mathop_sse2.h</includes>
  </compound>
  <compound kind="file">
    <name>mser.c</name>
    <path>vl/</path>
    <filename>mser_8c.html</filename>
    <includes id="mser_8h" name="mser.h" local="yes" import="no" module="no" objc="no">mser.h</includes>
    <member kind="function">
      <type>void</type>
      <name>adv</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>aef2b52041a114960ba86e2b61791dc21</anchor>
      <arglist>(int ndims, int const *dims, int *subs)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>climb</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>a95199af3632f9d161217f7932dce9066</anchor>
      <arglist>(VlMserReg *r, vl_uint idx)</arglist>
    </member>
    <member kind="function">
      <type>VlMserFilt *</type>
      <name>vl_mser_new</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>a56288ad0752452c54c1a768d12096a3f</anchor>
      <arglist>(int ndims, int const *dims)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_delete</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>a3d94ff216cb9389b49dc5799e26ad3ba</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_process</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>ae50c576bc27a1ee7837cbbe6e5089583</anchor>
      <arglist>(VlMserFilt *f, vl_mser_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_ell_fit</name>
      <anchorfile>mser_8c.html</anchorfile>
      <anchor>aeeee08edd486e41126316f1d3bf90013</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>mser.h</name>
    <path>vl/</path>
    <filename>mser_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">_VlMserStats</class>
    <class kind="struct">_VlMserReg</class>
    <class kind="struct">_VlMserExtrReg</class>
    <class kind="struct">_VlMserFilt</class>
    <member kind="define">
      <type>#define</type>
      <name>VL_MSER_PIX_MAXVAL</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>ab88df95be093992e6c90caf07711182a</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_MSER_VOID_NODE</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a8dedc365f221c110cee8b0634ab86241</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>vl_uint8</type>
      <name>vl_mser_pix</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a5f6872cfbb7787c2a38cc2d5f138c716</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>float</type>
      <name>vl_mser_acc</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a4da3be7334e5383e02c829c53ddb9e34</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlMserFilt *</type>
      <name>vl_mser_new</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a56288ad0752452c54c1a768d12096a3f</anchor>
      <arglist>(int ndims, int const *dims)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_delete</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a3d94ff216cb9389b49dc5799e26ad3ba</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_process</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>ae50c576bc27a1ee7837cbbe6e5089583</anchor>
      <arglist>(VlMserFilt *f, vl_mser_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_ell_fit</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>aeeee08edd486e41126316f1d3bf90013</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_regions_num</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a40ccc21a2849c0aec7d5f05205843402</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint const *</type>
      <name>vl_mser_get_regions</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a3e79dcb72a6ff1b0d7695257149017fa</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_mser_get_ell</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>ad2e8f40c8cd872941cb1756cac334cf0</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_ell_num</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a1f92bdb8142fdc6f256ebb98adac1d23</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_ell_dof</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a275a5df25b8b628f0e5315758f4e9b44</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>VlMserStats const *</type>
      <name>vl_mser_get_stats</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abe6d998cfec12cb5a5eeb7d3f05e3245</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_mser_pix</type>
      <name>vl_mser_get_delta</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abcd71f7677c7daf6902c022c825637de</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_min_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a82b28392b17bfd5bd6765e1cab61f049</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_max_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a9598f59824914b8cd39ff384cdf2d708</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_max_variation</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a546850260c72fa3ef1d5b5887a1240ad</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_min_diversity</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a420d10de58b8e7878c6e4708f223493f</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_delta</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a9aa9f3041186a969cb35268d4ab656bb</anchor>
      <arglist>(VlMserFilt *f, vl_mser_pix x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_min_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a25744f49395d441a8769b9f605480f4c</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_max_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>af517861a633fbd7cc5637ea4baef0db6</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_max_variation</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a7feb4b477fe6340639d40461174cfabe</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_min_diversity</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abb7fe6fc94bb7503bdc0dd160a549de1</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>VlMserFilt *</type>
      <name>vl_mser_new</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a56288ad0752452c54c1a768d12096a3f</anchor>
      <arglist>(int ndims, int const *dims)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_delete</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a3d94ff216cb9389b49dc5799e26ad3ba</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_process</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>ae50c576bc27a1ee7837cbbe6e5089583</anchor>
      <arglist>(VlMserFilt *f, vl_mser_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_ell_fit</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>aeeee08edd486e41126316f1d3bf90013</anchor>
      <arglist>(VlMserFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_regions_num</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a40ccc21a2849c0aec7d5f05205843402</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint const *</type>
      <name>vl_mser_get_regions</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a3e79dcb72a6ff1b0d7695257149017fa</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_mser_get_ell</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>ad2e8f40c8cd872941cb1756cac334cf0</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_ell_num</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a1f92bdb8142fdc6f256ebb98adac1d23</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint</type>
      <name>vl_mser_get_ell_dof</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a275a5df25b8b628f0e5315758f4e9b44</anchor>
      <arglist>(VlMserFilt const  *f)</arglist>
    </member>
    <member kind="function">
      <type>VlMserStats const *</type>
      <name>vl_mser_get_stats</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abe6d998cfec12cb5a5eeb7d3f05e3245</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_mser_pix</type>
      <name>vl_mser_get_delta</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abcd71f7677c7daf6902c022c825637de</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_min_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a82b28392b17bfd5bd6765e1cab61f049</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_max_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a9598f59824914b8cd39ff384cdf2d708</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_max_variation</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a546850260c72fa3ef1d5b5887a1240ad</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_mser_get_min_diversity</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a420d10de58b8e7878c6e4708f223493f</anchor>
      <arglist>(VlMserFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_delta</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a9aa9f3041186a969cb35268d4ab656bb</anchor>
      <arglist>(VlMserFilt *f, vl_mser_pix x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_min_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a25744f49395d441a8769b9f605480f4c</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_max_area</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>af517861a633fbd7cc5637ea4baef0db6</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_max_variation</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>a7feb4b477fe6340639d40461174cfabe</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_mser_set_min_diversity</name>
      <anchorfile>mser_8h.html</anchorfile>
      <anchor>abb7fe6fc94bb7503bdc0dd160a549de1</anchor>
      <arglist>(VlMserFilt *f, double x)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>pgm.c</name>
    <path>vl/</path>
    <filename>pgm_8c.html</filename>
    <includes id="pgm_8h" name="pgm.h" local="yes" import="no" module="no" objc="no">pgm.h</includes>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>remove_line</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>aec39fb8104ed58ac87b75e896fbb7ceb</anchor>
      <arglist>(FILE *f)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static int</type>
      <name>remove_blanks</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a7160d7d1836b470963d12b4e5997ea62</anchor>
      <arglist>(FILE *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_npixels</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>aa0e5d7cf948817fa0929b4216100665b</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_bpp</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>aef628fa82fec40803ce5cdcecdd82f14</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_head</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a829c23407220c6e7953ee45cca900565</anchor>
      <arglist>(FILE *f, VlPgmImage *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_data</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a5ff673e681338e79a1c1591179504b5f</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void *data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_insert</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a418f48a6aa8471ccaaf79640f4298d0a</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a5814312e5e026dc51396dd09b864fb8b</anchor>
      <arglist>(char const *name, VlPgmImage *im, vl_uint8 **data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new_f</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a8b9eb82a66e8cb72bdf6ab3ad1d30015</anchor>
      <arglist>(char const *name, VlPgmImage *im, float **data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>af2e33d504690aeff3eeb3e035727df9b</anchor>
      <arglist>(char const *name, vl_uint8 const *data, int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write_f</name>
      <anchorfile>pgm_8c.html</anchorfile>
      <anchor>a3751d1ee6548a567dd0860dfe921b498</anchor>
      <arglist>(char const *name, float const *data, int width, int height)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>pgm.h</name>
    <path>vl/</path>
    <filename>pgm_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <class kind="struct">VlPgmImage</class>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_HEAD</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aa0566322098c2b529a027f1f00a9b586</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_META</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>ad7d582518c6bbb8409649207443b0d42</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_DATA</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a4623e454d921cad79d89ad3783d46739</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_IO</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a8d09e3f8171e1531db2045fe33c023f5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_head</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a829c23407220c6e7953ee45cca900565</anchor>
      <arglist>(FILE *f, VlPgmImage *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_data</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a5ff673e681338e79a1c1591179504b5f</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void *data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_insert</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a418f48a6aa8471ccaaf79640f4298d0a</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_npixels</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aa0e5d7cf948817fa0929b4216100665b</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_bpp</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aef628fa82fec40803ce5cdcecdd82f14</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>af2e33d504690aeff3eeb3e035727df9b</anchor>
      <arglist>(char const *name, vl_uint8 const *data, int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write_f</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a3751d1ee6548a567dd0860dfe921b498</anchor>
      <arglist>(char const *name, float const *data, int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a5814312e5e026dc51396dd09b864fb8b</anchor>
      <arglist>(char const *name, VlPgmImage *im, vl_uint8 **data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new_f</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a8b9eb82a66e8cb72bdf6ab3ad1d30015</anchor>
      <arglist>(char const *name, VlPgmImage *im, float **data)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_HEAD</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aa0566322098c2b529a027f1f00a9b586</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_META</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>ad7d582518c6bbb8409649207443b0d42</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_INV_DATA</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a4623e454d921cad79d89ad3783d46739</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_ERR_PGM_IO</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a8d09e3f8171e1531db2045fe33c023f5</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_head</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a829c23407220c6e7953ee45cca900565</anchor>
      <arglist>(FILE *f, VlPgmImage *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_extract_data</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a5ff673e681338e79a1c1591179504b5f</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void *data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_insert</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a418f48a6aa8471ccaaf79640f4298d0a</anchor>
      <arglist>(FILE *f, VlPgmImage const *im, void const *data)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_npixels</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aa0e5d7cf948817fa0929b4216100665b</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_pgm_get_bpp</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>aef628fa82fec40803ce5cdcecdd82f14</anchor>
      <arglist>(VlPgmImage const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>af2e33d504690aeff3eeb3e035727df9b</anchor>
      <arglist>(char const *name, vl_uint8 const *data, int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_write_f</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a3751d1ee6548a567dd0860dfe921b498</anchor>
      <arglist>(char const *name, float const *data, int width, int height)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a5814312e5e026dc51396dd09b864fb8b</anchor>
      <arglist>(char const *name, VlPgmImage *im, vl_uint8 **data)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_pgm_read_new_f</name>
      <anchorfile>pgm_8h.html</anchorfile>
      <anchor>a8b9eb82a66e8cb72bdf6ab3ad1d30015</anchor>
      <arglist>(char const *name, VlPgmImage *im, float **data)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>qsort-def.h</name>
    <path>vl/</path>
    <filename>qsort-def_8h.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_QSORT_array</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>a09b2946a2aa460a9d33a78f46056059c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_QSORT_prefix</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>a6bc1350759ef49165982d85fe1996be3</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_QSORT_type</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>aa7bbcd78393c03275c0e3d55c1decdb0</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_QSORT_array</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>a09b2946a2aa460a9d33a78f46056059c</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VL_QSORT_type</type>
      <name>VL_QSORT_cmp</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>a846b82fcc68f6bb540da6243d2670ed1</anchor>
      <arglist>(VL_QSORT_array_const array, vl_uindex indexA, vl_uindex indexB)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_QSORT_swap</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>ac7face14222e47cac7d730925637ac91</anchor>
      <arglist>(VL_QSORT_array array, vl_uindex indexA, vl_uindex indexB)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_QSORT_sort_recursive</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>aa91794fadc74f98458f58a22cd0bd6ae</anchor>
      <arglist>(VL_QSORT_array array, vl_uindex begin, vl_uindex end)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_QSORT_sort</name>
      <anchorfile>qsort-def_8h.html</anchorfile>
      <anchor>a11be07172455010601a417058008ffa4</anchor>
      <arglist>(VL_QSORT_array array, vl_size size)</arglist>
    </member>
    <docanchor file="qsort-def_8h.html" title="Overview">qsort-def-overview</docanchor>
    <docanchor file="qsort-def_8h.html" title="Usage">qsort-def-usage</docanchor>
  </compound>
  <compound kind="file">
    <name>quickshift.c</name>
    <path>vl/</path>
    <filename>quickshift_8c.html</filename>
    <includes id="quickshift_8h" name="quickshift.h" local="yes" import="no" module="no" objc="no">quickshift.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_distance</name>
      <anchorfile>quickshift_8c.html</anchorfile>
      <anchor>aa70ffb9d0d0c62908a46b425604a7065</anchor>
      <arglist>(vl_qs_type const *I, int N1, int N2, int K, int i1, int i2, int j1, int j2)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_inner</name>
      <anchorfile>quickshift_8c.html</anchorfile>
      <anchor>a7d317b966c114ce48d921fbeeef13a3c</anchor>
      <arglist>(vl_qs_type const *I, int N1, int N2, int K, int i1, int i2, int j1, int j2)</arglist>
    </member>
    <member kind="function">
      <type>VlQS *</type>
      <name>vl_quickshift_new</name>
      <anchorfile>quickshift_8c.html</anchorfile>
      <anchor>a4d53cb708777d4d84eb224094fcfd5b9</anchor>
      <arglist>(vl_qs_type const *image, int height, int width, int channels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_process</name>
      <anchorfile>quickshift_8c.html</anchorfile>
      <anchor>aebfc7337283b7a8f8be1a1c0fd4f5f92</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_delete</name>
      <anchorfile>quickshift_8c.html</anchorfile>
      <anchor>a9c2a39344fb684d899f22faf358425e8</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>quickshift.h</name>
    <path>vl/</path>
    <filename>quickshift_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <class kind="struct">VlQS</class>
    <member kind="define">
      <type>#define</type>
      <name>VL_QS_INF</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a674ebf4b93ac727a31df15e6d5a45b91</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>double</type>
      <name>vl_qs_type</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>aee7aaa0947ccf164d8072bd798f419e2</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlQS *</type>
      <name>vl_quickshift_new</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a7893c61e3daae6462e7aa92ee872c5d0</anchor>
      <arglist>(vl_qs_type const *im, int height, int width, int channels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_delete</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a9c2a39344fb684d899f22faf358425e8</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_process</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>aebfc7337283b7a8f8be1a1c0fd4f5f92</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_get_max_dist</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a0a6c066b205bf0382d19b7c9fe8628d5</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_get_kernel_size</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a929d3f6d37b578d40edddb0e6aa9d4e3</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_quickshift_get_medoid</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a199679a6a594f25a690c97d5c67515a0</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>int *</type>
      <name>vl_quickshift_get_parents</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ab116d2dbad717ce889e56ea8335a1463</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type *</type>
      <name>vl_quickshift_get_dists</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a675666418f0bc2665be61f0b243a8c1d</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type *</type>
      <name>vl_quickshift_get_density</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>acceb1733e008e0542164429e92253837</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_max_dist</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ac54275b6b97121f41cf3b64d9e6210a3</anchor>
      <arglist>(VlQS *q, vl_qs_type tau)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_kernel_size</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ae54ca4abe8fb6ba0b8a8306d053b7628</anchor>
      <arglist>(VlQS *q, vl_qs_type sigma)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_medoid</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>aacf51684900938c0eaec425e742d0a76</anchor>
      <arglist>(VlQS *q, vl_bool medoid)</arglist>
    </member>
    <member kind="function">
      <type>VlQS *</type>
      <name>vl_quickshift_new</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a7893c61e3daae6462e7aa92ee872c5d0</anchor>
      <arglist>(vl_qs_type const *im, int height, int width, int channels)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_delete</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a9c2a39344fb684d899f22faf358425e8</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_process</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>aebfc7337283b7a8f8be1a1c0fd4f5f92</anchor>
      <arglist>(VlQS *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_get_max_dist</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a0a6c066b205bf0382d19b7c9fe8628d5</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type</type>
      <name>vl_quickshift_get_kernel_size</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a929d3f6d37b578d40edddb0e6aa9d4e3</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_quickshift_get_medoid</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a199679a6a594f25a690c97d5c67515a0</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>int *</type>
      <name>vl_quickshift_get_parents</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ab116d2dbad717ce889e56ea8335a1463</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type *</type>
      <name>vl_quickshift_get_dists</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>a675666418f0bc2665be61f0b243a8c1d</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>vl_qs_type *</type>
      <name>vl_quickshift_get_density</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>acceb1733e008e0542164429e92253837</anchor>
      <arglist>(VlQS const *q)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_max_dist</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ac54275b6b97121f41cf3b64d9e6210a3</anchor>
      <arglist>(VlQS *q, vl_qs_type tau)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_kernel_size</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>ae54ca4abe8fb6ba0b8a8306d053b7628</anchor>
      <arglist>(VlQS *q, vl_qs_type sigma)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_quickshift_set_medoid</name>
      <anchorfile>quickshift_8h.html</anchorfile>
      <anchor>aacf51684900938c0eaec425e742d0a76</anchor>
      <arglist>(VlQS *q, vl_bool medoid)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>random.c</name>
    <path>vl/</path>
    <filename>random_8c.html</filename>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_init</name>
      <anchorfile>random_8c.html</anchorfile>
      <anchor>adc85f15763be5c5de846697a2af843df</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed</name>
      <anchorfile>random_8c.html</anchorfile>
      <anchor>afd8d168b5b154f5f03615fda291b9364</anchor>
      <arglist>(VlRand *self, vl_uint32 s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed_by_array</name>
      <anchorfile>random_8c.html</anchorfile>
      <anchor>a165da1d589640d329cddb64c779f813a</anchor>
      <arglist>(VlRand *self, vl_uint32 const key[], vl_size keySize)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_permute_indexes</name>
      <anchorfile>random_8c.html</anchorfile>
      <anchor>af6690a982b19ecd8fcebe2909176d1f9</anchor>
      <arglist>(VlRand *self, vl_index *array, vl_size size)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint32</type>
      <name>vl_rand_uint32</name>
      <anchorfile>random_8c.html</anchorfile>
      <anchor>a0b444c85bf8f37b8b8050d66b9b0ab8b</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>random.h</name>
    <path>vl/</path>
    <filename>random_8h.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <class kind="struct">VlRand</class>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_permute_indexes</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>af6690a982b19ecd8fcebe2909176d1f9</anchor>
      <arglist>(VlRand *self, vl_index *array, vl_size size)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_init</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>adc85f15763be5c5de846697a2af843df</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>afd8d168b5b154f5f03615fda291b9364</anchor>
      <arglist>(VlRand *self, vl_uint32 s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed_by_array</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a165da1d589640d329cddb64c779f813a</anchor>
      <arglist>(VlRand *self, vl_uint32 const key[], vl_size keySize)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint64</type>
      <name>vl_rand_uint64</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a04b5a46e955520edca48e8266db1057c</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_int64</type>
      <name>vl_rand_int63</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a0f97cfce8f7f71de9a8ff7b78bb6660c</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint32</type>
      <name>vl_rand_uint32</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a0b444c85bf8f37b8b8050d66b9b0ab8b</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_int32</type>
      <name>vl_rand_int31</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a4e4ed13a370eaa931eb5b55f4182c520</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real1</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a9a615000c94ea12981fe04f3f12c8202</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real2</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a77c6737e2516d762e71acf4c6c700f0f</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real3</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a1de78dd0192fe5168f47e7181f94aeae</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_res53</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a610a2d1017c661151d70711f4dfc9e05</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_rand_uindex</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>abef2fe4cfd0c0d532b7c43b7960bd188</anchor>
      <arglist>(VlRand *self, vl_uindex range)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_init</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>adc85f15763be5c5de846697a2af843df</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>afd8d168b5b154f5f03615fda291b9364</anchor>
      <arglist>(VlRand *self, vl_uint32 s)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_rand_seed_by_array</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a165da1d589640d329cddb64c779f813a</anchor>
      <arglist>(VlRand *self, vl_uint32 const key[], vl_size keySize)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint64</type>
      <name>vl_rand_uint64</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a04b5a46e955520edca48e8266db1057c</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_int64</type>
      <name>vl_rand_int63</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a0f97cfce8f7f71de9a8ff7b78bb6660c</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_uint32</type>
      <name>vl_rand_uint32</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a0b444c85bf8f37b8b8050d66b9b0ab8b</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_int32</type>
      <name>vl_rand_int31</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a4e4ed13a370eaa931eb5b55f4182c520</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real1</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a9a615000c94ea12981fe04f3f12c8202</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real2</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a77c6737e2516d762e71acf4c6c700f0f</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_real3</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a1de78dd0192fe5168f47e7181f94aeae</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_rand_res53</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>a610a2d1017c661151d70711f4dfc9e05</anchor>
      <arglist>(VlRand *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_uindex</type>
      <name>vl_rand_uindex</name>
      <anchorfile>random_8h.html</anchorfile>
      <anchor>abef2fe4cfd0c0d532b7c43b7960bd188</anchor>
      <arglist>(VlRand *self, vl_uindex range)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>rodrigues.c</name>
    <path>vl/</path>
    <filename>rodrigues_8c.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <includes id="rodrigues_8h" name="rodrigues.h" local="yes" import="no" module="no" objc="no">rodrigues.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_rodrigues</name>
      <anchorfile>rodrigues_8c.html</anchorfile>
      <anchor>aecd536d61f6f0f4c1d91a1df68da44bd</anchor>
      <arglist>(double *R_pt, double *dR_pt, const double *om_pt)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_irodrigues</name>
      <anchorfile>rodrigues_8c.html</anchorfile>
      <anchor>a93ca856ba44cf313789442ed622b32fb</anchor>
      <arglist>(double *om_pt, double *dom_pt, const double *R_pt)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>rodrigues.h</name>
    <path>vl/</path>
    <filename>rodrigues_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_rodrigues</name>
      <anchorfile>rodrigues_8h.html</anchorfile>
      <anchor>aecd536d61f6f0f4c1d91a1df68da44bd</anchor>
      <arglist>(double *R_pt, double *dR_pt, const double *om_pt)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_irodrigues</name>
      <anchorfile>rodrigues_8h.html</anchorfile>
      <anchor>a93ca856ba44cf313789442ed622b32fb</anchor>
      <arglist>(double *om_pt, double *dom_pt, const double *R_pt)</arglist>
    </member>
    <docanchor file="rodrigues_8h.html" title="Rodrigues formulas">rodrigues</docanchor>
  </compound>
  <compound kind="file">
    <name>scalespace.c</name>
    <path>vl/</path>
    <filename>scalespace_8c.html</filename>
    <includes id="scalespace_8h" name="scalespace.h" local="yes" import="no" module="no" objc="no">scalespace.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_default_geometry</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>ab9a838a41d9fe1e04f1477061055b6d9</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_scalespacegeometry_is_equal</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>ad515a7ec3d620d6b55f9869c5318b546</anchor>
      <arglist>(VlScaleSpaceGeometry a, VlScaleSpaceGeometry b)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_geometry</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a13e0136527672f35a76ffb60fcea2bba</anchor>
      <arglist>(VlScaleSpace const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceOctaveGeometry</type>
      <name>vl_scalespace_get_octave_geometry</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a5c63aee8d9c6e9393308eb3306264108</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>float *</type>
      <name>vl_scalespace_get_level</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a02a6518f9c1657db18bfd182d908a3d8</anchor>
      <arglist>(VlScaleSpace *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_scalespace_get_level_const</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a4624191b911aa6dc7552ec5ba562789e</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_scalespace_get_level_sigma</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a105e697419bf9ddfaef70e498353a968</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>copy_and_upsample</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a3af937d6abc261c74ead647e7feb01e7</anchor>
      <arglist>(float *destination, float const *source, vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>copy_and_downsample</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a603b9912ae52a8ac7cf10e38409ec54f</anchor>
      <arglist>(float *destination, float const *source, vl_size width, vl_size height, vl_size numOctaves)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>ac206ef14cefd04b93df4afeaec666af5</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_with_geometry</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>ab477858e0a4aec416557f2931923bb81</anchor>
      <arglist>(VlScaleSpaceGeometry geom)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_copy</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a662bcfe97965e39f9291504386027798</anchor>
      <arglist>(VlScaleSpace *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_shallow_copy</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>aeffdbd9b11be06a48a0c2b2e1b5f3b31</anchor>
      <arglist>(VlScaleSpace *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_delete</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>af4d66bec63bb5a3670f55a2fa7786830</anchor>
      <arglist>(VlScaleSpace *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_scalespace_fill_octave</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a565eee225a634d2a45b1ea7ed7526f05</anchor>
      <arglist>(VlScaleSpace *self, vl_index o)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_scalespace_start_octave_from_image</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>abe23f0dea09f128255452886a397fdc8</anchor>
      <arglist>(VlScaleSpace *self, float const *image, vl_index o)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_scalespace_start_octave_from_previous_octave</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>ab787be9d4225a542ace408f89b07818c</anchor>
      <arglist>(VlScaleSpace *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_put_image</name>
      <anchorfile>scalespace_8c.html</anchorfile>
      <anchor>a2e2be28c7c1017222fec22a8c0df02f5</anchor>
      <arglist>(VlScaleSpace *self, float const *image)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>scalespace.h</name>
    <path>vl/</path>
    <filename>scalespace_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <class kind="struct">VlScaleSpaceGeometry</class>
    <class kind="struct">VlScaleSpaceOctaveGeometry</class>
    <member kind="function">
      <type>vl_bool</type>
      <name>vl_scalespacegeometry_is_equal</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ad515a7ec3d620d6b55f9869c5318b546</anchor>
      <arglist>(VlScaleSpaceGeometry a, VlScaleSpaceGeometry b)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_default_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ab9a838a41d9fe1e04f1477061055b6d9</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ac206ef14cefd04b93df4afeaec666af5</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_with_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ab477858e0a4aec416557f2931923bb81</anchor>
      <arglist>(VlScaleSpaceGeometry geom)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_copy</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>afe050026e38c8e323728150745f8cfb0</anchor>
      <arglist>(VlScaleSpace *src)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_shallow_copy</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a91ea755e1a3f50427d553a11482ce85a</anchor>
      <arglist>(VlScaleSpace *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_delete</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>af4d66bec63bb5a3670f55a2fa7786830</anchor>
      <arglist>(VlScaleSpace *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_put_image</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a2e2be28c7c1017222fec22a8c0df02f5</anchor>
      <arglist>(VlScaleSpace *self, float const *image)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a13e0136527672f35a76ffb60fcea2bba</anchor>
      <arglist>(VlScaleSpace const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceOctaveGeometry</type>
      <name>vl_scalespace_get_octave_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a5c63aee8d9c6e9393308eb3306264108</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>float *</type>
      <name>vl_scalespace_get_level</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a02a6518f9c1657db18bfd182d908a3d8</anchor>
      <arglist>(VlScaleSpace *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_scalespace_get_level_const</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a4624191b911aa6dc7552ec5ba562789e</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_scalespace_get_level_sigma</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a105e697419bf9ddfaef70e498353a968</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_default_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ab9a838a41d9fe1e04f1477061055b6d9</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ac206ef14cefd04b93df4afeaec666af5</anchor>
      <arglist>(vl_size width, vl_size height)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_with_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>ab477858e0a4aec416557f2931923bb81</anchor>
      <arglist>(VlScaleSpaceGeometry geom)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_copy</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>afe050026e38c8e323728150745f8cfb0</anchor>
      <arglist>(VlScaleSpace *src)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpace *</type>
      <name>vl_scalespace_new_shallow_copy</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a91ea755e1a3f50427d553a11482ce85a</anchor>
      <arglist>(VlScaleSpace *src)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_delete</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>af4d66bec63bb5a3670f55a2fa7786830</anchor>
      <arglist>(VlScaleSpace *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_scalespace_put_image</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a2e2be28c7c1017222fec22a8c0df02f5</anchor>
      <arglist>(VlScaleSpace *self, float const *image)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceGeometry</type>
      <name>vl_scalespace_get_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a13e0136527672f35a76ffb60fcea2bba</anchor>
      <arglist>(VlScaleSpace const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlScaleSpaceOctaveGeometry</type>
      <name>vl_scalespace_get_octave_geometry</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a5c63aee8d9c6e9393308eb3306264108</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o)</arglist>
    </member>
    <member kind="function">
      <type>float *</type>
      <name>vl_scalespace_get_level</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a02a6518f9c1657db18bfd182d908a3d8</anchor>
      <arglist>(VlScaleSpace *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>float const *</type>
      <name>vl_scalespace_get_level_const</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a4624191b911aa6dc7552ec5ba562789e</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_scalespace_get_level_sigma</name>
      <anchorfile>scalespace_8h.html</anchorfile>
      <anchor>a105e697419bf9ddfaef70e498353a968</anchor>
      <arglist>(VlScaleSpace const *self, vl_index o, vl_index s)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>shuffle-def.h</name>
    <path>vl/</path>
    <filename>shuffle-def_8h.html</filename>
    <includes id="host_8h" name="host.h" local="yes" import="no" module="no" objc="no">host.h</includes>
    <includes id="random_8h" name="random.h" local="yes" import="no" module="no" objc="no">random.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHUFFLE_array</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>a1b2ff17424758cd25468688d9eeb9768</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHUFFLE_prefix</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>a0f4417ddb60f347306e145cddc70632b</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHUFFLE_type</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>a1148a2ce5fc323d5c524e0f5d28f7702</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_SHUFFLE_array</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>a1b2ff17424758cd25468688d9eeb9768</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_SHUFFLE_swap</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>ad670015d69c1236260f8931a4e34dc7e</anchor>
      <arglist>(VL_SHUFFLE_array array, vl_uindex indexA, vl_uindex indexB)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>VL_SHUFFLE_shuffle</name>
      <anchorfile>shuffle-def_8h.html</anchorfile>
      <anchor>a81c4e7b542befcbed0beaabbf7535e3c</anchor>
      <arglist>(VL_SHUFFLE_array array, vl_size size, VlRand *rand)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>sift.c</name>
    <path>vl/</path>
    <filename>sift_8c.html</filename>
    <includes id="sift_8h" name="sift.h" local="yes" import="no" module="no" objc="no">sift.h</includes>
    <includes id="imopv_8h" name="imopv.h" local="yes" import="no" module="no" objc="no">imopv.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_SIFT_BILINEAR_ORIENTATIONS</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a3292b2feb6b1aba4f34ba037f15bc2d0</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>EXPN_SZ</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a98146d82a06b921641fa84448c41343d</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>EXPN_MAX</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a4b559178f5db3bdf1ae9b89b58a703da</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>fast_expn</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>af6d47c007c0b124e219efeccd80d9888</anchor>
      <arglist>(double x)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>fast_expn_init</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a1ba399b1016b22b00d36111f94a414c4</anchor>
      <arglist>()</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>copy_and_upsample_rows</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>aeb42c89bf4510234d60ba3eef7010c29</anchor>
      <arglist>(vl_sift_pix *dst, vl_sift_pix const *src, int width, int height)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>_vl_sift_smooth</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>aa3b643d6efaaeebb3107ecb11d398e8a</anchor>
      <arglist>(VlSiftFilt *self, vl_sift_pix *outputImage, vl_sift_pix *tempImage, vl_sift_pix const *inputImage, vl_size width, vl_size height, double sigma)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>copy_and_downsample</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a457daa5f995f4b946c1a44a45e7702bb</anchor>
      <arglist>(vl_sift_pix *dst, vl_sift_pix const *src, int width, int height, int d)</arglist>
    </member>
    <member kind="function">
      <type>VlSiftFilt *</type>
      <name>vl_sift_new</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a64ce14306bb4f96bef67c53d8c84064a</anchor>
      <arglist>(int width, int height, int noctaves, int nlevels, int o_min)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_delete</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>ab242293326626641411e7d7f43a109b2</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_first_octave</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a97cca9a09efaadc9dd0671912b9d5e05</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_next_octave</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a610cab1a3bf7d38e389afda9037f14da</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_detect</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a65c55820964f4f6609ca9ef1d547b2c4</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function" static="yes">
      <type>static void</type>
      <name>update_gradient</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>ace1fba61b0cc6ad7b1b0f9a07eabdf87</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_calc_keypoint_orientations</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a2e409d464f81582dc3e839bf0fece66e</anchor>
      <arglist>(VlSiftFilt *f, double angles[4], VlSiftKeypoint const *k)</arglist>
    </member>
    <member kind="function">
      <type>vl_sift_pix</type>
      <name>normalize_histogram</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a8cde1754325194d2bcfb08474b4b573a</anchor>
      <arglist>(vl_sift_pix *begin, vl_sift_pix *end)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_raw_descriptor</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a335f3295ba77b3bb937e5272fe1a02fc</anchor>
      <arglist>(VlSiftFilt const *f, vl_sift_pix const *grad, vl_sift_pix *descr, int width, int height, double x, double y, double sigma, double angle0)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_keypoint_descriptor</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a85f3878a53ef7151b569c1b3ea4d13b6</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix *descr, VlSiftKeypoint const *k, double angle0)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_keypoint_init</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a6f3fc8e38b6c0c520cb90b1a63ddc031</anchor>
      <arglist>(VlSiftFilt const *f, VlSiftKeypoint *k, double x, double y, double sigma)</arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>expn_tab</name>
      <anchorfile>sift_8c.html</anchorfile>
      <anchor>a6bfe7ecf9f4b9125e9613e90e4dc8971</anchor>
      <arglist>[EXPN_SZ+1]</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>sift.h</name>
    <path>vl/</path>
    <filename>sift_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlSiftKeypoint</class>
    <class kind="struct">VlSiftFilt</class>
    <member kind="typedef">
      <type>float</type>
      <name>vl_sift_pix</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a7efac4fb08e4642f12ef439ac376a5cc</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlSiftFilt *</type>
      <name>vl_sift_new</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a64ce14306bb4f96bef67c53d8c84064a</anchor>
      <arglist>(int width, int height, int noctaves, int nlevels, int o_min)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_delete</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ab242293326626641411e7d7f43a109b2</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_first_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a97cca9a09efaadc9dd0671912b9d5e05</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_next_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a610cab1a3bf7d38e389afda9037f14da</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_detect</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a65c55820964f4f6609ca9ef1d547b2c4</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_calc_keypoint_orientations</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a2e409d464f81582dc3e839bf0fece66e</anchor>
      <arglist>(VlSiftFilt *f, double angles[4], VlSiftKeypoint const *k)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_keypoint_descriptor</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a19140d86df12ff8c211c2728209de9b1</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix *descr, VlSiftKeypoint const *k, double angle)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_raw_descriptor</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a46d3e864618b4a940c2099b7c1f7b6a6</anchor>
      <arglist>(VlSiftFilt const *f, vl_sift_pix const *image, vl_sift_pix *descr, int widht, int height, double x, double y, double s, double angle0)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_keypoint_init</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a6f3fc8e38b6c0c520cb90b1a63ddc031</anchor>
      <arglist>(VlSiftFilt const *f, VlSiftKeypoint *k, double x, double y, double sigma)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_index</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a70186e579c8eff1bcabf408f46169cad</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_noctaves</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a5e0cd96b3985635b82adabc3ce8b2242</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_first</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aa3db07e91c86f992c31b8e2335a760a9</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_width</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a89bd76ab5c1e584ff8e46dfdc93ea748</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_height</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a9769e8f6d84ec75804e873229526eb10</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_nlevels</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a751c116352e72eed8a111e7c1e06a18e</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_nkeypoints</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aa45b8e7413384c7d6525f439e68856fe</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_peak_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a08959e6a90c98bf397e3430e79a6ea9c</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_edge_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>adb5b0159af92e1ce1462ddaaaa55a747</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_norm_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ad4b57c390ca004dc56b0b0b1abf0c7a9</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_magnif</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ae0272723812d5072619475d4787be78e</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_window_size</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a76053a5e655b9577995fea0fbe429078</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_sift_pix *</type>
      <name>vl_sift_get_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a400759060e87dc7a6264555b90b0a221</anchor>
      <arglist>(VlSiftFilt const *f, int s)</arglist>
    </member>
    <member kind="function">
      <type>VlSiftKeypoint const *</type>
      <name>vl_sift_get_keypoints</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aed757b23c8f615eb8c6f6a450a0f847f</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_peak_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>af69118a1c5d4d17bccac87d11fe8ce8f</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_edge_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ab7173b402b85de43ebf36fcabde77508</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_norm_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a86703f33aad31638909acd9697f93115</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_magnif</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a595579dd7952807c074c5311a6500121</anchor>
      <arglist>(VlSiftFilt *f, double m)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_window_size</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>af5996cc6171c6e3c8810fb400abbad21</anchor>
      <arglist>(VlSiftFilt *f, double x)</arglist>
    </member>
    <member kind="function">
      <type>VlSiftFilt *</type>
      <name>vl_sift_new</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a64ce14306bb4f96bef67c53d8c84064a</anchor>
      <arglist>(int width, int height, int noctaves, int nlevels, int o_min)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_delete</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ab242293326626641411e7d7f43a109b2</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_first_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a97cca9a09efaadc9dd0671912b9d5e05</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix const *im)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_process_next_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a610cab1a3bf7d38e389afda9037f14da</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_detect</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a65c55820964f4f6609ca9ef1d547b2c4</anchor>
      <arglist>(VlSiftFilt *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_calc_keypoint_orientations</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a2e409d464f81582dc3e839bf0fece66e</anchor>
      <arglist>(VlSiftFilt *f, double angles[4], VlSiftKeypoint const *k)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_keypoint_descriptor</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a19140d86df12ff8c211c2728209de9b1</anchor>
      <arglist>(VlSiftFilt *f, vl_sift_pix *descr, VlSiftKeypoint const *k, double angle)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_calc_raw_descriptor</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a46d3e864618b4a940c2099b7c1f7b6a6</anchor>
      <arglist>(VlSiftFilt const *f, vl_sift_pix const *image, vl_sift_pix *descr, int widht, int height, double x, double y, double s, double angle0)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_keypoint_init</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a6f3fc8e38b6c0c520cb90b1a63ddc031</anchor>
      <arglist>(VlSiftFilt const *f, VlSiftKeypoint *k, double x, double y, double sigma)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_index</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a70186e579c8eff1bcabf408f46169cad</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_noctaves</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a5e0cd96b3985635b82adabc3ce8b2242</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_first</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aa3db07e91c86f992c31b8e2335a760a9</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_width</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a89bd76ab5c1e584ff8e46dfdc93ea748</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_octave_height</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a9769e8f6d84ec75804e873229526eb10</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_nlevels</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a751c116352e72eed8a111e7c1e06a18e</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_sift_get_nkeypoints</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aa45b8e7413384c7d6525f439e68856fe</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_peak_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a08959e6a90c98bf397e3430e79a6ea9c</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_edge_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>adb5b0159af92e1ce1462ddaaaa55a747</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_norm_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ad4b57c390ca004dc56b0b0b1abf0c7a9</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_magnif</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ae0272723812d5072619475d4787be78e</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_sift_get_window_size</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a76053a5e655b9577995fea0fbe429078</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>vl_sift_pix *</type>
      <name>vl_sift_get_octave</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a400759060e87dc7a6264555b90b0a221</anchor>
      <arglist>(VlSiftFilt const *f, int s)</arglist>
    </member>
    <member kind="function">
      <type>VlSiftKeypoint const *</type>
      <name>vl_sift_get_keypoints</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>aed757b23c8f615eb8c6f6a450a0f847f</anchor>
      <arglist>(VlSiftFilt const *f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_peak_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>af69118a1c5d4d17bccac87d11fe8ce8f</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_edge_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>ab7173b402b85de43ebf36fcabde77508</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_norm_thresh</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a86703f33aad31638909acd9697f93115</anchor>
      <arglist>(VlSiftFilt *f, double t)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_magnif</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>a595579dd7952807c074c5311a6500121</anchor>
      <arglist>(VlSiftFilt *f, double m)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_sift_set_window_size</name>
      <anchorfile>sift_8h.html</anchorfile>
      <anchor>af5996cc6171c6e3c8810fb400abbad21</anchor>
      <arglist>(VlSiftFilt *f, double x)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>slic.c</name>
    <path>vl/</path>
    <filename>slic_8c.html</filename>
    <includes id="slic_8h" name="slic.h" local="yes" import="no" module="no" objc="no">slic.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_slic_segment</name>
      <anchorfile>slic_8c.html</anchorfile>
      <anchor>adb6a4c91f40fc32528ba88cffba756ab</anchor>
      <arglist>(vl_uint32 *segmentation, float const *image, vl_size width, vl_size height, vl_size numChannels, vl_size regionSize, float regularization, vl_size minRegionSize)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>slic.h</name>
    <path>vl/</path>
    <filename>slic_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_slic_segment</name>
      <anchorfile>slic_8h.html</anchorfile>
      <anchor>adb6a4c91f40fc32528ba88cffba756ab</anchor>
      <arglist>(vl_uint32 *segmentation, float const *image, vl_size width, vl_size height, vl_size numChannels, vl_size regionSize, float regularization, vl_size minRegionSize)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>stringop.c</name>
    <path>vl/</path>
    <filename>stringop_8c.html</filename>
    <includes id="stringop_8h" name="stringop.h" local="yes" import="no" module="no" objc="no">stringop.h</includes>
    <member kind="function">
      <type>char *</type>
      <name>vl_string_parse_protocol</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>aeb8dcade8be54d36fefd3c85ccbdddf2</anchor>
      <arglist>(char const *string, int *protocol)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_string_protocol_name</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>a6c60db26f8c75b8f0667da0c379afc6b</anchor>
      <arglist>(int protocol)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_basename</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>a303c8ed2006e76ba890080244c9e6439</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *source, vl_size maxNumStrippedExtensions)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_replace_wildcard</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>af938e0e45610e0e1680c8ec41a958882</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *source, char wildcardChar, char escapeChar, char const *replacement)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_copy</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>a12595787245c1d92c5d3bbe6c0cea9f4</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *source)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_copy_sub</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>a3ecf896f613bca486a0821f076aa8855</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *beginning, char const *end)</arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_string_find_char_rev</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>ae8063240b40727ab6cb0b1bc9147587c</anchor>
      <arglist>(char const *beginning, char const *end, char c)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_length</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>acc9de03bedf2b67ce907a7478e34bc4e</anchor>
      <arglist>(char const *string)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_string_casei_cmp</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>ad006cebd610a7a6f7b6d97c93e398824</anchor>
      <arglist>(const char *string1, const char *string2)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>abbcfe8f5acf171801319646f64d88e3e</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_casei</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>a851e9e65edeaff4c68321f98fe05c20b</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_by_value</name>
      <anchorfile>stringop_8c.html</anchorfile>
      <anchor>ad150db6a5409c12748aa3cb63dc0739e</anchor>
      <arglist>(VlEnumerator const *enumeration, vl_index value)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>stringop.h</name>
    <path>vl/</path>
    <filename>stringop_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <class kind="struct">VlEnumerator</class>
    <member kind="enumvalue">
      <name>VL_PROT_UNKNOWN</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a61dadd085c1777f559549e05962b2c9ea71fca21ec3ae6a26edbe380fedc2ebec</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_PROT_NONE</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a61dadd085c1777f559549e05962b2c9ea94b2ad9436eeeb7e7a08baf24e00f3d6</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_PROT_ASCII</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a61dadd085c1777f559549e05962b2c9ea611cc6138919fdd98ce2a9137a762b91</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VL_PROT_BINARY</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a61dadd085c1777f559549e05962b2c9eaa92055b1172e1b8fa98177304d495653</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_copy</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a12595787245c1d92c5d3bbe6c0cea9f4</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *source)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_copy_sub</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a3ecf896f613bca486a0821f076aa8855</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *beginning, char const *end)</arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_string_parse_protocol</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>aeb8dcade8be54d36fefd3c85ccbdddf2</anchor>
      <arglist>(char const *string, int *protocol)</arglist>
    </member>
    <member kind="function">
      <type>char const *</type>
      <name>vl_string_protocol_name</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a0727013b68ee91d42f281a87ec15a1b6</anchor>
      <arglist>(int prot)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_basename</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a7c19551fb6bb7e1f45c453caef5b9044</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *source, vl_size maxNumStrippedExtension)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_replace_wildcard</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a3333f80d5012dadb8967ab297ff02645</anchor>
      <arglist>(char *destination, vl_size destinationSize, char const *src, char wildcardChar, char escapeChar, char const *replacement)</arglist>
    </member>
    <member kind="function">
      <type>char *</type>
      <name>vl_string_find_char_rev</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>ae8063240b40727ab6cb0b1bc9147587c</anchor>
      <arglist>(char const *beginning, char const *end, char c)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_string_length</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>acc9de03bedf2b67ce907a7478e34bc4e</anchor>
      <arglist>(char const *string)</arglist>
    </member>
    <member kind="function">
      <type>int</type>
      <name>vl_string_casei_cmp</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>ad006cebd610a7a6f7b6d97c93e398824</anchor>
      <arglist>(const char *string1, const char *string2)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>abbcfe8f5acf171801319646f64d88e3e</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_casei</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a851e9e65edeaff4c68321f98fe05c20b</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_by_value</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>ad150db6a5409c12748aa3cb63dc0739e</anchor>
      <arglist>(VlEnumerator const *enumeration, vl_index value)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>abbcfe8f5acf171801319646f64d88e3e</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_casei</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>a851e9e65edeaff4c68321f98fe05c20b</anchor>
      <arglist>(VlEnumerator const *enumeration, char const *name)</arglist>
    </member>
    <member kind="function">
      <type>VlEnumerator *</type>
      <name>vl_enumeration_get_by_value</name>
      <anchorfile>stringop_8h.html</anchorfile>
      <anchor>ad150db6a5409c12748aa3cb63dc0739e</anchor>
      <arglist>(VlEnumerator const *enumeration, vl_index value)</arglist>
    </member>
    <docanchor file="stringop_8h.html" title="Enumerations">vl-stringop-enumeration</docanchor>
    <docanchor file="stringop_8h.html" title="File protocols">vl-stringop-file-protocols</docanchor>
    <docanchor file="stringop_8h.html" title="Detecting overflow">vl-stringop-err</docanchor>
  </compound>
  <compound kind="file">
    <name>svm.c</name>
    <path>vl/</path>
    <filename>svm_8c.html</filename>
    <includes id="svm_8h" name="svm.h" local="yes" import="no" module="no" objc="no">svm.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a37cd490ff9128d446ce115dd8c614360</anchor>
      <arglist>(VlSvmSolverType type, double const *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_dataset</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a03c9dfea6a6b4568632ccab3820770cc</anchor>
      <arglist>(VlSvmSolverType solver, VlSvmDataset *dataset, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_abstract_data</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a5db4f4c9afd4a717c6a66c3513c9960b</anchor>
      <arglist>(VlSvmSolverType solver, void *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_delete</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a473c326f265db2ad4752e514b86f2786</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_epsilon</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a4a1a5228c945a145c1bc7e025a0ffe4e</anchor>
      <arglist>(VlSvm *self, double epsilon)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_epsilon</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a409e6ad402041555ace5bea07bee8f4c</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_learning_rate</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a330b9011895064b930c772c1b28e1d9e</anchor>
      <arglist>(VlSvm *self, double rate)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_learning_rate</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>af1e386cc2240d4dc793b43cf0581a8da</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_multiplier</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a1225f0f7f32f8fe5ee4090e77efc4e2c</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_multiplier</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a8d856e3af06dfc1cbb65858008f99279</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_iteration_number</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a446295ef005b5f19fa3648a199c0254d</anchor>
      <arglist>(VlSvm *self, vl_uindex n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_iteration_number</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a38d626608707412d287d9878da3906a6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_max_num_iterations</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a39b8dfc06c0eea75932efacf946df356</anchor>
      <arglist>(VlSvm *self, vl_size n)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_max_num_iterations</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ac88536c7cdb604e94fc314c1b0b74f61</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_frequency</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ab01a4bb3b6aa172fcc24caa2524c2e68</anchor>
      <arglist>(VlSvm *self, vl_size f)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_diagnostic_frequency</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>adb4999d45e11c18ba92068b4184cd78e</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmSolverType</type>
      <name>vl_svm_get_solver</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a53996f81113054b626c2333a648c14f6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_lambda</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>afd55352a18d58c6dba0c49206263f96d</anchor>
      <arglist>(VlSvm *self, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_lambda</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a8692ad5cb99ddc60db131e74a6d75d23</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_weights</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>af81b6cb98f1730f41266ec69f2b6cece</anchor>
      <arglist>(VlSvm *self, double const *weights)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_weights</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>aee658236610044b8fdedd52b97d9d026</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_dimension</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ab3a28927b8bf3bcc241b15e4ee9ef091</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_num_data</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a07d588c6592e443a4366b295bb5e9ccc</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_model</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a9aa3f3a7ab93ad2cb660abfb360eba4d</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_model</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a11cfeb959efa6d18ced2e55603e32097</anchor>
      <arglist>(VlSvm *self, double const *model)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a60d6f706dcde30fea14fbf80714c93ce</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>aa7fb1a06113795e0fd1f24ce99324981</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmStatistics const *</type>
      <name>vl_svm_get_statistics</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>adb5c50a8bd7509fbe2bbeefc14d0f68b</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_scores</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a641e217bac113dd4285c3ca1c6893ec6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_function</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a0a01191236abfe94b65f895fa49e0a35</anchor>
      <arglist>(VlSvm *self, VlSvmDiagnosticFunction f, void *data)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_data_functions</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ab452546b3f6e5e2116e983a5c6f9f2c3</anchor>
      <arglist>(VlSvm *self, VlSvmInnerProductFunction inner, VlSvmAccumulateFunction acc)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_function</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a96b35e9e2b6000e40debe2c64ca7e09b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_derivative_function</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a3d3adc335fd789a702eb7771694464c8</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_conjugate_loss_function</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a58607879bd185df037f8a644e080a03b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_dca_update_function</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a51fa5a1151eb24dfb894df30f23a0ea7</anchor>
      <arglist>(VlSvm *self, VlSvmDcaUpdateFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a8d0d404bab46b9235c15e914146c05bc</anchor>
      <arglist>(VlSvm *self, VlSvmLossType loss)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a0716de4deae9d2c0dbfadbc341b5bd23</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss_derivative</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>afb84322b6e73c3e52f7aad2d11cafa4d</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_conjugate_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>af2fe18d9e0464d0dbea4f47085f965c7</anchor>
      <arglist>(double u, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_dca_update</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a124569cc46bef2e6d1ac6d1c6466cd04</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a5e8dae2afbec9d4b12a3b9fb41f22982</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss_derivative</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a4e05d57c98630a4b1dc8dd1d5fb5ee83</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_conjugate_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>afcbc30c041d098f234c9212b949d5355</anchor>
      <arglist>(double u, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_dca_update</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a2ad7b4c276cd0f8ed85a543703876cb9</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a208fcdeed237af77411304dbf3a66d49</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss_derivative</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a1a9e4d9033578f22f4122cee332c5b96</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_conjugate_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a9ed9aee4e5c10c394e8c74fb07830d8e</anchor>
      <arglist>(double u, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_dca_update</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a3beb0d1198c40cd81d554f3f6e45cfc3</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a0b0ee33bdc4c03bb1b145d31049cde99</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss_derivative</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ad1610aa045bd31aee3999b3738079931</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_conjugate_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ac17be0691987f74ff643b0e968d653f7</anchor>
      <arglist>(double u, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_dca_update</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a19fdae42e265e3c89b9b390e9946bc8f</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a6bbc5ef9c1b1e070e8d08d4f4cf5db2d</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss_derivative</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ae131f2f2cffaa8a187130fa379c4009d</anchor>
      <arglist>(double inner, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_conjugate_loss</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>ac6b56d51d0d2164c1deab595f42eb66d</anchor>
      <arglist>(double u, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_dca_update</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a351223c8a963451830a758e84e8ca3f5</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>_vl_svm_update_statistics</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a07fdae9de0f8d8add3d5f8dd015ac39e</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_train</name>
      <anchorfile>svm_8c.html</anchorfile>
      <anchor>a0812e42b5511e8da15b9a283a0564d02</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>svm.h</name>
    <path>vl/</path>
    <filename>svm_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="svmdataset_8h" name="svmdataset.h" local="yes" import="no" module="no" objc="no">svmdataset.h</includes>
    <class kind="struct">VlSvmStatistics</class>
    <member kind="typedef">
      <type>OPAQUE</type>
      <name>VlSvm</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ad54eb871794742668e91b2e73c6f8ea4</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlSvmSolverType</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0c5120e756a9a2b06d23130d54db90c9</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmSolverNone</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0c5120e756a9a2b06d23130d54db90c9a0813728ebdd6388e9df7d8ad8787d0ef</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmSolverSgd</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0c5120e756a9a2b06d23130d54db90c9ad7ec41888bf7474e5d92a8b0f0dfa05a</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmSolverSdca</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0c5120e756a9a2b06d23130d54db90c9a65819739f150850ac0033ddc142ec593</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlSvmLossType</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmLossHinge</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7a9f3f057683a70fc737622274a94e8d76</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmLossHinge2</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7a9b9299ce069ae6dab29a0f99a82f370d</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmLossL1</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7a0b10b3dc74d3a4908e22200fb314e9af</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmLossL2</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7a8694da194009c2496e28e5be1c6d0a47</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmLossLogistic</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a039ed185475e457e96dcb41a096bd8a7a2ce88153bc65e0ebad17b92b7841409a</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumeration">
      <type></type>
      <name>VlSvmSolverStatus</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab10b6ec323abb9c4ed1c75290ac7032a</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmStatusTraining</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab10b6ec323abb9c4ed1c75290ac7032aa1b47ec65b19b761a65abd4c4864b162b</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmStatusConverged</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab10b6ec323abb9c4ed1c75290ac7032aa3aaf89d2a76ae35ce2a5761628ac6bbf</anchor>
      <arglist></arglist>
    </member>
    <member kind="enumvalue">
      <name>VlSvmStatusMaxNumIterationsReached</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab10b6ec323abb9c4ed1c75290ac7032aa6a48b72e94b4f9b00053885982af3958</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a37cd490ff9128d446ce115dd8c614360</anchor>
      <arglist>(VlSvmSolverType type, double const *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_dataset</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>acb660583da7011e46539d6d2207cffff</anchor>
      <arglist>(VlSvmSolverType type, VlSvmDataset *dataset, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_abstract_data</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aa3adac7a98f48af218faa73aa6a06aa2</anchor>
      <arglist>(VlSvmSolverType type, void *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_delete</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a473c326f265db2ad4752e514b86f2786</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmStatistics const *</type>
      <name>vl_svm_get_statistics</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>adb5c50a8bd7509fbe2bbeefc14d0f68b</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_model</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9aa3f3a7ab93ad2cb660abfb360eba4d</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aa7fb1a06113795e0fd1f24ce99324981</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_dimension</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab3a28927b8bf3bcc241b15e4ee9ef091</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_num_data</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a07d588c6592e443a4366b295bb5e9ccc</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_epsilon</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a409e6ad402041555ace5bea07bee8f4c</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_learning_rate</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af1e386cc2240d4dc793b43cf0581a8da</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_max_num_iterations</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ac88536c7cdb604e94fc314c1b0b74f61</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_diagnostic_frequency</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>adb4999d45e11c18ba92068b4184cd78e</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmSolverType</type>
      <name>vl_svm_get_solver</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a53996f81113054b626c2333a648c14f6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_multiplier</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8d856e3af06dfc1cbb65858008f99279</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_lambda</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8692ad5cb99ddc60db131e74a6d75d23</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_iteration_number</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a38d626608707412d287d9878da3906a6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_scores</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a641e217bac113dd4285c3ca1c6893ec6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_weights</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aee658236610044b8fdedd52b97d9d026</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_epsilon</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a4a1a5228c945a145c1bc7e025a0ffe4e</anchor>
      <arglist>(VlSvm *self, double epsilon)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_learning_rate</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a330b9011895064b930c772c1b28e1d9e</anchor>
      <arglist>(VlSvm *self, double rate)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_max_num_iterations</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a18cb2adc040000ef02ba9c6a15f82cf0</anchor>
      <arglist>(VlSvm *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_frequency</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab01a4bb3b6aa172fcc24caa2524c2e68</anchor>
      <arglist>(VlSvm *self, vl_size f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_multiplier</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a1225f0f7f32f8fe5ee4090e77efc4e2c</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_model</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a11cfeb959efa6d18ced2e55603e32097</anchor>
      <arglist>(VlSvm *self, double const *model)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a60d6f706dcde30fea14fbf80714c93ce</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_iteration_number</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a446295ef005b5f19fa3648a199c0254d</anchor>
      <arglist>(VlSvm *self, vl_uindex n)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_weights</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af81b6cb98f1730f41266ec69f2b6cece</anchor>
      <arglist>(VlSvm *self, double const *weights)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0a01191236abfe94b65f895fa49e0a35</anchor>
      <arglist>(VlSvm *self, VlSvmDiagnosticFunction f, void *data)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a96b35e9e2b6000e40debe2c64ca7e09b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_derivative_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a3d3adc335fd789a702eb7771694464c8</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_conjugate_loss_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a58607879bd185df037f8a644e080a03b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_dca_update_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a51fa5a1151eb24dfb894df30f23a0ea7</anchor>
      <arglist>(VlSvm *self, VlSvmDcaUpdateFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_data_functions</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab452546b3f6e5e2116e983a5c6f9f2c3</anchor>
      <arglist>(VlSvm *self, VlSvmInnerProductFunction inner, VlSvmAccumulateFunction acc)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8d0d404bab46b9235c15e914146c05bc</anchor>
      <arglist>(VlSvm *self, VlSvmLossType loss)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_train</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0812e42b5511e8da15b9a283a0564d02</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9b840a87d2bff2d13d241f7939cd309c</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a5ac4b8009090cc4d2d151bd6385d62ca</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a5fc0df0b86c5cc6abce979d0f41e7efb</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a124569cc46bef2e6d1ac6d1c6466cd04</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>acb7865e9dcff8c7ffdb8691bf5a214c6</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af5c2718ad2f5b60ab1c5e9ce342694af</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a1428c410f17db8b4d3d44b8ef19bf694</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a2ad7b4c276cd0f8ed85a543703876cb9</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a18c9bd164991c23461aebfba7387ec6b</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a40f140dcba523b7b7eab8a1780d0fbfc</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ac0593cf7cc30e1070eaf28aa00eb0e85</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a3beb0d1198c40cd81d554f3f6e45cfc3</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a4302119703c72c34e82e4001dd6bccc4</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8abc5f1d42774b0b70803c3db2331fbc</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a680af302cca5e1abc3c580dd37319012</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a19fdae42e265e3c89b9b390e9946bc8f</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a21196b4676f47d82db58d81ca24f21bd</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9062cd19f1ce595bd5858793b07df2de</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a42c11deaac87f38fd9169fe94ec9cd89</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a351223c8a963451830a758e84e8ca3f5</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a37cd490ff9128d446ce115dd8c614360</anchor>
      <arglist>(VlSvmSolverType type, double const *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_dataset</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>acb660583da7011e46539d6d2207cffff</anchor>
      <arglist>(VlSvmSolverType type, VlSvmDataset *dataset, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>VlSvm *</type>
      <name>vl_svm_new_with_abstract_data</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aa3adac7a98f48af218faa73aa6a06aa2</anchor>
      <arglist>(VlSvmSolverType type, void *data, vl_size dimension, vl_size numData, double const *labels, double lambda)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_delete</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a473c326f265db2ad4752e514b86f2786</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmStatistics const *</type>
      <name>vl_svm_get_statistics</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>adb5c50a8bd7509fbe2bbeefc14d0f68b</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_model</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9aa3f3a7ab93ad2cb660abfb360eba4d</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aa7fb1a06113795e0fd1f24ce99324981</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_dimension</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab3a28927b8bf3bcc241b15e4ee9ef091</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_num_data</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a07d588c6592e443a4366b295bb5e9ccc</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_epsilon</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a409e6ad402041555ace5bea07bee8f4c</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_learning_rate</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af1e386cc2240d4dc793b43cf0581a8da</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_max_num_iterations</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ac88536c7cdb604e94fc314c1b0b74f61</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_diagnostic_frequency</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>adb4999d45e11c18ba92068b4184cd78e</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmSolverType</type>
      <name>vl_svm_get_solver</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a53996f81113054b626c2333a648c14f6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_bias_multiplier</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8d856e3af06dfc1cbb65858008f99279</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_get_lambda</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8692ad5cb99ddc60db131e74a6d75d23</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svm_get_iteration_number</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a38d626608707412d287d9878da3906a6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_scores</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a641e217bac113dd4285c3ca1c6893ec6</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>double const *</type>
      <name>vl_svm_get_weights</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>aee658236610044b8fdedd52b97d9d026</anchor>
      <arglist>(VlSvm const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_epsilon</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a4a1a5228c945a145c1bc7e025a0ffe4e</anchor>
      <arglist>(VlSvm *self, double epsilon)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_learning_rate</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a330b9011895064b930c772c1b28e1d9e</anchor>
      <arglist>(VlSvm *self, double rate)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_max_num_iterations</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a18cb2adc040000ef02ba9c6a15f82cf0</anchor>
      <arglist>(VlSvm *self, vl_size maxNumIterations)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_frequency</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab01a4bb3b6aa172fcc24caa2524c2e68</anchor>
      <arglist>(VlSvm *self, vl_size f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias_multiplier</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a1225f0f7f32f8fe5ee4090e77efc4e2c</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_model</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a11cfeb959efa6d18ced2e55603e32097</anchor>
      <arglist>(VlSvm *self, double const *model)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_bias</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a60d6f706dcde30fea14fbf80714c93ce</anchor>
      <arglist>(VlSvm *self, double b)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_iteration_number</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a446295ef005b5f19fa3648a199c0254d</anchor>
      <arglist>(VlSvm *self, vl_uindex n)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_weights</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af81b6cb98f1730f41266ec69f2b6cece</anchor>
      <arglist>(VlSvm *self, double const *weights)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_diagnostic_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0a01191236abfe94b65f895fa49e0a35</anchor>
      <arglist>(VlSvm *self, VlSvmDiagnosticFunction f, void *data)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a96b35e9e2b6000e40debe2c64ca7e09b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss_derivative_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a3d3adc335fd789a702eb7771694464c8</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_conjugate_loss_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a58607879bd185df037f8a644e080a03b</anchor>
      <arglist>(VlSvm *self, VlSvmLossFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_dca_update_function</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a51fa5a1151eb24dfb894df30f23a0ea7</anchor>
      <arglist>(VlSvm *self, VlSvmDcaUpdateFunction f)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_data_functions</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ab452546b3f6e5e2116e983a5c6f9f2c3</anchor>
      <arglist>(VlSvm *self, VlSvmInnerProductFunction inner, VlSvmAccumulateFunction acc)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_set_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8d0d404bab46b9235c15e914146c05bc</anchor>
      <arglist>(VlSvm *self, VlSvmLossType loss)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svm_train</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a0812e42b5511e8da15b9a283a0564d02</anchor>
      <arglist>(VlSvm *self)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9b840a87d2bff2d13d241f7939cd309c</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a5ac4b8009090cc4d2d151bd6385d62ca</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a5fc0df0b86c5cc6abce979d0f41e7efb</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a124569cc46bef2e6d1ac6d1c6466cd04</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>acb7865e9dcff8c7ffdb8691bf5a214c6</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>af5c2718ad2f5b60ab1c5e9ce342694af</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a1428c410f17db8b4d3d44b8ef19bf694</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_hinge2_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a2ad7b4c276cd0f8ed85a543703876cb9</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a18c9bd164991c23461aebfba7387ec6b</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a40f140dcba523b7b7eab8a1780d0fbfc</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>ac0593cf7cc30e1070eaf28aa00eb0e85</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l1_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a3beb0d1198c40cd81d554f3f6e45cfc3</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a4302119703c72c34e82e4001dd6bccc4</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a8abc5f1d42774b0b70803c3db2331fbc</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a680af302cca5e1abc3c580dd37319012</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_l2_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a19fdae42e265e3c89b9b390e9946bc8f</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a21196b4676f47d82db58d81ca24f21bd</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_loss_derivative</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a9062cd19f1ce595bd5858793b07df2de</anchor>
      <arglist>(double label, double inner)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_conjugate_loss</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a42c11deaac87f38fd9169fe94ec9cd89</anchor>
      <arglist>(double label, double u)</arglist>
    </member>
    <member kind="function">
      <type>double</type>
      <name>vl_svm_logistic_dca_update</name>
      <anchorfile>svm_8h.html</anchorfile>
      <anchor>a351223c8a963451830a758e84e8ca3f5</anchor>
      <arglist>(double alpha, double inner, double norm2, double label)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>svmdataset.c</name>
    <path>vl/</path>
    <filename>svmdataset_8c.html</filename>
    <includes id="svmdataset_8h" name="svmdataset.h" local="yes" import="no" module="no" objc="no">svmdataset.h</includes>
    <includes id="svmdataset_8c" name="svmdataset.c" local="yes" import="no" module="no" objc="no">svmdataset.c</includes>
    <member kind="function">
      <type>VlSvmDataset *</type>
      <name>vl_svmdataset_new</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a9c70357f26da5f309e43fb7c86af09a7</anchor>
      <arglist>(vl_type dataType, void *data, vl_size dimension, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_delete</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>af0085da6bb1cca9fc48ecfb267b107d5</anchor>
      <arglist>(VlSvmDataset *self)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_svmdataset_get_data</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a0216d73bd5e674ab55f6db6c8f6cd015</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_num_data</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a9e26f54293c5999f146c1275662c96ae</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_dimension</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a7651f4dde6a4f607ce609eafbe8e9556</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_svmdataset_get_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a7df8c2668ffdf236289e5febfc59a0aa</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_set_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a6e72d282d3bb7e05410efe5d28026ad2</anchor>
      <arglist>(VlSvmDataset *self, VlHomogeneousKernelMap *hom)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmAccumulateFunction</type>
      <name>vl_svmdataset_get_accumulate_function</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>af311a005cf80188b291848969116c795</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmInnerProductFunction</type>
      <name>vl_svmdataset_get_inner_product_function</name>
      <anchorfile>svmdataset_8c.html</anchorfile>
      <anchor>a9eb6105fde6800091886cfd9f3f95927</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>svmdataset.h</name>
    <path>vl/</path>
    <filename>svmdataset_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <includes id="homkermap_8h" name="homkermap.h" local="yes" import="no" module="no" objc="no">homkermap.h</includes>
    <member kind="typedef">
      <type>OPAQUE</type>
      <name>VlSvmDataset</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a5861f5083aeff8991fa982e4809c7258</anchor>
      <arglist></arglist>
    </member>
    <member kind="typedef">
      <type>void(*</type>
      <name>VlSvmDiagnosticFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>aa88e0bfe32f34da8904ce26fef46207f</anchor>
      <arglist>)(struct VlSvm_ *svm, void *data)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmLossFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a0e6f309e6cfe483680ae0b5baad6e63c</anchor>
      <arglist>)(double inner, double label)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmDcaUpdateFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a5bb6eb4863de6458604d5ddb77cdb057</anchor>
      <arglist>)(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmInnerProductFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a31cceb46535045f1176f718481569046</anchor>
      <arglist>)(const void *data, vl_uindex element, double *model)</arglist>
    </member>
    <member kind="typedef">
      <type>void(*</type>
      <name>VlSvmAccumulateFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>afed5bca344240e8700ed1be9bf8567c1</anchor>
      <arglist>)(const void *data, vl_uindex element, double *model, double multiplier)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmDataset *</type>
      <name>vl_svmdataset_new</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9c70357f26da5f309e43fb7c86af09a7</anchor>
      <arglist>(vl_type dataType, void *data, vl_size dimension, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_delete</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>aea5a446f62eb3ad21269f6a660b03bee</anchor>
      <arglist>(VlSvmDataset *dataset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_set_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a6e72d282d3bb7e05410efe5d28026ad2</anchor>
      <arglist>(VlSvmDataset *self, VlHomogeneousKernelMap *hom)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_svmdataset_get_data</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a0216d73bd5e674ab55f6db6c8f6cd015</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_num_data</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9e26f54293c5999f146c1275662c96ae</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_dimension</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a7651f4dde6a4f607ce609eafbe8e9556</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmAccumulateFunction</type>
      <name>vl_svmdataset_get_accumulate_function</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>af311a005cf80188b291848969116c795</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmInnerProductFunction</type>
      <name>vl_svmdataset_get_inner_product_function</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9eb6105fde6800091886cfd9f3f95927</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_svmdataset_get_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a7df8c2668ffdf236289e5febfc59a0aa</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="typedef">
      <type>void(*</type>
      <name>VlSvmDiagnosticFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>aa88e0bfe32f34da8904ce26fef46207f</anchor>
      <arglist>)(struct VlSvm_ *svm, void *data)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmLossFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a0e6f309e6cfe483680ae0b5baad6e63c</anchor>
      <arglist>)(double inner, double label)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmDcaUpdateFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a5bb6eb4863de6458604d5ddb77cdb057</anchor>
      <arglist>)(double alpha, double inner, double norm2, double label)</arglist>
    </member>
    <member kind="typedef">
      <type>double(*</type>
      <name>VlSvmInnerProductFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a31cceb46535045f1176f718481569046</anchor>
      <arglist>)(const void *data, vl_uindex element, double *model)</arglist>
    </member>
    <member kind="typedef">
      <type>void(*</type>
      <name>VlSvmAccumulateFunction</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>afed5bca344240e8700ed1be9bf8567c1</anchor>
      <arglist>)(const void *data, vl_uindex element, double *model, double multiplier)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmDataset *</type>
      <name>vl_svmdataset_new</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9c70357f26da5f309e43fb7c86af09a7</anchor>
      <arglist>(vl_type dataType, void *data, vl_size dimension, vl_size numData)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_delete</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>aea5a446f62eb3ad21269f6a660b03bee</anchor>
      <arglist>(VlSvmDataset *dataset)</arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_svmdataset_set_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a6e72d282d3bb7e05410efe5d28026ad2</anchor>
      <arglist>(VlSvmDataset *self, VlHomogeneousKernelMap *hom)</arglist>
    </member>
    <member kind="function">
      <type>void *</type>
      <name>vl_svmdataset_get_data</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a0216d73bd5e674ab55f6db6c8f6cd015</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_num_data</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9e26f54293c5999f146c1275662c96ae</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>vl_size</type>
      <name>vl_svmdataset_get_dimension</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a7651f4dde6a4f607ce609eafbe8e9556</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmAccumulateFunction</type>
      <name>vl_svmdataset_get_accumulate_function</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>af311a005cf80188b291848969116c795</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlSvmInnerProductFunction</type>
      <name>vl_svmdataset_get_inner_product_function</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a9eb6105fde6800091886cfd9f3f95927</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <member kind="function">
      <type>VlHomogeneousKernelMap *</type>
      <name>vl_svmdataset_get_homogeneous_kernel_map</name>
      <anchorfile>svmdataset_8h.html</anchorfile>
      <anchor>a7df8c2668ffdf236289e5febfc59a0aa</anchor>
      <arglist>(VlSvmDataset const *self)</arglist>
    </member>
    <docanchor file="svmdataset_8h.html" title="Getting started">svmdataset-starting</docanchor>
  </compound>
  <compound kind="file">
    <name>vlad.c</name>
    <path>vl/</path>
    <filename>vlad_8c.html</filename>
    <includes id="vlad_8h" name="vlad.h" local="yes" import="no" module="no" objc="no">vlad.h</includes>
    <includes id="mathop_8h" name="mathop.h" local="yes" import="no" module="no" objc="no">mathop.h</includes>
    <member kind="function">
      <type>void</type>
      <name>vl_vlad_encode</name>
      <anchorfile>vlad_8c.html</anchorfile>
      <anchor>a6ee2926e14d4a76e9d99ba128bfe5a80</anchor>
      <arglist>(void *enc, vl_type dataType, void const *means, vl_size dimension, vl_size numClusters, void const *data, vl_size numData, void const *assignments, int flags)</arglist>
    </member>
  </compound>
  <compound kind="file">
    <name>vlad.h</name>
    <path>vl/</path>
    <filename>vlad_8h.html</filename>
    <includes id="generic_8h" name="generic.h" local="yes" import="no" module="no" objc="no">generic.h</includes>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_NORMALIZE_COMPONENTS</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>a2530f7175c68c931b9c195a227dd9d0e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_SQUARE_ROOT</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>adac275d53de92eba4f3a83325f85da3e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_UNNORMALIZED</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>ac048897164a0ab938bc26bec91b85b9c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_NORMALIZE_MASS</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>a2047ae2d21cec965ab5db039b1f66d98</anchor>
      <arglist></arglist>
    </member>
    <member kind="function">
      <type>void</type>
      <name>vl_vlad_encode</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>a6ee2926e14d4a76e9d99ba128bfe5a80</anchor>
      <arglist>(void *enc, vl_type dataType, void const *means, vl_size dimension, vl_size numClusters, void const *data, vl_size numData, void const *assignments, int flags)</arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_NORMALIZE_COMPONENTS</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>a2530f7175c68c931b9c195a227dd9d0e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_SQUARE_ROOT</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>adac275d53de92eba4f3a83325f85da3e</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_UNNORMALIZED</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>ac048897164a0ab938bc26bec91b85b9c</anchor>
      <arglist></arglist>
    </member>
    <member kind="define">
      <type>#define</type>
      <name>VL_VLAD_FLAG_NORMALIZE_MASS</name>
      <anchorfile>vlad_8h.html</anchorfile>
      <anchor>a2047ae2d21cec965ab5db039b1f66d98</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlCovDet</name>
    <filename>struct__VlCovDet.html</filename>
    <member kind="variable">
      <type>VlScaleSpace *</type>
      <name>gss</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a77f7d293b118dee86be80af6ee0ab531</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlScaleSpace *</type>
      <name>css</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>aa8038adaef01a1b2ee54c65658add0af</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlCovDetMethod</type>
      <name>method</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>aa61ec4e6cfd747ac1dc98064cd179164</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>peakThreshold</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a0e1383003f424d69d2f5f0bb69279fa0</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>edgeThreshold</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a71bd3beef31f61398ed22ca5e54d912a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>lapPeakThreshold</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a6c7f2e85d47c0a02ce451997a454bf38</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>octaveResolution</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a1abb4b0b2204d480701e332111c85521</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>numOctaves</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a5ed103028a1df86e17bf361a2d0149f2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>firstOctave</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a5bb8c687c17cdf4b7bb154521444eced</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>baseScale</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a2b13aca791d874ef53b678c516c3420d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>maxNumOrientations</name>
      <anchorfile>struct__VlCovDet.html</anchorfile>
      <anchor>a1accac52dc5aa16c88630979b290a6fb</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlAIB</name>
    <filename>structVlAIB.html</filename>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>nodes</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>a77f5198dcd0bfb7a47985ac0c5d84e3b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>nentries</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>ac44b016feb6fc2397f4f79e5a1ae22e1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double *</type>
      <name>beta</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>ace9cbba670128776c03a9cf0d7e53dfe</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>bidx</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>abb81041e575b04b2b2a0f8126ccbcf17</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>which</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>aa0e490d88c8ea0c372bf02b23f291108</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>nwhich</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>a6143399b605075053c30e4d603aceb81</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double *</type>
      <name>Pcx</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>ac1949576f214b7a6691189deb7d9dace</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double *</type>
      <name>Px</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>a064882a6f2252669858850fc650b97de</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double *</type>
      <name>Pc</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>a4d948f7509b088aa37d64fb7ac0e82b8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>nvalues</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>aff0e65edef1bb1e339ee0901dd2f8587</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>nlabels</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>a650b9fef79d1b92a464a1481643fb619</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>parents</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>ae0a5d0c9804d157558b92eb06b5c840f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double *</type>
      <name>costs</name>
      <anchorfile>structVlAIB.html</anchorfile>
      <anchor>ac62155359405a96c7f346b8ad11f248a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlArray</name>
    <filename>structVlArray.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlCovDetFeature</name>
    <filename>structVlCovDetFeature.html</filename>
    <member kind="variable">
      <type>VlFrameOrientedEllipse</type>
      <name>frame</name>
      <anchorfile>structVlCovDetFeature.html</anchorfile>
      <anchor>a25de61181315ca3f1f89c62d98b2ace7</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>peakScore</name>
      <anchorfile>structVlCovDetFeature.html</anchorfile>
      <anchor>ae588e59a101494995e6daabb1ed27b98</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>edgeScore</name>
      <anchorfile>structVlCovDetFeature.html</anchorfile>
      <anchor>a57a5c5b67ddf59327bea9a4c8a6c336e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>orientationScore</name>
      <anchorfile>structVlCovDetFeature.html</anchorfile>
      <anchor>a62792d5617f0d04ecb3ea5a4d4bf9cdb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>laplacianScaleScore</name>
      <anchorfile>structVlCovDetFeature.html</anchorfile>
      <anchor>ac249855def782e0d04db84d2b7244886</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlCovDetFeatureLaplacianScale</name>
    <filename>structVlCovDetFeatureLaplacianScale.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlCovDetFeatureOrientation</name>
    <filename>structVlCovDetFeatureOrientation.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlDsiftDescriptorGeometry</name>
    <filename>structVlDsiftDescriptorGeometry.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>numBinT</name>
      <anchorfile>structVlDsiftDescriptorGeometry.html</anchorfile>
      <anchor>a87a3ebdc9dd85fa401a3487f7a775af6</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numBinX</name>
      <anchorfile>structVlDsiftDescriptorGeometry.html</anchorfile>
      <anchor>ad9b98d9776ffc64d58ee8bc334b67cd3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numBinY</name>
      <anchorfile>structVlDsiftDescriptorGeometry.html</anchorfile>
      <anchor>a7286ef9a626758b7e51885d47949bb18</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>binSizeX</name>
      <anchorfile>structVlDsiftDescriptorGeometry.html</anchorfile>
      <anchor>aa16bfebff07c7e14d0abbf7e7a25f3dc</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>binSizeY</name>
      <anchorfile>structVlDsiftDescriptorGeometry.html</anchorfile>
      <anchor>aab782f65428fc76e63af68de00c3e6ef</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlDsiftFilter</name>
    <filename>structVlDsiftFilter.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>imWidth</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a47b34aa22c1ac914aff9f9c5b5df1ac8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>imHeight</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a00925db85e4f6fd44fe54f2f609b593c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>stepX</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>aec9bbfa83e413d4d9bb32d5d369d27d3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>stepY</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a13761e945b90727560e64e73fa10c056</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>boundMinX</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a3c3ac4c182b4ba15a887b75e98f90ad0</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>boundMinY</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a866207aea6fa39a8b6d419083335e7c8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>boundMaxX</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a9f43439af3b299c0ecef3d1b58bb25c2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>boundMaxY</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a6c2291f676ddcf6f1b5be26158077d4d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlDsiftDescriptorGeometry</type>
      <name>geom</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a0f6a9db82b0eb6f95c95133fd75d3a6f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>useFlatWindow</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>aaabeaf3f1ef63f86533bc320a3c0979c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>windowSize</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a3bf6b701aa4c4f33fc756ba4a655f9ec</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numFrames</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a46bfa38154e5d4957a028c9148c5e500</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>descrSize</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>afbe51c17de336dbb99e79904b4561cb5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlDsiftKeypoint *</type>
      <name>frames</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>ae2a5d95b44bbf8ddc8f01670109087be</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>descrs</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a7327abb224129df06a2d6c6f5b7c8ab1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numBinAlloc</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>aedbe067867835f6e640ad9719c3ac1ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numFrameAlloc</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a167e5c67b8c4d2457d20d82d8fc4a4d1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>numGradAlloc</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a4959c1b64531a38c8b4c65b94435f645</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float **</type>
      <name>grads</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a6732857d58cb28b95c7cef0932e2fbda</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>convTmp1</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>a3bb946b1bb8ccb9ea992cfce601b6dff</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>convTmp2</name>
      <anchorfile>structVlDsiftFilter.html</anchorfile>
      <anchor>af189dce008cae83170f654e3f05f34b4</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlDsiftKeypoint</name>
    <filename>structVlDsiftKeypoint.html</filename>
    <member kind="variable">
      <type>double</type>
      <name>x</name>
      <anchorfile>structVlDsiftKeypoint.html</anchorfile>
      <anchor>a6f8fcf1ba583e3757038fd52591ccb98</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>y</name>
      <anchorfile>structVlDsiftKeypoint.html</anchorfile>
      <anchor>ac7333a1abf7ed22a0598e3b32f9529ff</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>s</name>
      <anchorfile>structVlDsiftKeypoint.html</anchorfile>
      <anchor>a73cf7f4b6b7ae0a82d5d1c61326423f9</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>norm</name>
      <anchorfile>structVlDsiftKeypoint.html</anchorfile>
      <anchor>ad98fe9803ea23caa9cffb242fdfa9482</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlEnumerator</name>
    <filename>structVlEnumerator.html</filename>
    <member kind="variable">
      <type>char const  *</type>
      <name>name</name>
      <anchorfile>structVlEnumerator.html</anchorfile>
      <anchor>a9f1631dbd4f6083fdadb18dab354f76f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>value</name>
      <anchorfile>structVlEnumerator.html</anchorfile>
      <anchor>aa731575bab1f4c0348a3b8f4e6ad97b9</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlFileMeta</name>
    <filename>struct__VlFileMeta.html</filename>
    <member kind="variable">
      <type>vl_bool</type>
      <name>active</name>
      <anchorfile>struct__VlFileMeta.html</anchorfile>
      <anchor>ac8245ecf1ae71176fa944260f79493b4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>char</type>
      <name>pattern</name>
      <anchorfile>struct__VlFileMeta.html</anchorfile>
      <anchor>a50a830ec13f3b64f0689c52c0ec95a2c</anchor>
      <arglist>[1024]</arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>protocol</name>
      <anchorfile>struct__VlFileMeta.html</anchorfile>
      <anchor>a83fd3b4f0875175d0af4daa2994f0f81</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>char</type>
      <name>name</name>
      <anchorfile>struct__VlFileMeta.html</anchorfile>
      <anchor>afba45105c40b174ade989a520e9599bc</anchor>
      <arglist>[1024]</arglist>
    </member>
    <member kind="variable">
      <type>FILE *</type>
      <name>file</name>
      <anchorfile>struct__VlFileMeta.html</anchorfile>
      <anchor>aee7b5502dfa0235b8df0b2f4a5807db1</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlFrameDisc</name>
    <filename>structVlFrameDisc.html</filename>
    <member kind="variable">
      <type>float</type>
      <name>x</name>
      <anchorfile>structVlFrameDisc.html</anchorfile>
      <anchor>ac5f32176c8011abb982669e08822844c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>y</name>
      <anchorfile>structVlFrameDisc.html</anchorfile>
      <anchor>ac17b5f9f8d70ca4fa00d76422296edfb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>sigma</name>
      <anchorfile>structVlFrameDisc.html</anchorfile>
      <anchor>af4cd86ab4cef4d10c43e4eaa03d2988c</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlFrameEllipse</name>
    <filename>structVlFrameEllipse.html</filename>
    <member kind="variable">
      <type>float</type>
      <name>x</name>
      <anchorfile>structVlFrameEllipse.html</anchorfile>
      <anchor>a828d9728476ee2bb3ded150e07de73da</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>y</name>
      <anchorfile>structVlFrameEllipse.html</anchorfile>
      <anchor>a36246b27beb190b642bad60aee8c59dc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlFrameOrientedDisc</name>
    <filename>structVlFrameOrientedDisc.html</filename>
    <member kind="variable">
      <type>float</type>
      <name>x</name>
      <anchorfile>structVlFrameOrientedDisc.html</anchorfile>
      <anchor>a023fa94eb34c14183a519d6db658e355</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>y</name>
      <anchorfile>structVlFrameOrientedDisc.html</anchorfile>
      <anchor>a62eae282eb13e56ce25d942f7f31cfc6</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>sigma</name>
      <anchorfile>structVlFrameOrientedDisc.html</anchorfile>
      <anchor>ad09f73e3266612e4a43e1dca13867f08</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>angle</name>
      <anchorfile>structVlFrameOrientedDisc.html</anchorfile>
      <anchor>a0ef72c38f9420ba0cddafab1e64cb052</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlFrameOrientedEllipse</name>
    <filename>structVlFrameOrientedEllipse.html</filename>
    <member kind="variable">
      <type>float</type>
      <name>x</name>
      <anchorfile>structVlFrameOrientedEllipse.html</anchorfile>
      <anchor>a41b6faf0214d2c0397fd25f395a1e2ed</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>y</name>
      <anchorfile>structVlFrameOrientedEllipse.html</anchorfile>
      <anchor>ab5d1b4bf31911b4df5a0ff817393cacc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlHIKMNode</name>
    <filename>structVlHIKMNode.html</filename>
    <member kind="variable">
      <type>VlIKMFilt *</type>
      <name>filter</name>
      <anchorfile>structVlHIKMNode.html</anchorfile>
      <anchor>add3392d13a430dc285f00b04a267249a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>struct _VlHIKMNode **</type>
      <name>children</name>
      <anchorfile>structVlHIKMNode.html</anchorfile>
      <anchor>a6880f479994ea1a274d95f9ce6bb848a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlHIKMTree</name>
    <filename>structVlHIKMTree.html</filename>
    <member kind="variable">
      <type>vl_size</type>
      <name>M</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>aee1dffe76b44fa38951193243ca8688d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>K</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>a0fcf23530d692ffb58f72e9ac59bfdf5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>depth</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>a7d1807da5166539047f6ab930d775034</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>max_niters</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>a05095932329fb9ce21add00fe9be3c52</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>method</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>a2988cdb22a79aa4a54e3603e2222166c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>verb</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>a1a05752e41d0ab70ecb9337748e45991</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlHIKMNode *</type>
      <name>root</name>
      <anchorfile>structVlHIKMTree.html</anchorfile>
      <anchor>aa8c7fcf80b9a8d35056cee9788005c78</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlIKMFilt</name>
    <filename>structVlIKMFilt.html</filename>
    <member kind="variable">
      <type>vl_size</type>
      <name>M</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>a827e38f4f931f81abe4e5f4f22c6a38b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>K</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>ac9201e49dcc063d9cfcb75c5ac0f8e4c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>max_niters</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>a972f3c77667d1a364e55f98f76e6281d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>method</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>ae4e37b9263a74255cde334cda98699fc</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>verb</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>ac16f4970d5d24025752c7f52c361487a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_ikmacc_t *</type>
      <name>centers</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>a065192a24b46d957ce1fab8a093c1880</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_ikmacc_t *</type>
      <name>inter_dist</name>
      <anchorfile>structVlIKMFilt.html</anchorfile>
      <anchor>a09b47af446cd9fd552c767bc822aac7a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlKDForest</name>
    <filename>structVlKDForest.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlKDForestNeighbor</name>
    <filename>structVlKDForestNeighbor.html</filename>
    <member kind="variable">
      <type>double</type>
      <name>distance</name>
      <anchorfile>structVlKDForestNeighbor.html</anchorfile>
      <anchor>a33819f0e08407be3ef9f8147dcb61c26</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uindex</type>
      <name>index</name>
      <anchorfile>structVlKDForestNeighbor.html</anchorfile>
      <anchor>ab7e878f102c69e382c75839a42f1dc3f</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlKDForestSearcher</name>
    <filename>structVlKDForestSearcher.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlKMeans</name>
    <filename>structVlKMeans.html</filename>
    <member kind="variable">
      <type>vl_type</type>
      <name>dataType</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a214c12e89d3fae767cbd05c61925a62b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>dimension</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a0bf437dc2b532c176b591fb2a29348c7</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>numCenters</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a9a227d1ad7a4f6597a862bb643751d68</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>numTrees</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>adf0550f848cf978fe2e49ada1549476c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>maxNumComparisons</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>aa74f5dae99f6a559dd803473d3012668</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlKMeansInitialization</type>
      <name>initialization</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>ad1c4e271f9f05a65256ef85872d0c78e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlKMeansAlgorithm</type>
      <name>algorithm</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a904692fa47ab410f699174998fc0d71f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlVectorComparisonType</type>
      <name>distance</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a1dc1d6568d733c77530d4cd85429f17c</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>maxNumIterations</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a7db701e94e7692930738b5fa3bf28314</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>minEnergyVariation</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>ab03a66040a91a7b67b9b1e421f7136b1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>numRepetitions</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>ac26c49b0fc0078c25c02aa4fd084e1c6</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>verbosity</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a17e1b4a25607cfef9bbb4d516ca5920a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>void *</type>
      <name>centers</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>ab4add917caa5961ce6a3cda9b0446be5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>void *</type>
      <name>centerDistances</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a497ffe536f6e2eab2451ad3f56f78b38</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>energy</name>
      <anchorfile>structVlKMeans.html</anchorfile>
      <anchor>a96ed1a0a6244be372e70b61fdf3953fc</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlLbp</name>
    <filename>structVlLbp.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlLiopDesc</name>
    <filename>structVlLiopDesc.html</filename>
    <member kind="variable">
      <type>vl_int</type>
      <name>numNeighbours</name>
      <anchorfile>structVlLiopDesc.html</anchorfile>
      <anchor>a3f448828433881edc6ffadcf53515a8d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_int</type>
      <name>numSpatialBins</name>
      <anchorfile>structVlLiopDesc.html</anchorfile>
      <anchor>a1000b2a0940a3ecc33994ae417db980a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>intensityThreshold</name>
      <anchorfile>structVlLiopDesc.html</anchorfile>
      <anchor>a53bcd9c9d8428734c91be304ff7542b4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>dimension</name>
      <anchorfile>structVlLiopDesc.html</anchorfile>
      <anchor>ab1d786bcf3a16b5199081f0da974b0ca</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>neighRadius</name>
      <anchorfile>structVlLiopDesc.html</anchorfile>
      <anchor>a6f340278850ec9631a5bc6c0a028d740</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlMserExtrReg</name>
    <filename>struct__VlMserExtrReg.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>parent</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>ae8db1abcb43cf63519f6505c8ad4b130</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>index</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>aa6c9cdebc95d472b0d7ec85174be53ee</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_mser_pix</type>
      <name>value</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>a2a580e49b6e80e739bee96ca3b226519</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>shortcut</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>a1ecd8d198c50d70604f4918005e750e7</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>area</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>ab142bed25b2dd8089e2c8d2ebce194c3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>variation</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>a40abc194bb282f1bfa9aed7e08efe4ff</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>max_stable</name>
      <anchorfile>struct__VlMserExtrReg.html</anchorfile>
      <anchor>a03903e0a26a66289b55341616b08169e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlMserFilt</name>
    <filename>struct__VlMserFilt.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>ndims</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a38bbbda6027a6cc5972e9909c4a12692</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>dims</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aeaf813d7f58f2198b25a9ee7ff9e404e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nel</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ade49647bf63afe9f0a695c92974d8764</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>subs</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ac6f3cb73d9a7fd43f6d027b8584041b3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>dsubs</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a2264b7c580aa2cf56b936260fd4c6d9b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>strides</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a2629f43ce616ae381868a4f0f17b591b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>perm</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ade169ed435dead256a61ebc3dc47fa58</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>joins</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>acf8d0ebf133041eda51e3789cf6956ef</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>njoins</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a1ed0f15196286e91dfe0a34c51b04220</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlMserReg *</type>
      <name>r</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aebb2464636ccd5eb4454d7ee535e0cd3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlMserExtrReg *</type>
      <name>er</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a80d6ab8f68d843050f6dfbb15fa76faa</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>mer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a00c6ae0c602645621bcedc26c8204beb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>ner</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a19abf235bce5559c4eb139facd47d842</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nmer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>acd315af1fd4c55ef8f03c8f8eb997a09</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a11040e5cbc6455ef231459f4b991d56d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rmer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aabbd59fddb3c7bd765cdfafdaf5e0272</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>acc</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a32c7bdfbce8c6b42457f4d9807e08d1f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>ell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a8406f80a3fca4c4e905f45e130c51a86</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ab3b0841163944f505ca64da0c23299b3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>afcdbe35c3718b946d0a1325be30e19a3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>dof</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aa1ba51f153855bfec5e55085038a2041</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_bool</type>
      <name>verbose</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a61de9f2acbff1ad0bc5e4a413531ab17</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>delta</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a42c761e11f5785eb405c017c3e6d0626</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>max_area</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a97e972a7f749e0e1d4739775168d9eb4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>min_area</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>abdd439ec557069eeca5cd684bd145431</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>max_variation</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a819ecb6c5cf221ef163f04d3d4773d62</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>min_diversity</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a16946e2db32dbddc90e63349b6f3a17e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>ndims</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a38bbbda6027a6cc5972e9909c4a12692</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>dims</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aeaf813d7f58f2198b25a9ee7ff9e404e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nel</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ade49647bf63afe9f0a695c92974d8764</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>subs</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ac6f3cb73d9a7fd43f6d027b8584041b3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>dsubs</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a2264b7c580aa2cf56b936260fd4c6d9b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int *</type>
      <name>strides</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a2629f43ce616ae381868a4f0f17b591b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>perm</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ade169ed435dead256a61ebc3dc47fa58</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>joins</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>acf8d0ebf133041eda51e3789cf6956ef</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>njoins</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a1ed0f15196286e91dfe0a34c51b04220</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlMserReg *</type>
      <name>r</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aebb2464636ccd5eb4454d7ee535e0cd3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlMserExtrReg *</type>
      <name>er</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a80d6ab8f68d843050f6dfbb15fa76faa</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint *</type>
      <name>mer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a00c6ae0c602645621bcedc26c8204beb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>ner</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a19abf235bce5559c4eb139facd47d842</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nmer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>acd315af1fd4c55ef8f03c8f8eb997a09</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a11040e5cbc6455ef231459f4b991d56d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rmer</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aabbd59fddb3c7bd765cdfafdaf5e0272</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>acc</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a32c7bdfbce8c6b42457f4d9807e08d1f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float *</type>
      <name>ell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a8406f80a3fca4c4e905f45e130c51a86</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>rell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>ab3b0841163944f505ca64da0c23299b3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nell</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>afcdbe35c3718b946d0a1325be30e19a3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>dof</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>aa1ba51f153855bfec5e55085038a2041</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_bool</type>
      <name>verbose</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a61de9f2acbff1ad0bc5e4a413531ab17</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>delta</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a42c761e11f5785eb405c017c3e6d0626</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>max_area</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a97e972a7f749e0e1d4739775168d9eb4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>min_area</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>abdd439ec557069eeca5cd684bd145431</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>max_variation</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a819ecb6c5cf221ef163f04d3d4773d62</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>min_diversity</name>
      <anchorfile>struct__VlMserFilt.html</anchorfile>
      <anchor>a16946e2db32dbddc90e63349b6f3a17e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlMserReg</name>
    <filename>struct__VlMserReg.html</filename>
    <member kind="variable">
      <type>vl_uint</type>
      <name>parent</name>
      <anchorfile>struct__VlMserReg.html</anchorfile>
      <anchor>afaa47c5bf0ed5f406f96f231b8be9f18</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>shortcut</name>
      <anchorfile>struct__VlMserReg.html</anchorfile>
      <anchor>a0e9576f9f559df16c6b1c66f9462996e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>height</name>
      <anchorfile>struct__VlMserReg.html</anchorfile>
      <anchor>a50a7c872e724d0a29a1ca22730f6c2ee</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_uint</type>
      <name>area</name>
      <anchorfile>struct__VlMserReg.html</anchorfile>
      <anchor>a6a68084dfc9dc70169b1f77227531a69</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_VlMserStats</name>
    <filename>struct__VlMserStats.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>num_extremal</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>ab3788acf53ad8e7d18c0e2ea12d306c8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>num_unstable</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>ae8da5c0cc8621ad732843ea365166024</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>num_abs_unstable</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>a6e02b42b26882bb60028c611611e04ca</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>num_too_big</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>ac244e5928e3140f705848c99195b7db9</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>num_too_small</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>a1586d7a48e6ca6f83e66db43b5fa230b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>num_duplicates</name>
      <anchorfile>struct__VlMserStats.html</anchorfile>
      <anchor>aa86bf8d676818932a07d411203ad5538</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>_vlmxOption</name>
    <filename>struct__vlmxOption.html</filename>
    <member kind="variable">
      <type>const char *</type>
      <name>name</name>
      <anchorfile>struct__vlmxOption.html</anchorfile>
      <anchor>a4ec124175ea389a2d549dd47f4a8467e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>has_arg</name>
      <anchorfile>struct__vlmxOption.html</anchorfile>
      <anchor>a8ea5d36cdcddfe856d6a75cddf3f4951</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>val</name>
      <anchorfile>struct__vlmxOption.html</anchorfile>
      <anchor>ae656ba7bcc0adb64cc71fcba135d1f0e</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlPgmImage</name>
    <filename>structVlPgmImage.html</filename>
    <member kind="variable">
      <type>vl_size</type>
      <name>width</name>
      <anchorfile>structVlPgmImage.html</anchorfile>
      <anchor>aa50c42588248640ece2b205f40ebe8da</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>height</name>
      <anchorfile>structVlPgmImage.html</anchorfile>
      <anchor>a9530efa0a38d7a7b23b8fb6fed8cdc05</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>max_value</name>
      <anchorfile>structVlPgmImage.html</anchorfile>
      <anchor>ae05be500dcdba477fb8749d8b2bf38e2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_bool</type>
      <name>is_raw</name>
      <anchorfile>structVlPgmImage.html</anchorfile>
      <anchor>ae762f755ff886e0ea83cdaa89d6b30e8</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlQS</name>
    <filename>structVlQS.html</filename>
    <member kind="variable">
      <type>vl_qs_type *</type>
      <name>image</name>
      <anchorfile>structVlQS.html</anchorfile>
      <anchor>a2a829f63f74287ffc615c80b0d11d0ec</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>height</name>
      <anchorfile>structVlQS.html</anchorfile>
      <anchor>af2163561956e728ec6152f888e186ba2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>width</name>
      <anchorfile>structVlQS.html</anchorfile>
      <anchor>a35bb3b6e10854d9986e23a7eebac9bc3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>channels</name>
      <anchorfile>structVlQS.html</anchorfile>
      <anchor>a8db8bc87fa6dd012d176ee702ed3a078</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlRand</name>
    <filename>structVlRand.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlScaleSpace</name>
    <filename>structVlScaleSpace.html</filename>
  </compound>
  <compound kind="struct">
    <name>VlScaleSpaceGeometry</name>
    <filename>structVlScaleSpaceGeometry.html</filename>
    <member kind="variable">
      <type>vl_size</type>
      <name>width</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>aa94ca44578b0cec97cb82a96586a435f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>height</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a5bfbfc1c3b82074f2e8a53f23eed8e14</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>firstOctave</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a96805e209d1452bfb9aa36b9269efcfc</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>lastOctave</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a0030186c55207e827d3d91b05faa7673</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>octaveResolution</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a1ce73bc970c420bd4c93154727edd16d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>octaveFirstSubdivision</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a6336d051b8aa479fe3085c9fde98db66</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_index</type>
      <name>octaveLastSubdivision</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a0bff7bc6133eabbfb78b1c1c96bc3fa2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>baseScale</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a21d4303a6b90e7b377df29df472a145e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>nominalScale</name>
      <anchorfile>structVlScaleSpaceGeometry.html</anchorfile>
      <anchor>a5cdf5aba69c40c1314f35f18d9fadb0a</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlScaleSpaceOctaveGeometry</name>
    <filename>structVlScaleSpaceOctaveGeometry.html</filename>
    <member kind="variable">
      <type>vl_size</type>
      <name>width</name>
      <anchorfile>structVlScaleSpaceOctaveGeometry.html</anchorfile>
      <anchor>a6453dbc6d4d71f937f6f33ba47305ffd</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>height</name>
      <anchorfile>structVlScaleSpaceOctaveGeometry.html</anchorfile>
      <anchor>a3213379847cead09269f075d6605dda1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>step</name>
      <anchorfile>structVlScaleSpaceOctaveGeometry.html</anchorfile>
      <anchor>a4138bb23b20fa0d96b98027243b79816</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlSiftFilt</name>
    <filename>structVlSiftFilt.html</filename>
    <member kind="variable">
      <type>double</type>
      <name>sigman</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>afeff1449803c0c01e6caf43b68b16355</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>sigma0</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ad583e71c9e367d6314e9ad98d08c61e7</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>sigmak</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ab1574bafcd4927f21c9b358b247db5b1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>dsigma0</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ab15bc7b1dab5c19cc77f037e9eedcd59</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>width</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>abe15202c0f359d7fd0d214ab28820a7a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>height</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a139e1c875981a97807f4a8b9e4dcc9a8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>O</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>acad5649defab73e58886cf2167b72bc5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>S</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a2b05b948c2e8b2d551a9f57320b6005d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>o_min</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a0afd0e233218214356ac3bdf44a36df5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>s_min</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a19ff010fa014177b60b55d6479300d63</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>s_max</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a795fa5ed74858d9bb6cc1816428b1e8f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>o_cur</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a7f7bb566b99f71aff5b2d8b9430654aa</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_sift_pix *</type>
      <name>temp</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a9e7ada896fbee7c781ca26129730f4ce</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_sift_pix *</type>
      <name>octave</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ab80e60a4353a81607b930e4a538ac6c4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_sift_pix *</type>
      <name>dog</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a7db55218d022f8718bbc78741aba08bc</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>octave_width</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a0f125393e5acc4d6585f5b1c29101fb3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>octave_height</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a4bd71bfa8ddda1e8bc31bbeec7d710c8</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_sift_pix *</type>
      <name>gaussFilter</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>addd078a421a4ecbaa5b4d075e965cf9d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>gaussFilterSigma</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ac9de6ece6b423e809b744767246bfd0d</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>gaussFilterWidth</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a90de5afb0eca41df4eb86cab65bfc6d3</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>VlSiftKeypoint *</type>
      <name>keys</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a890071db17c9e746c8cad18f9ebf9127</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>nkeys</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>abe8dd50bac1242461ff84d0f32f570fb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>keys_res</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a8dcda50b7b9433b2fbe7286bd13ed472</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>peak_thresh</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a4111ff540a8dc0c4cfc3d3116725d0a2</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>edge_thresh</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>aef30d44211610ac382ff2de14eb729c0</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>norm_thresh</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a692d31d7aa8ef5906ab8563c8cd1b98b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>magnif</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a61878ee5f5e0b9d6d8640ec626d1b3eb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>windowSize</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>aab8bb3596d89fc6633762d10491a8160</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_sift_pix *</type>
      <name>grad</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>a2313c64b82cb48a32bd550e5c0d56a9b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>grad_o</name>
      <anchorfile>structVlSiftFilt.html</anchorfile>
      <anchor>ac2c41453ede1063403f87a952dca8adb</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlSiftKeypoint</name>
    <filename>structVlSiftKeypoint.html</filename>
    <member kind="variable">
      <type>int</type>
      <name>o</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>af4269a0491b0e78c6aefbf6009e73a8e</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>ix</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>ae79e7fda337fbf4cb13ba7ac79e9b385</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>iy</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>a86c40c68583029a4d5cebe25ec8b5bea</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>int</type>
      <name>is</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>ad508be29f72248edf7c485b04fd020c1</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>x</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>a70c5fa0257fe46373147a5b7469b7ed4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>y</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>ac7d488adf645bd902afb79d65ebfdc5b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>s</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>a722e23b5accdce3b970d415497184e45</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>float</type>
      <name>sigma</name>
      <anchorfile>structVlSiftKeypoint.html</anchorfile>
      <anchor>ad0ad82a253362c5169311af6fdc166f7</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="struct">
    <name>VlSvmStatistics</name>
    <filename>structVlSvmStatistics.html</filename>
    <member kind="variable">
      <type>VlSvmSolverStatus</type>
      <name>status</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a0d2fe3c53652506a1ed06eb29c08420a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>iteration</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>af759443a4cf113b8d821e6210ba0fd2a</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>vl_size</type>
      <name>epoch</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a22f90747c978338a5e9d623f2ea7edb9</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>objective</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>ae5d4b11cbd600bc6b3cb55e98985c214</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>regularizer</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a9919f9f92febc3583d31e11958b3687b</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>loss</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a4bc7e92e0d2d88561b733f6ee8a85e24</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>dualObjective</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a1fff0350a4bb85f2d4b51d80ff347a3f</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>dualLoss</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>af730509dd6b8ac1eb18a5c2d983ae1b4</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>dualityGap</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a87b1ac8d8999abc6ba38ffa56aeb50a5</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>scoresVariation</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>af722bd373382ae10dcff8b5d16c06beb</anchor>
      <arglist></arglist>
    </member>
    <member kind="variable">
      <type>double</type>
      <name>elapsedTime</name>
      <anchorfile>structVlSvmStatistics.html</anchorfile>
      <anchor>a1c0bbc377f42d0b93dd147f964b7ae7d</anchor>
      <arglist></arglist>
    </member>
  </compound>
  <compound kind="page">
    <name>aib</name>
    <title>Agglomerative Information Bottleneck (AIB)</title>
    <filename>aib.html</filename>
    <docanchor file="aib.html" title="Overview">aib-overview</docanchor>
    <docanchor file="aib.html" title="Algorithm details">aib-algorithm</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet</name>
    <title>Covariant feature detectors</title>
    <filename>covdet.html</filename>
    <subpage>covdet-fundamentals.html</subpage>
    <subpage>covdet-principles.html</subpage>
    <subpage>covdet-differential.html</subpage>
    <subpage>covdet-corner-types.html</subpage>
    <docanchor file="covdet.html" title="Getting started">covdet-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet-fundamentals</name>
    <title>Covariant detectors fundamentals</title>
    <filename>covdet-fundamentals.html</filename>
    <docanchor file="covdet-fundamentals.html" title="Covariant detection">covdet-covariance</docanchor>
    <docanchor file="covdet-fundamentals.html" title="Feature geometry and feature frames">covdet-frame</docanchor>
    <docanchor file="covdet-fundamentals.html" title="Transforming feature frames">covdet-frame-transformation</docanchor>
    <docanchor file="covdet-fundamentals.html" title="Normalizing feature frames">covdet-frame-normalization</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet-principles</name>
    <title>Principles of covariant detection</title>
    <filename>covdet-principles.html</filename>
    <docanchor file="covdet-principles.html" title="Detection using a cornerness measure">covdet-cornerness</docanchor>
    <docanchor file="covdet-principles.html" title="Local maxima of a cornerness measure">covdet-cornerness-localmax</docanchor>
    <docanchor file="covdet-principles.html" title="Covariant detection by normalization">covdet-cornerness-normalization</docanchor>
    <docanchor file="covdet-principles.html" title="Locality of the detected features">covdet-locality</docanchor>
    <docanchor file="covdet-principles.html" title="Partial and iterated normalization">covdet-partial</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet-differential</name>
    <title>Differential and integral image operations</title>
    <filename>covdet-differential.html</filename>
    <docanchor file="covdet-differential.html" title="Derivative operations: gradients">covdet-derivatives</docanchor>
    <docanchor file="covdet-differential.html" title="Derivative and image warps">covdet-derivative-transformations</docanchor>
    <docanchor file="covdet-differential.html" title="Integral operations: smoothing">covdet-smoothing</docanchor>
    <docanchor file="covdet-differential.html" title="Smoothing and image warps">covdet-smoothing-transformations</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet-corner-types</name>
    <title>Cornerness measures</title>
    <filename>covdet-corner-types.html</filename>
    <docanchor file="covdet-corner-types.html" title="Harris corners">covdet-harris</docanchor>
    <docanchor file="covdet-corner-types.html" title="Harris in the warped domain">covdet-harris-warped</docanchor>
    <docanchor file="covdet-corner-types.html" title="Hessian blobs">covdet-hessian</docanchor>
    <docanchor file="covdet-corner-types.html" title="Hessian in the warped domain">covdet-hessian-warped</docanchor>
    <docanchor file="covdet-corner-types.html" title="Laplacian and Difference of Gaussians blobs">covdet-laplacian</docanchor>
    <docanchor file="covdet-corner-types.html" title="Laplacian in the warped domain">covdet-laplacian-warped</docanchor>
    <docanchor file="covdet-corner-types.html" title="Laplacian as a matched filter">covdet-laplacian-matched</docanchor>
    <docanchor file="covdet-corner-types.html" title="Difference of Gaussians">covdet-laplacian-dog</docanchor>
  </compound>
  <compound kind="page">
    <name>covdet-affine-adaptation</name>
    <title>Affine adaptation</title>
    <filename>covdet-affine-adaptation.html</filename>
  </compound>
  <compound kind="page">
    <name>covdet-dominant-orientation</name>
    <title>Dominant orientation</title>
    <filename>covdet-dominant-orientation.html</filename>
  </compound>
  <compound kind="page">
    <name>dsift</name>
    <title>Dense Scale Invariant Feature Transform (DSIFT)</title>
    <filename>dsift.html</filename>
    <docanchor file="dsift.html" title="Overview">dsift-intro</docanchor>
    <docanchor file="dsift.html" title="Usage">dsift-usage</docanchor>
    <docanchor file="dsift.html" title="Technical details">dsift-tech</docanchor>
    <docanchor file="dsift.html" title="Dense descriptors">dsift-tech-descriptor-dense</docanchor>
    <docanchor file="dsift.html" title="Sampling">dsift-tech-sampling</docanchor>
  </compound>
  <compound kind="page">
    <name>fisher</name>
    <title>Fisher Vector encoding (FV)</title>
    <filename>fisher.html</filename>
    <subpage>fisher-fundamentals.html</subpage>
    <subpage>fisher-derivation.html</subpage>
    <subpage>fisher-kernel.html</subpage>
    <docanchor file="fisher.html" title="Getting started">fisher-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>fisher-fundamentals</name>
    <title>Fisher vector fundamentals</title>
    <filename>fisher-fundamentals.html</filename>
    <docanchor file="fisher-fundamentals.html" title="Normalization and improved Fisher vectors">fisher-normalization</docanchor>
    <docanchor file="fisher-fundamentals.html" title="Faster computations">fisher-fast</docanchor>
  </compound>
  <compound kind="page">
    <name>fisher-derivation</name>
    <title>Fisher vector derivation</title>
    <filename>fisher-derivation.html</filename>
  </compound>
  <compound kind="page">
    <name>fisher-kernel</name>
    <title>Fisher kernel</title>
    <filename>fisher-kernel.html</filename>
  </compound>
  <compound kind="page">
    <name>resources</name>
    <title>Memory and resource handling</title>
    <filename>resources.html</filename>
  </compound>
  <compound kind="page">
    <name>conventions</name>
    <title>Conventions</title>
    <filename>conventions.html</filename>
    <docanchor file="conventions.html" title="Matrix and image storage conventions">conventions-storage</docanchor>
  </compound>
  <compound kind="page">
    <name>objects</name>
    <title>Objects</title>
    <filename>objects.html</filename>
    <docanchor file="objects.html" title="Object lifecycle">objects-lifecycle</docanchor>
    <docanchor file="objects.html" title="Getters and setters">objects-getters-setters</docanchor>
  </compound>
  <compound kind="page">
    <name>matlab</name>
    <title>MATLAB integration</title>
    <filename>matlab.html</filename>
  </compound>
  <compound kind="page">
    <name>metaprogram</name>
    <title>Preprocessor metaprogramming</title>
    <filename>metaprogram.html</filename>
  </compound>
  <compound kind="page">
    <name>glossary</name>
    <title>Glossary</title>
    <filename>glossary.html</filename>
  </compound>
  <compound kind="page">
    <name>dev</name>
    <title>Developing the library</title>
    <filename>dev.html</filename>
    <docanchor file="dev.html" title="Copyright">dev-copy</docanchor>
    <docanchor file="dev.html" title="Coding style">dev-style</docanchor>
    <docanchor file="dev.html" title="MATLAB coding style">dev-style-matlab</docanchor>
    <docanchor file="dev.html" title="Documenting the code">dev-doc</docanchor>
    <docanchor file="dev.html" title="Documenting the library modules">devl-doc-modules</docanchor>
    <docanchor file="dev.html" title="Documenting functions">devl-doc-functions</docanchor>
    <docanchor file="dev.html" title="Documenting structures">devl-doc-structures</docanchor>
    <docanchor file="dev.html" title="Bibliographic references">devl-doc-bib</docanchor>
  </compound>
  <compound kind="page">
    <name>generic</name>
    <title>General support functionalities</title>
    <filename>generic.html</filename>
    <subpage>resources.html</subpage>
    <subpage>threads.html</subpage>
    <subpage>misc.html</subpage>
  </compound>
  <compound kind="page">
    <name>misc</name>
    <title>Preprocssor, library state, etc.</title>
    <filename>misc.html</filename>
    <docanchor file="misc.html" title="C preprocessor helpers">misc-preproc</docanchor>
    <docanchor file="misc.html" title="VLFeat state and configuration parameters">misc-state</docanchor>
    <docanchor file="misc.html" title="Error handling">misc-error</docanchor>
    <docanchor file="misc.html" title="Memory allocation">misc-memory</docanchor>
    <docanchor file="misc.html" title="Logging">misc-logging</docanchor>
    <docanchor file="misc.html" title="Measuring time">misc-time</docanchor>
  </compound>
  <compound kind="page">
    <name>threads</name>
    <title>Threading</title>
    <filename>threads.html</filename>
    <docanchor file="threads.html" title="Using VLFeat from multiple threads">threads-multiple</docanchor>
    <docanchor file="threads.html" title="Parallel computations">threads-parallel</docanchor>
  </compound>
  <compound kind="page">
    <name>gmm</name>
    <title>Gaussian Mixture Models (GMM)</title>
    <filename>gmm.html</filename>
    <subpage>gmm-fundamentals.html</subpage>
    <docanchor file="gmm.html" title="Getting started">gmm-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>gmm-fundamentals</name>
    <title>GMM fundamentals</title>
    <filename>gmm-fundamentals.html</filename>
    <docanchor file="gmm-fundamentals.html" title="Learning a GMM by expectation maximization">gmm-em</docanchor>
    <docanchor file="gmm-fundamentals.html" title="Expectation step">gmm-expectation-step</docanchor>
    <docanchor file="gmm-fundamentals.html" title="Maximization step">gmm-maximization-step</docanchor>
    <docanchor file="gmm-fundamentals.html" title="Initialization algorithms">gmm-fundamentals-init</docanchor>
  </compound>
  <compound kind="page">
    <name>hog</name>
    <title>Histogram of Oriented Gradients (HOG) features</title>
    <filename>hog.html</filename>
    <docanchor file="hog.html" title="Overview">hog-overview</docanchor>
    <docanchor file="hog.html" title="Technical details">hog-tech</docanchor>
    <docanchor file="hog.html" title="Conventions">hog-conventions</docanchor>
  </compound>
  <compound kind="page">
    <name>homkermap</name>
    <title>Homogeneous kernel map</title>
    <filename>homkermap.html</filename>
    <docanchor file="homkermap.html" title="Getting started">homkermap-starting</docanchor>
    <docanchor file="homkermap.html" title="Fundamentals">homkermap-fundamentals</docanchor>
    <docanchor file="homkermap.html" title="Extension to the negative reals">homkermap-overview-negative</docanchor>
    <docanchor file="homkermap.html" title="Homogeneity degree">homkermap-overview-homogeneity</docanchor>
    <docanchor file="homkermap.html" title="Windowing and period">homkermap-overview-window</docanchor>
    <docanchor file="homkermap.html" title="Implementation details">homkermap-details</docanchor>
  </compound>
  <compound kind="page">
    <name>portability</name>
    <title>Portability features</title>
    <filename>portability.html</filename>
    <docanchor file="portability.html" title="Host operating system">host-os</docanchor>
    <docanchor file="portability.html" title="Host compiler">host-compiler</docanchor>
    <docanchor file="portability.html" title="Data models">host-compiler-data-model</docanchor>
    <docanchor file="portability.html" title="Other compiler-specific features">host-compiler-other</docanchor>
    <docanchor file="portability.html" title="Host CPU architecture">host-arch</docanchor>
    <docanchor file="portability.html" title="Endianness">host-arch-endianness</docanchor>
    <docanchor file="portability.html" title="Multi-threading">host-threads</docanchor>
  </compound>
  <compound kind="page">
    <name>kdtree</name>
    <title>KD-trees and forests</title>
    <filename>kdtree.html</filename>
    <docanchor file="kdtree.html" title="Overview">kdtree-overview</docanchor>
    <docanchor file="kdtree.html" title="Technical details">kdtree-tech</docanchor>
  </compound>
  <compound kind="page">
    <name>kmeans</name>
    <title>K-means clustering</title>
    <filename>kmeans.html</filename>
    <subpage>kmeans-fundamentals.html</subpage>
    <docanchor file="kmeans.html" title="Getting started">kmeans-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>kmeans-fundamentals</name>
    <title>K-means fundamentals</title>
    <filename>kmeans-fundamentals.html</filename>
    <docanchor file="kmeans-fundamentals.html" title="Initialization methods">kmeans-init</docanchor>
    <docanchor file="kmeans-fundamentals.html" title="Lloyd&apos;s algorithm">kmeans-lloyd</docanchor>
    <docanchor file="kmeans-fundamentals.html" title="Elkan&apos;s algorithm">kmeans-elkan</docanchor>
    <docanchor file="kmeans-fundamentals.html" title="ANN algorithm">kmeans-ann</docanchor>
  </compound>
  <compound kind="page">
    <name>lbp</name>
    <title>Local Binary Patterns (LBP) descriptor</title>
    <filename>lbp.html</filename>
    <subpage>lbp-fundamentals.html</subpage>
    <docanchor file="lbp.html" title="Getting started with LBP">lbp-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>lbp-fundamentals</name>
    <title>Local Binary Patterns fundamentals</title>
    <filename>lbp-fundamentals.html</filename>
    <docanchor file="lbp-fundamentals.html" title="Quantized LBP">lbp-quantization</docanchor>
    <docanchor file="lbp-fundamentals.html" title="Histograms of LBPs">lbp-histograms</docanchor>
  </compound>
  <compound kind="page">
    <name>liop</name>
    <title>Local Intensity Order Pattern (LIOP) descriptor</title>
    <filename>liop.html</filename>
    <subpage>liop-fundamentals.html</subpage>
    <docanchor file="liop.html" title="Getting started with LIOP">liop-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>liop-fundamentals</name>
    <title>LIOP fundamentals</title>
    <filename>liop-fundamentals.html</filename>
    <docanchor file="liop-fundamentals.html" title="Intensity rank spatial binning">liop-spatial-binning</docanchor>
    <docanchor file="liop-fundamentals.html" title="Weighted pooling">liop-weighing</docanchor>
    <docanchor file="liop-fundamentals.html" title="Normalization">liop-normalization</docanchor>
  </compound>
  <compound kind="page">
    <name>mathop</name>
    <title>Mathematical operations</title>
    <filename>mathop.html</filename>
    <subpage>mathop-sqrti.html</subpage>
    <docanchor file="mathop.html" title="Comparing vectors">mathop-usage-vector-comparison</docanchor>
    <docanchor file="mathop.html" title="Fast basic functions operations">mathop-integer-ops</docanchor>
  </compound>
  <compound kind="page">
    <name>mathop-sqrti</name>
    <title>Fast integer square root algorithm</title>
    <filename>mathop-sqrti.html</filename>
  </compound>
  <compound kind="page">
    <name>mser</name>
    <title>Maximally Stable Extremal Regions (MSER)</title>
    <filename>mser.html</filename>
    <subpage>mser-fundamentals.html</subpage>
    <docanchor file="mser.html" title="Getting started with the MSER detector">mser-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>mser-fundamentals</name>
    <title>MSER fundamentals</title>
    <filename>mser-fundamentals.html</filename>
    <docanchor file="mser-fundamentals.html" title="Volumetric images">mser-vol</docanchor>
    <docanchor file="mser-fundamentals.html" title="Ellipsoids">mser-ell</docanchor>
    <docanchor file="mser-fundamentals.html" title="Algorithm">mser-algo</docanchor>
  </compound>
  <compound kind="page">
    <name>quickshift</name>
    <title>Quick shift image segmentation</title>
    <filename>quickshift.html</filename>
    <docanchor file="quickshift.html" title="Overview">quickshift-intro</docanchor>
    <docanchor file="quickshift.html" title="Usage">quickshift-usage</docanchor>
    <docanchor file="quickshift.html" title="Technical details">quickshift-tech</docanchor>
  </compound>
  <compound kind="page">
    <name>random</name>
    <title>Random number generator</title>
    <filename>random.html</filename>
    <docanchor file="random.html" title="Getting started">random-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>scalespace</name>
    <title>Gaussian Scale Space (GSS)</title>
    <filename>scalespace.html</filename>
    <subpage>scalespace-fundamentals.html</subpage>
    <docanchor file="scalespace.html" title="Getting started">scalespace-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>scalespace-fundamentals</name>
    <title>Gaussian scale space fundamentals</title>
    <filename>scalespace-fundamentals.html</filename>
    <docanchor file="scalespace-fundamentals.html" title="Scale space definition">scalespace-definition</docanchor>
    <docanchor file="scalespace-fundamentals.html" title="Scale space geometry">scalespace-geometry</docanchor>
    <docanchor file="scalespace-fundamentals.html" title="Algorithm and limitations">scalespace-algorithm</docanchor>
  </compound>
  <compound kind="page">
    <name>sift</name>
    <title>Scale Invariant Feature Transform (SIFT)</title>
    <filename>sift.html</filename>
    <docanchor file="sift.html" title="Overview">sift-intro</docanchor>
    <docanchor file="sift.html" title="SIFT detector">sift-intro-detector</docanchor>
    <docanchor file="sift.html" title="SIFT Descriptor">sift-intro-descriptor</docanchor>
    <docanchor file="sift.html" title="Extensions">sift-intro-extensions</docanchor>
    <docanchor file="sift.html" title="Using the SIFT filter object">sift-usage</docanchor>
    <docanchor file="sift.html" title="Technical details">sift-tech</docanchor>
    <docanchor file="sift.html" title="Scale space">sift-tech-ss</docanchor>
    <docanchor file="sift.html" title="Detector">sift-tech-detector</docanchor>
    <docanchor file="sift.html" title="Eliminating low contrast responses">sift-tech-detector-peak</docanchor>
    <docanchor file="sift.html" title="Eliminating edge responses">sift-tech-detector-edge</docanchor>
    <docanchor file="sift.html" title="Orientation assignment">sift-tech-detector-orientation</docanchor>
    <docanchor file="sift.html" title="Descriptor">sift-tech-descriptor</docanchor>
    <docanchor file="sift.html" title="Construction in the canonical frame">sift-tech-descriptor-can</docanchor>
    <docanchor file="sift.html" title="Calculation in the image frame">sift-tech-descriptor-image</docanchor>
    <docanchor file="sift.html" title="Standard SIFT descriptor">sift-tech-descriptor-std</docanchor>
  </compound>
  <compound kind="page">
    <name>slic</name>
    <title>Simple Linear Iterative Clustering (SLIC)</title>
    <filename>slic.html</filename>
    <docanchor file="slic.html" title="Overview">slic-overview</docanchor>
    <docanchor file="slic.html" title="Usage from the C library">slic-usage</docanchor>
    <docanchor file="slic.html" title="Technical details">slic-tech</docanchor>
  </compound>
  <compound kind="page">
    <name>svm</name>
    <title>Support Vector Machines (SVM)</title>
    <filename>svm.html</filename>
    <subpage>svm-fundamentals.html</subpage>
    <subpage>svm-advanced.html</subpage>
    <subpage>svm-sgd.html</subpage>
    <subpage>svm-sdca.html</subpage>
    <docanchor file="svm.html" title="Getting started">svm-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>svm-fundamentals</name>
    <title>SVM fundamentals</title>
    <filename>svm-fundamentals.html</filename>
    <docanchor file="svm-fundamentals.html" title="Learning">svm-learning</docanchor>
    <docanchor file="svm-fundamentals.html" title="Adding a bias">svm-bias</docanchor>
    <docanchor file="svm-fundamentals.html" title="Non-linear SVMs and feature maps">svm-feature-maps</docanchor>
  </compound>
  <compound kind="page">
    <name>svm-advanced</name>
    <title>Advanced SVM topics</title>
    <filename>svm-advanced.html</filename>
    <docanchor file="svm-advanced.html" title="Loss functions">svm-loss-functions</docanchor>
    <docanchor file="svm-advanced.html" title="Data abstraction: working with compressed data">svm-data-abstraction</docanchor>
    <docanchor file="svm-advanced.html" title="Dual problem">svm-dual-problem</docanchor>
    <docanchor file="svm-advanced.html" title="Parametrization in C">svm-C</docanchor>
  </compound>
  <compound kind="page">
    <name>svm-sdca</name>
    <title>Stochastic Dual Coordinate Ascent</title>
    <filename>svm-sdca.html</filename>
    <docanchor file="svm-sdca.html" title="Dual coordinate maximization">svm-sdca-dual-max</docanchor>
  </compound>
  <compound kind="page">
    <name>svm-sgd</name>
    <title>Stochastic Gradient Descent</title>
    <filename>svm-sgd.html</filename>
    <docanchor file="svm-sgd.html" title="Convergence and speed">svm-sgd-convergence</docanchor>
    <docanchor file="svm-sgd.html" title="The bias term">svm-sgd-bias</docanchor>
    <docanchor file="svm-sgd.html" title="Adjusting the learning rate">svm-sgd-starting-iteration</docanchor>
    <docanchor file="svm-sgd.html" title="Implementation details">svm-sgd-details</docanchor>
  </compound>
  <compound kind="page">
    <name>vlad</name>
    <title>Vector of Locally Aggregated Descriptors (VLAD) encoding</title>
    <filename>vlad.html</filename>
    <subpage>vlad-fundamentals.html</subpage>
    <docanchor file="vlad.html" title="Getting started with VLAD">vlad-starting</docanchor>
  </compound>
  <compound kind="page">
    <name>vlad-fundamentals</name>
    <title>VLAD fundamentals</title>
    <filename>vlad-fundamentals.html</filename>
    <docanchor file="vlad-fundamentals.html" title="VLAD normalization">vlad-normalization</docanchor>
  </compound>
  <compound kind="page">
    <name>index</name>
    <title>Vision Lab Features Library (VLFeat)</title>
    <filename>index.html</filename>
    <subpage>sift.html</subpage>
    <subpage>dsift.html</subpage>
    <subpage>mser.html</subpage>
    <subpage>covdet.html</subpage>
    <subpage>scalespace.html</subpage>
    <subpage>hog.html</subpage>
    <subpage>fisher.html</subpage>
    <subpage>vlad.html</subpage>
    <subpage>liop.html</subpage>
    <subpage>lbp.html</subpage>
    <subpage>kmeans.html</subpage>
    <subpage>gmm.html</subpage>
    <subpage>aib.html</subpage>
    <subpage>kdtree.html</subpage>
    <subpage>slic.html</subpage>
    <subpage>quickshift.html</subpage>
    <subpage>homkermap.html</subpage>
    <subpage>svm.html</subpage>
    <subpage>random.html</subpage>
    <subpage>mathop.html</subpage>
    <subpage>conventions.html</subpage>
    <subpage>generic.html</subpage>
    <subpage>portability.html</subpage>
    <subpage>objects.html</subpage>
    <subpage>matlab.html</subpage>
    <subpage>metaprogram.html</subpage>
    <subpage>dev.html</subpage>
    <subpage>glossary.html</subpage>
    <docanchor file="index.html" title="Contents">main-contents</docanchor>
  </compound>
</tagfile>
